// role: [工程师]+[AI]
// ════════════════════════════════════════════════════════════════
//  service.notice.js — 通知数据模型
//  提供 NoticeStore：通知的 CRUD + mockDB 持久化
//  独立于 mockDB 内存结构，通过 mockDB.notices 统一持久化
// ════════════════════════════════════════════════════════════════

import { mockDB } from '../../core/domain/domain.js?v=20261028a';
import { generateId } from '../../core/base/id.js?v=20261028a';
import { persist, getDataSource, getApiBaseUrl, getAuthToken, adoptCollectionFromServer } from '../../data/data-adapter.js?v=20261028a';
import { buildSystemNotice } from '../../core/domain/system-notice-templates.js?v=20261028a';
import { bumpToken } from '../../core/base/version-token.js?v=20261028a'; // P0 域缓存失效（spec §二.3）
import { MOCK_NOTICES } from '../../data/mock/index.js?v=20261028a';
import { isInitStateActive } from '../core/init-reset.js?v=20261028a'; // C2 修复（2026-09-08）：init 态跳过演示种子兜底
import { todayLocal } from '../../core/base/utils.js?v=20261028a';
import { AuthStore } from '../core/auth.js?v=20261028a';
import {  getPersonById, getPersonName } from '../member/person.js?v=20261028a';
import { NoticeTodoDeriver, TodoStore, TodoSourceType, TodoStatus } from './todo.js?v=20261028a';
// 组织者身份读取单一源（2026-09-19 批次 91 · SOP-B-17）——发布权随「被指定为该场组织者」动态获得
import {  getOrganizedActivities } from '../activity/activity.js?v=20261028a';
import {
  NOTICE_PUBLISH_ROLES, NOTICE_MANAGE_ROLES, BRANCH_COMMISSION_ROLES,
  NOTICE_AUDIENCE_SENTINELS, ROLE_LABELS,
  DEFAULT_BRANCH_ID,
} from '../../core/domain/constants.js?v=20261028a';

// ════════════════════════════════════════════════════════════════
//  消息对象模型（Task 3 · 2026-10-25）
//  一条消息只有一个身份：公告 announcement / 系统通知 system / 私信 message。
//  历史行缺 `kind` 时按 `kindOf()` 迁移；缺坐标时尽量从 `targetUrl` / `meetingActivityId` 补齐，
//  补不出坐标的非公告行降级为 announcement（「非公告必须有 targetType+targetId」的落库口径）。
// ════════════════════════════════════════════════════════════════

/** 消息种类（单一源）：显式 kind 优先；私信 → message；系统来源 → system；其余 → announcement */
export function kindOf(n) {
  if (!n) return 'announcement';
  if (n.kind === 'announcement' || n.kind === 'system' || n.kind === 'message') return n.kind;
  if (n.noticeType === 'message') return 'message';
  if (n.sourceType || n.systemKind || n.derivedFromSystem === true) return 'system';
  return 'announcement';
}

/** 逐人归档名单（旧行无 archivedBy = 未归档） */
function _archivedByOf(n) {
  return Array.isArray(n && n.archivedBy) ? n.archivedBy.filter(Boolean) : [];
}

/** 逐人归档：系统归档（archived）不可恢复；用户归档（archivedBy）可恢复 */
export function isArchivedFor(n, viewerId) {
  if (!n) return false;
  if (n.archived === true) return true;
  return !!viewerId && _archivedByOf(n).includes(viewerId);
}

function _isExpired(n, today = todayLocal()) {
  return !!(n && n.expireDate && n.expireDate < today);
}

/** 列表口径的「已归档」：用户归档 / 系统归档 / 自然过期（过期即系统归档，见 spec「消息过期」） */
function _archivedForViewer(n, viewerId) {
  return isArchivedFor(n, viewerId) || _isExpired(n);
}

function _isReadBy(n, viewerId) {
  return !!(viewerId && _readsOf(n).includes(viewerId));
}

/** 私信对当前人是否为「发出」（自己发给自己以外的人）——自己的发件不计未读 */
function _isOwnOutboundMessage(n, viewerId, ctx) {
  if (kindOf(n) !== 'message' || !viewerId) return false;
  if (!ctx) ctx = _noticeViewerCtx(AuthStore.getCurrentUser());
  return !!n.fromPersonId && n.fromPersonId === viewerId && !_audiencePersonsHit(n, ctx);
}

/** 从落点 URL 解析对象坐标（历史行规范化用；不改变 targetUrl 本身的兜底地位） */
function _coordsFromUrl(url) {
  if (typeof url !== 'string' || !url) return null;
  const grab = (key) => {
    const m = new RegExp(`[?&]${key}=([^&]+)`).exec(url);
    return m ? decodeURIComponent(m[1]) : null;
  };
  if (/thought-report\.html/.test(url)) {
    const id = grab('id');
    return id ? { targetType: 'thoughtReport', targetId: id } : null;
  }
  if (/taskforce\.html/.test(url)) {
    const id = grab('id');
    return id ? { targetType: 'taskforce', targetId: id } : null;
  }
  if (/activity\.html/.test(url)) {
    const id = grab('id');
    return id ? { targetType: 'activity', targetId: id } : null;
  }
  const activityId = grab('activityId');
  if (activityId) return { targetType: 'activity', targetId: activityId };
  return null;
}

/** 历史行规范化（幂等）：补 reads / archivedBy / kind / 坐标；不改业务字段 */
function _normalizeNotice(n, viewerId) {
  const row = { ...n, archived: n.archived === true };
  if (!Array.isArray(row.reads)) {
    row.reads = row.read === true && viewerId ? [viewerId] : [];
  }
  delete row.read;
  if (!Array.isArray(row.archivedBy)) row.archivedBy = [];
  if (!row.kind) row.kind = kindOf(row);
  if (!row.targetType || !row.targetId) {
    const coords = _coordsFromUrl(row.targetUrl)
      || (row.meetingActivityId ? { targetType: 'activity', targetId: row.meetingActivityId } : null);
    if (coords) {
      row.targetType = row.targetType || coords.targetType;
      row.targetId = row.targetId || coords.targetId;
    }
  }
  // 「非公告必须有 targetType+targetId」只约束系统通知；私信没有对象坐标是合法形态。
  if (row.kind === 'system' && !(row.targetType && row.targetId)) {
    row.kind = 'announcement';
  }
  return row;
}

function _loadNotices() {
  try {
    // 2026-08-08 归档闭环：统一归一化 archived 字段（旧数据缺省视为未归档）
    // R2-49（2026-10-20）：已读改为逐人 `reads: personId[]`；旧全局 `read` 只做一次性回填——
    //   只回填给**当前登录人**（无会话则按未读），随后删除该字段；不把「某人读过」扩散成全站已读。
    const viewerId = _viewerPersonId();
    return (mockDB.notices || []).map(n => _normalizeNotice(n, viewerId));
  } catch (e) {
    console.warn('[NoticeStore] 加载失败：', e);
    return [];
  }
}

function _saveNotices(notices) {
  try {
    mockDB.notices = [...notices];
    bumpToken('notice'); // P0：通知写口统一 bump（发布/编辑/删除/归档/标记已读）
    persist();
  } catch (e) {
    console.warn('[NoticeStore] 保存失败：', e);
  }
}

// ════════════════════════════════════════════════════════════════
//  逐人已读（R2-49，2026-10-20）
//  为什么：通知是共享行，全局 `read` 布尔会让「广播通知任一人点开 ⇒ 所有人未读清零」。
//  现口径：通知本体仍只有一行；已读写在行内 `reads: personId[]`（不改表结构，随 JSON 行持久化）。
//  读侧投影：list()/getAll()/getById() 返回的每条通知都带**当前人**的 `read` 布尔，
//  既有消费点（铃铛/首页/待办未读条）无需各自再算。
// ════════════════════════════════════════════════════════════════

/** 通知的逐人已读名单（旧行无 reads = 无人已读） */
function _readsOf(n) {
  return Array.isArray(n && n.reads) ? n.reads.filter(Boolean) : [];
}

/** 当前登录人 personId（无会话 = null；不得猜人） */
function _viewerPersonId() {
  return AuthStore.getCurrentUser()?.personId || null;
}

/** 给通知副本投影当前人的 read / kind / 归档（不修改源行，避免把观看者信息写回共享记录） */
function _withViewerRead(n, viewerId) {
  return {
    ...n,
    kind: kindOf(n),
    read: _isReadBy(n, viewerId),
    archivedForViewer: _archivedForViewer(n, viewerId),
  };
}

// ════════════════════════════════════════════════════════════════
//  S1（2026-09-12）：通知 id 兜底重建——通知类待办未持久化到 NoticeStore 时，
//  按 id（noticeId / sourceId / todo.id）从待办现算重建一条只读通知，
//  使 notice.html?id=<id> 对任一入口都取得到正文（不新增第二份存储）。
// ════════════════════════════════════════════════════════════════

/** 待办 → 通知视图对象（正文重建；read=待办已办结） */
function _noticeFromTodo(todo, id) {
  if (!todo) return null;
  return {
    id,
    title: todo.title || '通知',
    content: todo.description || '',
    priority: todo.priority || 'normal',
    publishDate: String(todo.createdAt || '').slice(0, 10) || null,
    expireDate: todo.deadline || null,
    read: todo.status === TodoStatus.COMPLETED,
    targetModule: (todo.actionData && todo.actionData.targetModule) || null,
    derivedFromTodo: true, // 标记：正文由待办重建（确认读取=销对应待办）
  };
}

// ════════════════════════════════════════════════════════════════
//  受众判定单一源（Q-22-1，2026-09-13）
//  发布侧写入 NOTICE_AUDIENCE_SENTINELS（core/domain/constants.js）的 sentinel 值，
//  消费端可见性判定（list() 受众门 / canReadNotice() 详情页读取权限）必须走这里，
//  杜绝「发布侧写 sentinel / 消费端比角色键」的口径分裂（`['all']` 永不命中 → 无人可见）。
// ════════════════════════════════════════════════════════════════

/**
 * 观看者上下文（list() 与 canReadNotice 共用）：角色 / 到人 personId / 发展阶段
 * 发展阶段从人员档案取（勿新增重依赖；getPersonById 已是本模块既有依赖）。
 * @param {{ role?:string, personId?:string }|null} user
 * @returns {{ role:string|null, personId:string|null, developStage:string|null }}
 */
function _noticeViewerCtx(user) {
  if (!user) return { role: null, personId: null, developStage: null };
  const personId = user.personId || null;
  return {
    role: user.role || null,
    personId,
    // 服务端复算受众时可直接带 developStage（避免拿前端 mockDB 人员表猜）；缺省仍按本地人员表取。
    developStage: user.developStage || (personId ? (getPersonById(personId)?.developStage || null) : null),
  };
}

/**
 * audience 数组命中判定（sentinel 单一源 + 裸角色键兼容）
 *  - sentinel broadcast（all）→ 恒命中（全员可见）
 *  - sentinel roles 含当前角色 / developStages 含当前发展阶段 → 命中
 *  - 未登记裸值 → 回退角色键直比（兼容 audience: ['org-commissioner'] 等既有写法）
 * @param {Object} n 通知
 * @param {{ role:string|null, developStage:string|null }} ctx
 * @returns {boolean}
 */
function _audienceHit(n, ctx) {
  if (!Array.isArray(n.audience) || !n.audience.length) return false;
  // 裸角色键兼容（含既有 audience: ['org-commissioner'] 等写法；sentinel 值不会与真实角色键冲突）
  if (ctx.role && n.audience.includes(ctx.role)) return true;
  return n.audience.some((s) => {
    // committee＝「本支部支委层」受众：须带支部比对，由 list() 的专用分支判定；
    //   此处不做全局角色命中，避免跨支部支委越权读到别的支部支委会通知。
    if (s === 'committee') return false;
    const def = NOTICE_AUDIENCE_SENTINELS[s];
    if (!def) return false;
    if (def.broadcast) return true;
    if (Array.isArray(def.roles) && ctx.role && def.roles.includes(ctx.role)) return true;
    if (Array.isArray(def.developStages) && ctx.developStage && def.developStages.includes(ctx.developStage)) return true;
    return false;
  });
}

/** audience 是否含指定 sentinel（裸字符串或数组；R10-B11：committee 判定统一查 NOTICE_AUDIENCE_SENTINELS） */
function _audienceSentinelPresent(n, sentinel) {
  const a = n && n.audience;
  return Array.isArray(a) ? a.includes(sentinel) : a === sentinel;
}

/** 指定 sentinel 的受众命中（按 NOTICE_AUDIENCE_SENTINELS 的 roles/developStages/broadcast 判定） */
function _audienceSentinelHit(n, sentinel, ctx) {
  if (!_audienceSentinelPresent(n, sentinel)) return false;
  const def = NOTICE_AUDIENCE_SENTINELS[sentinel];
  if (!def) return false;
  if (def.broadcast) return true;
  if (Array.isArray(def.roles) && ctx.role && def.roles.includes(ctx.role)) return true;
  if (Array.isArray(def.developStages) && ctx.developStage && def.developStages.includes(ctx.developStage)) return true;
  return false;
}

/** audiencePersons 到人定向命中（既有口径，不改） */
function _audiencePersonsHit(n, ctx) {
  return !!(ctx.personId && Array.isArray(n.audiencePersons) && n.audiencePersons.includes(ctx.personId));
}

/** actionRoles 行动角色命中（既有口径，不改） */
function _audienceActionRolesHit(n, ctx) {
  return !!(ctx.role && Array.isArray(n.actionRoles) && n.actionRoles.includes(ctx.role));
}

/**
 * 该通知是否「有受众」（四类受众源任一非空）。
 * sentinel 值（含 audience 为裸字符串 sentinel 的历史写法）也视为有受众——
 * 但 broadcast sentinel（all）语义是广播，仍对所有人可见（见 _isBroadcastAudience）。
 */
function _hasAudience(n) {
  return (Array.isArray(n.audience) && n.audience.length > 0)
    || !!NOTICE_AUDIENCE_SENTINELS[n.audience]
    || (Array.isArray(n.audiencePersons) && n.audiencePersons.length > 0)
    || (Array.isArray(n.actionRoles) && n.actionRoles.length > 0);
}

/** audience 是否含广播 sentinel（all）→ 全员可见（含无登录会话） */
function _isBroadcastAudience(n) {
  const a = n.audience;
  if (!a) return false;
  const list = Array.isArray(a) ? a : [a];
  return list.some((s) => NOTICE_AUDIENCE_SENTINELS[s] && NOTICE_AUDIENCE_SENTINELS[s].broadcast === true);
}

/** 观看者是否该通知的发布者（签发人恒可读自己的通知） */
function _isPublisher(n, ctx) {
  if (!ctx || !ctx.role) return false;
  // 站内信（批次 348）：**发件人到人**（`fromPersonId`）——先判，不与角色标签口径混用
  if (n.fromPersonId && ctx.personId && n.fromPersonId === ctx.personId) return true;
  // UI 发布口径：publishedBy 存角色标签（ROLE_LABELS[角色]），无 personId；按其比对
  if (n.publishedBy && ROLE_LABELS[ctx.role] && n.publishedBy === ROLE_LABELS[ctx.role]) return true;
  // 显式签发人 id（数据若带则优先）
  return !!(ctx.personId && (n.publisherId === ctx.personId || n.createdBy === ctx.personId));
}

// ════════════════════════════════════════════════════════════════
//  §D4 权限控制 — 通知发布/编辑/删除必须对接到角色白名单
// ════════════════════════════════════════════════════════════════

// dogfood 权限专项 2026-09-13：改引 constants.js 单一源（NOTICE_PUBLISH_ROLES / NOTICE_MANAGE_ROLES）——
// server routes/resources.js 的 notices 写门同源，杜绝「前端放行、后端全开」的前后端不一致。
const MANAGE_NOTICE_ROLES = new Set(NOTICE_MANAGE_ROLES);
const PUBLISH_NOTICE_ROLES = new Set(NOTICE_PUBLISH_ROLES);

export const NoticePermission = {
  /**
   * 发布权（2026-09-19 批次 91 · SOP-B-17 / `D-308` · `D-309`）：
   *   ① 角色白名单（支书 / 副支书 / 组织委员 / 宣传委员）——全支部通知与治理通知；
   *   ② **本组通知**：此人**被指定为某场活动的组织者**（按活动身份，不是角色）⇒ 该场的发布口就在他台上。
   *      指定即赋权、解除即收回（判据单一源 = `services/activity/activity.js::getOrganizedActivities`）。
   * @param {string} role 常设角色键
   * @param {string} [personId] 当前人（缺省＝只按角色白名单判定，保持既有调用点行为）
   * @param {Object|null} [notice] 待发布通知；给定则组织者例外只放行「**本场**活动通知」
   *   （与服务端 `routes/resources/gates.js::_isActivityOrganizer` 同一判据，R4-F03）
   */
  canPublish(role, personId, notice = null) {
    if (PUBLISH_NOTICE_ROLES.has(role)) return true;
    if (!personId) return false;
    const organized = getOrganizedActivities(personId);
    if (organized.length === 0) return false;
    if (!notice) return true; // 无通知上下文（如按钮显隐）保持既有判据
    const activityId = notice.targetType === 'activity' ? notice.targetId : (notice.activityId || null);
    return !!activityId && organized.some((activity) => activity.id === activityId);
  },

  canManage(role) {
    return MANAGE_NOTICE_ROLES.has(role);
  },

  check(role, action = 'read', personId = null, notice = null) {
    if (action === 'publish' || action === 'add') return this.canPublish(role, personId, notice);
    if (action === 'edit' || action === 'update' || action === 'remove') return this.canManage(role);
    return true; // read — 全员可读
  },
};

export const NoticeStore = {
  _notices: [],

  init() {
    // R2-49：旧全局 read → 逐人 reads 的迁移只发生在权威缓存上；迁移后同步回 mockDB，
    // 否则 _current() 优先读 mockDB 时又会拿到旧字段（迁移等于没做）。
    // R2-49：只有**旧全局 read 字段仍在**时才需要迁移并落盘；
    // 仅缺 reads 数组（例如服务端新行）不必整表回写，读侧按「无人已读」投影即可。
    const needsReadMigration = (mockDB.notices || []).some(n => 'read' in n);
    const persisted = _loadNotices();
    if (persisted.length > 0) {
      this._notices = persisted;
      if (needsReadMigration && mockDB.notices && mockDB.notices.length > 0) {
        mockDB.notices = persisted.map(n => ({ ...n }));
        bumpToken('notice');
        // 迁移要真正「一次性」：数据已加载时立即落盘（mock→localStorage / api→快照），
        // 否则下次换人登录会把旧全局 read=true 再回填给新用户。
        if (mockDB._loaded) _saveNotices(mockDB.notices);
      }
    } else if (getDataSource() === 'api' || isInitStateActive()) {
      // C2 修复（2026-09-08）：init 态下「无持久化通知 = 合法空支部态」——不兜底演示种子
      //（否则 MOCK_NOTICES 会经 _saveNotices 重新写回 mockDB/持久层，通知在 init 后回填 demo）。
      // Task 3（2026-10-26）：api 形态同样禁止空表回退（生产空库必须显示空态，不出现种子 id），
      // 且此分支**不落库**（没有 persist / _saveNotices）。
      this._notices = [];
    } else {
      this._notices = [...MOCK_NOTICES];
      // 2026-08-08 归档闭环修复：mockDB 未加载（_loaded=false）时不得落库，
      // 否则会用 seed 原版覆盖 localStorage 中的运行时字段（如 archived），
      // 且过早落库可能写入不完整数据。loadDB 完成后读取统一走 _current()。
      if (mockDB._loaded) {
        _saveNotices(this._notices);
      }
    }
  },

  /**
   * 当前数据源（2026-08-08 归档闭环修复）：
   * 优先取 mockDB.notices（loadDB / seed 增量合并后的权威数据），
   * 兜底 _notices（mockDB 未加载或全空时的内存态）。
   * 修复早期 init（header 渲染先于 loadDB）导致 _notices 滞留 seed 原版、
   * archived 等运行时字段丢失的问题。
   */
  _current() {
    const viewerId = _viewerPersonId();
    if (mockDB.notices && mockDB.notices.length > 0) {
      // Task 3（2026-10-25）：读口同样做幂等规范化（kind / archivedBy / 可解析坐标），
      // 历史行不必等到下次写回才具备消息对象模型。
      return mockDB.notices.map(n => _normalizeNotice(n, viewerId));
    }
    return this._notices;
  },

  /** 写操作前置对齐：以 mockDB.notices 为准刷新 _notices，避免基于旧内存态写回覆盖运行时字段 */
  _syncWithStore() {
    this._notices = [...this._current()];
  },

  list(filter = {}) {
    // 确保 _notices 已初始化（与 getAll() 一致，避免 list 在 init 前被调用返回空）
    if (this._notices.length === 0) {
      this.init();
    }
    // R2-49：先按**当前观看者**投影 read，再做受众/保留/排序/截断——
    // 未读角标与「已读重要通知收起」都自动按人计算。
    const viewerId = _viewerPersonId();
    let result = [...this._current()].map(n => _withViewerRead(n, viewerId));

    // 2026-08-08 归档闭环：默认排除已归档通知（随活动/专班归档退出工作区）
    // Task 3（2026-10-25）：逐人归档 `archivedBy[]` 同样让该条对本人退出默认列表（不影响其他收件人）。
    if (filter.includeArchived !== true) {
      result = result.filter(n => !n.archived && !(viewerId && _archivedByOf(n).includes(viewerId)));
    }

    // ── 受众门（2026-09-13 彻查批次：消费端统一过滤）─────────────────────────────
    // 背景（用户实报）：「支书的界面为什么会出现支书的催办？」根因＝消费端（铃铛/首页未读/角标/待办未读条）
    //   从未按受众过滤——签发人自己下发的催办又回到自己的未读里；且通知发布页所选受众（audience 数组）
    //   从未生效（选「党小组组长」实际全员可见）。
    // 规则：① audience 含 committee sentinel → 仅本支部支委层（党委下发通道，既有；见 NOTICE_AUDIENCE_SENTINELS）
    //       ② audience 为 sentinel 数组（发布侧写入「全体党员/党小组组长/入党积极分子/发展对象」）→
    //          经 NOTICE_AUDIENCE_SENTINELS 单一源判定（广播 sentinel 全员可见；roles/developStages 命中即可见）；
    //          未登记裸值回退角色键直比（兼容既有 audience:['org-commissioner'] 等写法）——Q-22-1 修正
    //       ③ audiencePersons 为 personId 数组 → 按人定向（2026-09-13 补：分工调整「信息自动传递」
    //          需把通知直接送到**到人负责人**，角色数组表达不了）
    //       ④ actionRoles 非空（行动性通知：催办/提醒/表决进度/分工履职等）→ 仅目标角色可见
    //       ⚠ 同一通知可**并存多种受众**（如「committee + audiencePersons + actionRoles」），
    //          命中任一即可见——原实现按 if/return 短路，committee 会吞掉其余受众。
    //       ⑤ 无受众/无 actionRoles → 全员可见（如活动通知广播）
    // 注：无登录会话（node 单测/匿名）时不收窄，保持既有行为。
    {
      const _me = AuthStore.getCurrentUser();
      const _role = _me && _me.role;
      const _myBranch = _me ? (getPersonById(_me.personId)?.branchId || DEFAULT_BRANCH_ID) : null;
      // 受众命中走单一源（Q-22-1）：sentinel 经 NOTICE_AUDIENCE_SENTINELS 判定，裸角色键回退直比
      const _ctx = _noticeViewerCtx(_me);
      const _hitPersons = (n) => _audiencePersonsHit(n, _ctx);
      const _hitRoles = (n) => _audienceHit(n, _ctx);
      const _hitActions = (n) => _audienceActionRolesHit(n, _ctx);
      // 党委台铃铛（scope:'committee'）下，党委组织员可读党委下发通道（audience 含 committee sentinel）——
      // ⚠ 这是「党委下发通道」的独立语义（source/scope），与「支委层受众」的 roles 判定分开；
      // 该角色不属于任何支部（branchId:null），故不做本支部比对；默认不传 scope 时保持原行为。
      const _staffCommitteeScope = filter.scope === 'committee' && _role === 'party-staff';
      result = result.filter((n) => {
        if (!_hasAudience(n)) return true;   // 广播
        if (!_role) return true;         // 无会话：不按受众收窄（保持既有行为）
        if (_staffCommitteeScope && _audienceSentinelPresent(n, 'committee')) return true;
        if (_audienceSentinelHit(n, 'committee', _ctx) && !!_myBranch && (n.branchId || DEFAULT_BRANCH_ID) === _myBranch) return true;
        if (_hitPersons(n) || _hitRoles(n) || _hitActions(n)) return true;
        return false;
      });
    }

    // ── 党委台视野（Task 28 · 2026-10-18）：顶栏铃铛与角标只取党委级通知 ─────────────
    // 口径（Task 28 · 2026-10-18）：党委下发 / 系统通知 / 发给本人的私信；支部内部广播不出现、不计入角标。
    // 仅对 party-staff 生效——其它角色即便误传 scope 也保持原行为（默认不传 = 原行为）。
    // 位置：受众门之后、retention 之前（先按可见性收窄，再做展示保留策略）。
    if (filter.scope === 'committee') {
      const _meScope = AuthStore.getCurrentUser();
      if (_meScope && _meScope.role === 'party-staff') {
        const _ctxScope = _noticeViewerCtx(_meScope);
        result = result.filter((n) => (
          n.source === 'committee'
          || _audienceSentinelPresent(n, 'committee')
          || _audiencePersonsHit(n, _ctxScope) // 发给本人的私信
        ));
      }
    }

    if (filter.activeOnly !== false) {
      const now = todayLocal();
      result = result.filter(n => !n.expireDate || n.expireDate >= now);
    }

    // 支书裁决（2026-08-05）：「未读的重要；无论已读未读的紧急」
    // 展示层保留策略：紧急通知全部保留展示，重要通知仅展示未读的（已读重要通知收起）。
    // 角标未读统计不走此过滤（仍统计全部未读），仅在列表展示处传 retention:'visible'。
    if (filter.retention === 'visible') {
      result = result.filter(n => n.priority === 'urgent' || !n.read);
    }

    if (filter.sortBy === 'date') {
      result.sort((a, b) => b.publishDate.localeCompare(a.publishDate));
    } else {
      const priorityOrder = { urgent: 0, normal: 1 };
      result.sort((a, b) => (priorityOrder[a.priority] || 1) - (priorityOrder[b.priority] || 1));
    }

    if (typeof filter.limit === 'number') {
      result = result.slice(0, filter.limit);
    }

    return result;
  },

  add(notice, actorRole = null, actorPersonId = null) {
    // 批次 353（`D-748`）：**站内信（`noticeType:'message'`）的发送权单列**——「支委层 ∪ 党小组组长」
    //   （`canSendDirectMessage`），与「全支部通知发布权」分列：私信不广播、不进支委层兜底可读，
    //   若沿用通用发布门，组长会被「本组通知＝本人是该场组织者」的判据挡在外面。
    const _isDirect = !!(notice && notice.noticeType === 'message');
    const _gate = _isDirect
      ? canSendDirectMessage(actorRole)
      : NoticePermission.check(actorRole, 'add', actorPersonId, notice);
    if (actorRole && !_gate) {
      console.warn(`[NoticeStore] 权限不足：角色 ${actorRole}（${actorPersonId || '未带 personId'}）无权${_isDirect ? '发站内信' : '发布通知'}`);
      return null;
    }
    // 人工发布路径（通知发布表单等）必传 actorRole，仍受白名单约束；
    // 2026-09-19 批次 91（SOP-B-17）：本组通知另按「此人是否该场组织者」放行（见 NoticePermission.canPublish）。
    // R-22（2026-09-13）：原「不传 actorRole 即打标 systemDerived」已随旧通道关闭而移除——
    //   系统派生通知改由 addSystem() 走服务端生成（POST /api/v1/system-notices）。
    // A05：有人类 actor 时补写发布人 / 创建人 id（供通知详情的「通知者」解析姓名；
    //   调用方已显式给出时不覆盖）。
    const actorPatch = actorPersonId
      ? { publisherId: notice.publisherId || actorPersonId, createdBy: notice.createdBy || actorPersonId }
      : {};
    const newNotice = {
      ...notice,
      ...actorPatch,
      id: notice.id || generateId('notice', '-'),
      publishDate: notice.publishDate || todayLocal(),
      kind: notice.kind || kindOf(notice),
      archivedBy: Array.isArray(notice.archivedBy) ? [...notice.archivedBy] : [],
    };
    this._syncWithStore();
    this._notices = [...this._notices, newNotice];
    _saveNotices(this._notices);
    // 行动性通知自动派生对应角色待办（最小三成本原则·阶段1C-2）
    try {
      NoticeTodoDeriver.deriveFromNotice(newNotice);
    } catch (e) {
      console.warn('[NoticeStore] 派生待办失败：', e);
    }
    return newNotice;
  },

  /**
   * 系统派生通知统一入口（R-22，2026-09-13）
   * 业务流程副作用（成员提交思想汇报、纪检确认考勤、赋权/表决进度、发起活动、专班/分工变更、
   * 党委下发等）不再由前端自述可信标记，而是：
   *   · mock 模式（无 API 会话）：复用与应用同一模板的本地 add()，演示/离线不受影响；
   *   · API 模式：POST /api/v1/system-notices，由服务端按 kind 注册表复算授权并生成文案/落点。
   * 失败时 console.warn 明确原因，不静默吞掉。
   * @param {string} kind 注册表 kind（见 docs/src/core/domain/system-notice-templates.js）
   * @param {string|null} sourceId 业务对象 id（服务端据此复算授权与落点）
   * @param {Object} [payload] 动态展示值（标题/正文/名称/计数等；不影响服务端安全判定）
   * @returns {Promise<Object|null>|Object|null} 新通知（失败返回 null）
   */
  addSystem(kind, sourceId = null, payload = {}) {
    const vars = { ...(payload || {}), sourceId };
    // ① 本地镜像（**同步**，批 17 回归修复）：多个界面读的是本地存储（下发历史、铃铛本地快照、
    //   以及「行动性通知 → 派生待办」），若只等服务端回包再并入，会出现「已提示下发成功但列表里没有」
    //   ——实测 party-committee-dispatch / online-committee 两用例因此失败。故先本地生成（与应用同一
    //   模板 system-notice-templates.js），再由服务端做权威复算与落库。
    let mirror = null;
    let built = null;
    try {
      built = buildSystemNotice(kind, vars);
    } catch (e) {
      console.warn(`[NoticeStore] 系统派生通知本地镜像失败（${kind}）：`, e);
    }
    // mock 模式（演示/离线）：无 API 会话 → 本地即权威（含"行动性通知→派生待办"，与既有行为一致）
    if (getDataSource() !== 'api' || !getAuthToken()) {
      return built ? this.add(built) : null;
    }
    // API 模式：仅做「可见性镜像」——**不在此派生待办**（成功后统一由服务端记录派生，避免同一通知派生两份待办）
    if (built) {
      mirror = {
        ...built,
        id: built.id || generateId('notice', '-'),
        publishDate: built.publishDate || todayLocal(),
      };
      this._syncWithStore();
      this._notices = [...this._notices, mirror];
      mockDB.notices = [...(mockDB.notices || []), mirror];
      // R4-F03/F02（2026-10-19）：**本地镜像不落快照**。系统派生通知的权威写口是
      //   POST /api/v1/system-notices（R-22 服务端复算授权）；镜像若随 persist() 整表写穿，
      //   会被快照 notices 写门按「非发布者新增通知」拒绝（普通成员提交思想汇报等正常路径会被连带卡住）。
      //   服务端回包后由下方以服务端记录替换镜像（该行在库里已存在，快照门自然放行）。
      bumpToken('notice');
    }
    // ② API 模式：服务端为权威（按 kind 复算授权、生成落点），失败则回收本地镜像
    return fetch(`${getApiBaseUrl()}/api/v1/system-notices`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getAuthToken()}` },
      body: JSON.stringify({ kind, sourceId, payload: payload || {} }),
    }).then(async (r) => {
      if (!r.ok) {
        const body = await r.json().catch(() => ({}));
        console.warn(`[NoticeStore] 系统派生通知发送失败（${kind}，HTTP ${r.status}）：${body.error || r.statusText}`);
        // 授权被拒/参数非法 → 回收本地镜像，避免留下"幻影通知"
        if (mirror) this._dropLocalNotice(mirror.id);
        return null;
      }
      const notice = await r.json();
      // ③ 以服务端记录替换本地镜像（同一逻辑通知只保留一条，避免列表重复）
      if (notice && notice.id) {
        if (mirror) this._dropLocalNotice(mirror.id);
        this._syncWithStore();
        if (!this._notices.some((n) => n.id === notice.id)) {
          this._notices = [...this._notices, notice];
          mockDB.notices = [...(mockDB.notices || []), notice];
          bumpToken('notice');
        }
        // 批次 504（R10-D02）：服务端插入系统通知会推进 `notices` 集合版本；本地若不把服务端真值并回来
        //   并推进基线，紧随其后的整表快照会「被自己刚写的那一版」挡成 409（用户看到假的「已被他人更新」）。
        //   `keepLocal:true`＝按 id 合并、本机行优先：本地未落库的通知不会被这次采用吞掉。
        try { await adoptCollectionFromServer('notices', { keepLocal: true }); } catch (e) {
          console.warn('[NoticeStore] 系统通知落库后采用服务端真值失败（下次快照走冲突恢复）：', e);
        }
        // 行动性通知本地派生对应角色待办（与 add() 一致；服务端仅存通知本身）
        try {
          NoticeTodoDeriver.deriveFromNotice(notice);
        } catch (e) {
          console.warn('[NoticeStore] 派生待办失败：', e);
        }
      }
      return notice;
    }).catch((e) => {
      console.warn(`[NoticeStore] 系统派生通知发送失败（${kind}）：`, e);
      if (mirror) this._dropLocalNotice(mirror.id);
      return null;
    });
  },

  /**
   * 回收本地镜像通知（仅本地存储；服务端未落库或已被服务端记录替换时调用）。
   * 注：派生的待办不做回收（错误路径极罕见，且回收待办涉及跨域写；已由 console.warn 明确留痕）。
   */
  _dropLocalNotice(id) {
    if (!id) return;
    this._syncWithStore();
    this._notices = this._notices.filter((n) => n.id !== id);
    mockDB.notices = (mockDB.notices || []).filter((n) => n.id !== id);
    _saveNotices(this._notices);
    bumpToken('notice');
  },

  update(id, patch, actorRole = null) {
    if (actorRole && !NoticePermission.check(actorRole, 'update')) {
      console.warn(`[NoticeStore] 权限不足：角色 ${actorRole} 无权编辑通知`);
      return null;
    }
    const idx = this._notices.findIndex(n => n.id === id);
    if (idx === -1) return null;
    const updated = { ...this._notices[idx], ...patch };
    this._notices = [
      ...this._notices.slice(0, idx),
      updated,
      ...this._notices.slice(idx + 1),
    ];
    _saveNotices(this._notices);
    return updated;
  },

  remove(id, actorRole = null) {
    if (actorRole && !NoticePermission.check(actorRole, 'remove')) {
      console.warn(`[NoticeStore] 权限不足：角色 ${actorRole} 无权删除通知`);
      return false;
    }
    this._syncWithStore();
    const prev = this._notices.length;
    this._notices = this._notices.filter(n => n.id !== id);
    if (this._notices.length === prev) return false;
    _saveNotices(this._notices);
    // 通知删除时联动删除关联待办（避免遗留孤儿待办）
    try {
      TodoStore.deleteBySource(TodoSourceType.NOTICE, id);
    } catch (e) {
      console.warn('[NoticeStore] 联动删除待办失败：', e);
    }
    return true;
  },

  getAll({ includeArchived = false } = {}) {
    if (this._notices.length === 0) this.init();
    const src = this._current();
    const viewerId = _viewerPersonId();
    const rows = includeArchived ? [...src] : [...src].filter(n => !n.archived);
    // R2-49：read 是观看者投影，不得把某人的已读状态当共享事实返回。
    return rows.map(n => _withViewerRead(n, viewerId));
  },

  /**
   * 按 id 取通知（S1 单一取数口，2026-09-12；Q-22-1 2026-09-13 脱离可见性门）：
   * 本函数**只负责「按 id 取数」**——含已归档/过期（不排除 archived，不按 expireDate 收窄）；
   * 未命中 → 从通知类待办按 id / sourceId / actionData.noticeId 现算重建（派生通知未持久化的兜底），
   * 使任一跳转入口（待办/铃铛/首页/通知发布）的 id 都能打开正文。
   * ⚠ 可见性判定**已移交 canReadNotice()**（详情页渲染前调用）——本函数不得再套消费端受众门，
   *   否则签发人/受众都取不到自己的通知（Q-22-1 根因之二：详情页 100% 打不开）。
   * @param {string} id
   * @returns {Object|null}
   */
  getById(id) {
    if (!id) return null;
    if (this._notices.length === 0) this.init(); // 与 list() 一致：确保初始化（_current 取 mockDB 优先、内存兜底）
    const found = this._current().find(n => n.id === id);
    if (found) return _withViewerRead(found, _viewerPersonId());
    try {
      const all = TodoStore.getAll();
      const todo = all.find(t => t && t.id === id)
        || all.find(t => t && t.sourceType === TodoSourceType.NOTICE && t.sourceId === id)
        || all.find(t => t && t.actionData && t.actionData.noticeId === id);
      return _noticeFromTodo(todo, id);
    } catch (e) {
      console.warn('[NoticeStore] 派生通知重建失败：', e);
      return null;
    }
  },

  /**
   * 归档与来源（活动/专班）绑定的通知（2026-08-08 归档闭环）
   * 活动/专班归档后，其配套通知随之一并归档，退出工作区。
   * @param {'activity'|'taskforce'} targetType
   * @param {string} targetId — activity.id 或 taskforce.id
   * @returns {number} 归档的通知条数
   */
  archiveBySource(targetType, targetId) {
    if (!targetType || !targetId) return 0;
    this._syncWithStore();
    let count = 0;
    this._notices = this._notices.map(n => {
      if (n.archived) return n;
      // targetType/targetId 精确匹配；或活动源通知经 targetUrl 携带 activityId 定位参数（如支书台 inspector 直达）——
      // 2026-09-05 补全：此类通知随活动归档不再成孤儿
      const urlCarriesActivity = targetType === 'activity' && typeof n.targetUrl === 'string'
        && n.targetUrl.includes(`activityId=${targetId}`);
      if ((n.targetType === targetType && n.targetId === targetId) || urlCarriesActivity) {
        count++;
        return { ...n, archived: true, archivedAt: todayLocal() };
      }
      return n;
    });
    if (count > 0) _saveNotices(this._notices);
    return count;
  },

  // ════════════════════════════════════════════════════════════════
  //  用户归档（逐人，可恢复）——Task 3 · 2026-10-25
  //  系统归档（archived=true，随活动归档 / 过期）与用户归档（archivedBy[]）分离：
  //  前者不可恢复，后者只影响本人，不改其他收件人的列表。
  // ════════════════════════════════════════════════════════════════

  /** 本人归档一条消息（系统归档不可再归档；已归档幂等） */
  archiveForViewer(id, on = true) {
    const viewerId = _viewerPersonId();
    if (!viewerId) { console.warn('[NoticeStore] 未登录，无法归档消息'); return false; }
    this._syncWithStore();
    const idx = this._notices.findIndex(n => n.id === id);
    if (idx === -1) return false;
    const row = this._notices[idx];
    if (row.archived === true || _isExpired(row)) return false; // 系统归档不可改
    const list = _archivedByOf(row);
    const has = list.includes(viewerId);
    if (on === has) return true;
    const next = { ...row, archivedBy: on ? [...list, viewerId] : list.filter(pid => pid !== viewerId) };
    this._notices = [...this._notices.slice(0, idx), next, ...this._notices.slice(idx + 1)];
    _saveNotices(this._notices);
    return true;
  },

  /** 本人恢复一条已归档消息（系统归档不可恢复 → false） */
  restoreForViewer(id) {
    return this.archiveForViewer(id, false);
  },

  /**
   * 消息中心统一读口（列表 / 角标 / 详情共用）。
   * box：all = 未归档（未读＋已读）；unread；read = 已读且未归档；archived = 本人或系统已归档。
   * q：标题 / 正文 / 对方姓名；source：announcement | system | message | all。
   * @returns {{ items:Object[], total:number, page:number, pageSize:number, pages:number }}
   */
  listMessages({ viewerId = null, box = 'all', source = 'all', q = '', page = 1, pageSize = 20, scope = null } = {}) {
    if (this._notices.length === 0) this.init();
    const me = AuthStore.getCurrentUser();
    const viewer = viewerId || _viewerPersonId();
    const viewerUser = viewer ? { ...(me || {}), personId: viewer } : me;
    const ctx = _noticeViewerCtx(viewerUser);
    // 可见性单一源 = canReadNotice（私信 / 定向 / sentinel 同一判据；发布者恒可读自己的私信）。
    // 不用 list()：list 的受众门没有「发布者恒可读」，会把本人发出的私信排除在消息中心之外。
    let rows = this.getAll({ includeArchived: true }).filter((n) => canReadNotice(n, viewerUser));
    // 党委台视野与 list(scope:'committee') 同口径（党委下发 / 党委 sentinel / 发给本人的私信）。
    if (scope === 'committee' && me?.role === 'party-staff') {
      rows = rows.filter((n) => (
        n.source === 'committee'
        || _audienceSentinelPresent(n, 'committee')
        || _audiencePersonsHit(n, ctx)
      ));
    }
    rows = rows.map((n) => {
      const inbound = kindOf(n) === 'message' && _audiencePersonsHit(n, ctx);
      const counterpartId = kindOf(n) === 'message'
        ? (inbound ? (n.fromPersonId || null) : ((n.audiencePersons || [])[0] || null))
        : null;
      return {
        ...n,
        kind: kindOf(n),
        read: _isReadBy(n, viewer),
        archivedForViewer: _archivedForViewer(n, viewer),
        ownOutbound: _isOwnOutboundMessage(n, viewer, ctx),
        counterpartId,
        counterpartName: counterpartId ? (getPersonName(counterpartId) || counterpartId) : '',
        sortTime: String(n.createdAt || n.publishDate || ''),
      };
    }).filter((n) => {
      if (source && source !== 'all' && n.kind !== source) return false;
      if (box === 'archived') return n.archivedForViewer;
      if (n.archivedForViewer) return false;
      if (box === 'unread') return !n.read && !n.ownOutbound;
      if (box === 'read') return n.read;
      return true; // all
    }).filter((n) => {
      const keyword = String(q || '').trim().toLowerCase();
      if (!keyword) return true;
      return [n.title, n.content, n.counterpartName].some((value) => String(value || '').toLowerCase().includes(keyword));
    }).sort((a, b) => b.sortTime.localeCompare(a.sortTime));

    const size = Math.max(1, Number(pageSize) || 20);
    const total = rows.length;
    const pages = Math.max(1, Math.ceil(total / size));
    const cur = Math.min(Math.max(1, Number(page) || 1), pages);
    return { items: rows.slice((cur - 1) * size, cur * size), total, page: cur, pageSize: size, pages };
  },

  /** 未读数（列表 / 角标 / 铃铛同一读数；私信自己的发件不计未读） */
  countUnread(viewerId = null, extra = {}) {
    const viewer = viewerId || _viewerPersonId();
    return this.listMessages({ viewerId: viewer, box: 'unread', pageSize: 100000, ...extra }).total;
  },

  /** 私信会话线程：同一 replyTo 根链上的全部可见消息，按时间升序。 */
  messageThreadOf(id) {
    if (!id) return [];
    const me = AuthStore.getCurrentUser() || {};
    if (!me.role) return [];
    const all = this.getAll({ includeArchived: true })
      .filter((n) => kindOf(n) === 'message' && canReadNotice(n, me));
    const byId = new Map(all.map((n) => [n.id, n]));
    const rootOf = (n) => {
      let cur = n;
      const seen = new Set();
      while (cur && cur.replyTo && byId.has(cur.replyTo) && !seen.has(cur.id)) {
        seen.add(cur.id);
        cur = byId.get(cur.replyTo);
      }
      return cur ? cur.id : n.id;
    };
    const current = byId.get(id);
    if (!current) return [];
    const root = rootOf(current);
    return all
      .filter((n) => rootOf(n) === root)
      .sort((a, b) => String(a.createdAt || a.publishDate || '').localeCompare(String(b.createdAt || b.publishDate || '')));
  },

  markRead(id) {
    const me = AuthStore.getCurrentUser();
    const viewerId = _viewerPersonId();
    // 写口纪律：无会话不得写共享记录，也不得销任何人的待办（B-499-3）
    if (!viewerId) {
      console.warn('[NoticeStore] 未登录，无法标记已读；请重新登录');
      return false;
    }
    this._syncWithStore();
    const notice = this._notices.find(n => n.id === id);
    if (notice) {
      const reads = _readsOf(notice);
      if (!reads.includes(viewerId)) {
        // R2-49：只把当前人追加进 reads；绝不写回全局 read（否则广播通知会全员已读）
        notice.reads = [...reads, viewerId];
        delete notice.read;
        _saveNotices(this._notices);
      }
    } else {
      // S1：派生通知（未持久化）确认读取 → 只销**本人 / 本角色**的通知待办
      try {
        const todo = TodoStore.getById(id);
        const mine = !!todo && (todo.personId
          ? String(todo.personId) === String(viewerId)
          : (!!todo.role && !!me && todo.role === me.role));
        if (mine) TodoStore.complete(id);
      } catch (e) { console.warn('[notice] 派生通知销待办失败', e); }
    }
    // 做事即销待办：已读自动完成「本人 / 本角色」的「通知阅读」待办（不跨角色）
    try {
      TodoStore.completeBySource(TodoSourceType.NOTICE, id, {
        personId: viewerId,
        role: me ? me.role : undefined,
      });
    } catch (e) { console.warn('[notice] 销待办失败', e); }
    return true;
  },

  /** 全部已读：只作用于「当前人可见、未归档、未读」的消息；系统归档 / 用户归档不参与。 */
  markAllRead(viewerId = null) {
    const viewer = viewerId || _viewerPersonId();
    if (!viewer) {
      console.warn('[NoticeStore] 未登录，无法全部标记已读；请重新登录');
      return false;
    }
    // 可见性单一源 = 消息中心列表（canReadNotice 投影；与列表同源）。
    const visible = new Set(this.listMessages({ viewerId: viewer, box: 'all', pageSize: 100000 }).items.map(n => n.id));
    this._syncWithStore();
    this._notices = this._notices.map(n => {
      if (!visible.has(n.id)) return n;
      if (_archivedForViewer(n, viewer)) return n;
      const reads = _readsOf(n);
      if (reads.includes(viewer)) return n;
      const next = { ...n, reads: [...reads, viewer] };
      delete next.read;
      return next;
    });
    _saveNotices(this._notices);
    return true;
  },
};

/**
 * 是否可读某条通知（详情页读取权限，单一源，Q-22-1 2026-09-13）
 *
 * 规则：
 *   ① 无受众 / 广播 sentinel（all）→ 人人可读（含无登录会话）；
 *   ② 无登录会话 → 仅广播/无受众可读（上一步已返回）；
 *   ③ 党委组织员（party-staff）可读党委级通知（source/audience 命中 committee）；
 *   ④ 发布者恒可读（签发人不应被自己的定向通知挡在门外）；
 *   ⑤ 支委层（BRANCH_COMMISSION_ROLES）可读（治理信息）；
 *   ⑥ 命中受众（audience sentinel / 裸角色键 / audiencePersons / actionRoles）可读；
 *   ⑦ 其余不可读。
 * 判定复用 list() 受众门**同一套** sentinel 判定（_audienceHit 等，勿写第二套规则）。
 * 注：本函数与 getById() 分工——getById 只取数、本函数判可见性（详情页渲染前调用）。
 * @param {Object} notice 通知对象
 * @param {{ personId?:string, role?:string }|null} [viewer] 观看者；缺省取当前登录会话
 * @returns {boolean}
 */
export function canReadNotice(notice, viewer) {
  const n = notice;
  if (!n) return false;
  const ctx = _noticeViewerCtx(viewer === undefined ? AuthStore.getCurrentUser() : viewer);
  // ⑥ **站内信（`noticeType:'message'`，点对点 / 点对多人 私信）——批次 348**：
  //    可见性＝**仅发件人 ＋ 收件人**。此判**必须先于**下面的「支委层可读任意通知」兜底——
  //    否则一条两人私信会被全体支委读到，与私信语义直接冲突。
  //    私信以 `audiencePersons` 承载收件人（发送时**逐人 fan-out**成每人一条，故逐人 reads 语义正确）。
  if (n.noticeType === 'message') {
    if (!ctx.role) return false;                       // 无会话 → 不可读（私信不广播）
    return _isPublisher(n, ctx) || _audiencePersonsHit(n, ctx);
  }
  if (!_hasAudience(n) || _isBroadcastAudience(n)) return true; // ① 无受众 / 广播 → 人人可读
  if (!ctx.role) return false;                                  // ② 无登录会话：仅广播/无受众
  // ③ 党委组织员（party-staff）可读党委下发通道（audience 含 committee sentinel）——
  //    与 list() 受众门同口径；否则顶栏铃铛可见、点开详情却「不可读」。
  if (ctx.role === 'party-staff'
    && (n.source === 'committee' || _audienceSentinelPresent(n, 'committee'))) return true;
  if (_isPublisher(n, ctx)) return true;                        // ④ 发布者恒可读
  if (BRANCH_COMMISSION_ROLES.includes(ctx.role)) return true;  // ⑤ 支委层可读
  return _audiencePersonsHit(n, ctx)                            // ⑥ 命中受众可读
    || _audienceHit(n, ctx)
    || _audienceActionRolesHit(n, ctx);
}

// ════════════════════════════════════════════════════════════════
//  站内信（点对点私信）读写口 —— 2026-10-03 批次 353 · 支书 `D-748`
//  · **发送权**：**全体成员**（批次 406 · `D-793` 改裁——原为「支委层 ∪ 党小组组长」）——与通用发布权分列，见 `add()` 注。
//  · **可见性**：仅发件人与收件人（`canReadNotice` ⑥，批次 348 已立；此处**复用、不另写规则**）。
//  · **回复线程**：回信＝一条新私信 ＋ `replyTo` 指向原信 ⇒ 「一来一往」成线（不新造实体）。
// ════════════════════════════════════════════════════════════════

/** 站内信发送权（批次 406 · `D-793`：**全体登录成员**；原「支委层 ∪ 党小组组长」已放开）——单一源，供页面与 `add()` 同判 */
export function canSendDirectMessage(role) {
  return !!role;
}

/** 我的私信（**收件 ＋ 发件**两条线，按时间倒序）。
 *  取数走 `getAll()`（不过消费端受众门）＋ 逐条 `canReadNotice`（私信＝仅收发双方）——
 *  单一源判可见性，**不另写一套规则**；`direction` / `counterpartId` 供页面直接消费。 */
export function listMyMessages() {
  const me = AuthStore.getCurrentUser() || {};
  if (!me.role) return [];
  const ctx = _noticeViewerCtx(me);
  return NoticeStore.getAll({ includeArchived: false })
    .filter((n) => n.noticeType === 'message' && canReadNotice(n, me))
    .map((n) => {
      const inbound = _audiencePersonsHit(n, ctx);
      return {
        ...n,
        direction: inbound ? 'in' : 'out',
        counterpartId: inbound ? (n.fromPersonId || null) : ((n.audiencePersons || [])[0] || null),
      };
    })
    .sort((a, b) => String(b.createdAt || b.publishDate || '').localeCompare(String(a.createdAt || a.publishDate || '')));
}

/** 发私信（逐人 fan-out：每人一条、`audiencePersons:[该人]`；`D-748` 发送权＝支委层 ∪ 组长）。
 *  与批次 348 支书台「指定人（私发）」**同一写形**（含 `createdAt` 供同日内排序）。返回生成的条数。 */
export function sendDirectMessage({ title, content, toPersonIds, actorRole, actorPersonId, replyTo = null } = {}) {
  const me = AuthStore.getCurrentUser() || {};
  const role = actorRole || me.role;
  const pid = actorPersonId || me.personId || null;
  const ids = (Array.isArray(toPersonIds) ? toPersonIds : []).filter(Boolean);
  const _title = String(title || '').trim();
  const _content = String(content || '').trim();
  if (!canSendDirectMessage(role) || !_title || !_content || ids.length === 0) return 0;
  let sent = 0;
  for (const to of ids) {
    const made = NoticeStore.add({
      title: _title,
      content: _content,
      priority: 'normal',
      publishDate: todayLocal(),
      expireDate: null,
      targetModule: 'workspace',
      // D13：新写入不再带全局 `read` 布尔（逐人已读走 reads）
      noticeType: 'message',
      fromPersonId: pid,
      audiencePersons: [to],
      audienceLabel: '指定人（私发）',
      createdAt: new Date().toISOString(),
      ...(replyTo ? { replyTo } : {}),
    }, role, pid);
    if (made) sent++;
  }
  return sent;
}

/** 回复一条私信（`D-748` 回复线程）：回信＝我 → 原信对方的一条新私信，`replyTo` 指向原信。
 *  原信收件人（inbound）回复 → 对方＝发件人；原信发件人（outbound）回复 → 对方＝收件人。 */
export function replyToMessage(originalId, { title, content, actorRole, actorPersonId } = {}) {
  const me = AuthStore.getCurrentUser() || {};
  const role = actorRole || me.role;
  const pid = actorPersonId || me.personId || null;
  const orig = NoticeStore.getById(originalId);
  if (!orig || orig.noticeType !== 'message' || !canReadNotice(orig, me)) return 0;
  const ctx = _noticeViewerCtx(me);
  const counterpartId = _audiencePersonsHit(orig, ctx)
    ? (orig.fromPersonId || null)
    : ((orig.audiencePersons || [])[0] || null);
  if (!counterpartId) return 0;
  const _title = String(title || '').trim() || (orig.title ? `回复：${orig.title}` : '回复');
  return sendDirectMessage({
    title: _title, content, toPersonIds: [counterpartId], actorRole: role, actorPersonId: pid, replyTo: originalId,
  });
}

// ════════════════════════════════════════════════════════════════
//  通知模块 → 角色页映射（2026-08-06 立；2026-10-25 批次 510 起只服务工作台内跳转）
//  `resolveNoticeUrl` 的页面级兜底与 `direct` 直跳已随 A 统一消息中心退役（Q-14 死码清理）：
//  所有消息入口统一 `notice.html?id=`，对象跳转由详情页内的唯一动作承担。
//   消费者：components/record/todo-tab-shell.js（催办 / 履职待办落本角色工作台）。
// ════════════════════════════════════════════════════════════════

// targetModule → 业务页（角色感知）：模块语义决定业务落点
//  - activity（活动/主题党日）→ 首页活动日历（全员统一活动视图）
//  - attendance（考勤）→ 纪检委员考勤管理 / 支书考勤概况
//  - party（发展党员/考察）→ 组织委员档案与发展党员 / 纪检委员考察管理 / 支书工作台
//  - workspace（工作部署/筹备）→ 支委各归其位 / 组长工作台 / 其余首页
// A①（2026-09-10）：导出供工作台自跳复用同一映射（`todo-tab-shell.js` 催办 / 履职落点）。
export const NOTICE_MODULE_ROLE_PAGES = {
  activity: {
    '*': 'index.html',
  },
  attendance: {
    'disc-commissioner': 'workspace/disc.html',
    'secretary': 'workspace/secretary.html',
    'deputy-secretary': 'workspace/secretary.html',
    '*': 'index.html',
  },
  party: {
    'org-commissioner': 'workspace/org.html',
    'disc-commissioner': 'workspace/disc.html',
    'secretary': 'workspace/secretary.html',
    'deputy-secretary': 'workspace/secretary.html',
    '*': 'index.html',
  },
  workspace: {
    'secretary': 'workspace/secretary.html',
    'deputy-secretary': 'workspace/secretary.html',
    'org-commissioner': 'workspace/org.html',
    'prop-commissioner': 'workspace/prop.html',
    'disc-commissioner': 'workspace/disc.html',
    'leader': 'workspace/leader.html',
    '*': 'index.html',
  },
};

/** P3 党委下发来源徽标（红底白字，与支部自发的通知区分；下发=党委→支委层治理通道） */
