// role: [工程师]+[AI]
// services/branch/branch.js — 支部服务（P1 党委后台，2026-09-02）
// 支部边界收敛点（防止未同步的情况）：人→支部归属、支部配置档案读取（header 软编码/主题/启停模块）
// 单一数据源：mockDB.branches（首启 seed 自 data/mock/branches.js BRANCHES）

import { mockDB } from '../../core/domain/domain.js?v=20261028b';
import { getPersonById } from '../member/person.js?v=20261028b';
import { PARTY_COMMITTEE, DEFAULT_BRANCH_DISPLAY_NAME } from '../../data/mock/branches.js?v=20261028b';
import { PEOPLE } from '../../data/mock/people.js?v=20261028b';
import { getAdapter, persist, getDataSource } from '../../data/data-adapter.js?v=20261028b';
import { listCapabilities } from '../../core/boot/registry.js?v=20261028b';
// P1a 单向权威（2026-09-03）：config 净化唯一实现 = services/branch/config-clean.js（server PATCH /branches/:id/config 同源）
import { sanitizeConfigBlocks, sanitizeConfigModules, sanitizeConfigWorkforce, sanitizeConfigOrg, sanitizeConfigPolicyOverrides, sanitizeConfigCapabilityPackages, applyBranchPolicyOverrides } from './config-clean.js?v=20261028b';
import { CAPABILITY_PACKAGES, disabledCapabilityChildIds } from '../../core/domain/capability-packages.js?v=20261028b';
// 审计内核共享常量（2026-09-09 支书批）：why 透传/单键回滚白名单/历史上限单一源 = config-clean
// （server resources.js 同源 import，双形态防止未同步的情况）
import { CONFIG_HISTORY_MAX, CONFIG_ROLLBACK_WHAT, CONFIG_ROLLBACK_KEYS } from './config-clean.js?v=20261028b';
// L4（2026-09-03）：支部工作地图模块目录单一源 = core/domain/work-map.js（14 模块/缺省分工/快照展开）
import { expandWorkforce } from '../../core/domain/work-map.js?v=20261028b';
// 批4（2026-09-09 支书批「域参数」）：policyOverrides 顶层节白名单（覆盖写口校验用）
import { POLICY_DEFAULTS, POLICY_OVERRIDE_SECTIONS, effectivePolicyWith, policySectionsByRole } from '../../core/domain/policy-defaults.js?v=20261028b';
import { randomHex } from '../../core/base/id.js?v=20261028b';
// 核心组判定单一源（2026-09-14 支书裁定·tab 全盘重设）：由「显示标签反推」改为「注册表 coreTab 显式声明」
import { DEFAULT_BRANCH_ID, isCoreTab } from '../../core/domain/constants.js?v=20261028b';

export function getBranchById(branchId) {
  return (mockDB.branches || []).find(b => b.id === branchId) || null;
}

/**
 * 补取支部完整档案（api 形态；D-825 批次 501）
 * 党委目录行（GET /branches 未选中支部）只投影 id/name/type/status + config.headerTitle，
 * 向导要读写 modules/blocks/capabilityPackages——必须换成该支部完整行，否则「保存成功 → 重进向导」读不到配置。
 * mock 形态全量在内存，直接返回。
 */
export async function ensureBranchConfigLoaded(branchId) {
  const row = getBranchById(branchId);
  if (!branchId || getDataSource() !== 'api') return row;
  // 已有 headerTitle 之外的配置键 = 完整行（如页面 URL 带 branchId 由全量快照恢复）
  if (Object.keys(row?.config || {}).some((k) => k !== 'headerTitle')) return row;
  try {
    const rows = await getAdapter().branches.list({ branchId });
    const full = (rows || []).find((r) => r && r.id === branchId);
    if (!full) return getBranchById(branchId);
    const patch = { ...full };
    delete patch.summary; // 目录统计不是支部档案字段
    const list = mockDB.branches || (mockDB.branches = []);
    const idx = list.findIndex((b) => b.id === branchId);
    if (idx >= 0) list[idx] = { ...list[idx], ...patch };
    else list.push(patch);
  } catch (e) {
    console.warn('[branch] 支部完整配置读取失败（沿用目录行）', branchId, e);
  }
  return getBranchById(branchId);
}

// ── 工作流模块配置 L2（2026-09-03 支书裁定：支部自治/支书操作/清单+画布并用/tab 级/核心固定）──
// config.modules = { hiddenTabIds: string[], tabOrder: string[] }；null = 默认全开（兼容现有演示）。
// 核心组 tab（注册表显式声明 coreTab: true：今天/待办/概况等，支书 2026-08-10 裁定全员必有）固定显示、
// 不可隐藏、不参与排序；业务组（我的职责/知情查看/制度与答复…）可隐藏、可按画布顺序调整。
// （2026-09-14 前以「显示标签 groupLabel 内容为『工作台』」反推，现改显式声明，见 core/domain/constants.js::isCoreTab）

/** 支部可勾选的工作流能力目录（派生自能力注册表 workspace:* 能力 + 其 tab 元数据；画布/清单数据源） */
export function listBranchModuleCatalog() {
  const { items } = listCapabilities({});
  return items
    .filter(cap => Array.isArray(cap.scope) && cap.scope.some(s => String(s).startsWith('workspace:')))
    .map(cap => ({
      capId: cap.id,
      name: cap.name,
      tabs: (typeof cap.tabs === 'function' ? cap.tabs() : [])
        .map(t => ({ id: t.id, label: t.label, groupLabel: t.groupLabel, coreTab: t.coreTab === true })),
    }));
}

/** 由 config.modules 解析策略：{ hidden:Set(tabId), order:string[]|null }（null order=沿用注册顺序） */
export function getTabPolicy(modules) {
  return {
    hidden: new Set(Array.isArray(modules?.hiddenTabIds) ? modules.hiddenTabIds : []),
    order: Array.isArray(modules?.tabOrder) && modules.tabOrder.length ? [...modules.tabOrder] : null,
  };
}

/** 支部工作流模块策略（读 mockDB.branches；纯判定见 getTabPolicy） */
export function getBranchTabPolicy(branchId) {
  return getTabPolicy(getBranchById(branchId)?.config?.modules);
}

/** 支部选用的业务能力包；旧配置未显式记录时按兼容默认启用。 */
export function getBranchCapabilityPackageState(branchId) {
  const saved = getBranchById(branchId)?.config?.capabilityPackages?.packages || {};
  return Object.fromEntries(CAPABILITY_PACKAGES.map((definition) => [
    definition.id, saved[definition.id]?.enabled !== false,
  ]));
}

/** tab 分类：核心组（注册表显式声明 coreTab）固定；业务组可配置 */
function _splitTabs(tabs) {
  const core = tabs.filter(isCoreTab);
  const coreIds = new Set(core.map(t => t.id));
  const business = tabs.filter(t => !coreIds.has(t.id));
  return { core, business };
}

/**
 * 纯函数：按 config.modules 过滤/排序工作台 tab（不读全局状态，便于单测与复用）
 * 核心组保持注册顺序置于前；业务组过滤 hidden 后按 tabOrder 排序（新注册 tab 若不在 order → 尾部）。
 */
export function applyTabPolicyPure(tabs, modules) {
  const { hidden, order } = getTabPolicy(modules);
  const { core, business } = _splitTabs(tabs);
  const visible = business.filter(t => !hidden.has(t.id));
  if (order && order.length) {
    const idxMap = new Map(order.map((id, i) => [id, i]));
    visible.sort((a, b) => {
      const ia = idxMap.has(a.id) ? idxMap.get(a.id) : Infinity;
      const ib = idxMap.has(b.id) ? idxMap.get(b.id) : Infinity;
      return ia - ib;
    });
  }
  return [...core, ...visible];
}

/**
 * 按支部策略过滤/排序工作台 tab（渲染侧收敛点：workspace-shell 构建 tab bar 前调用一次）
 */
export function applyTabPolicy(tabs, branchId, role = null) {
  const branch = getBranchById(branchId);
  const modules = branch?.config?.modules;
  // 停用能力包只停止新建；页签仍承载在办事项的完成与历史查阅，不能随开关一起隐藏。
  // `role` 保留为调用兼容参数；页面级新建入口与服务端写口各自检查包状态。
  return applyTabPolicyPure(tabs, modules);
}

// ── 活动产出块策略（块画布 v0，2026-09-03）────────────────────────────────────
// config.blocks = { outputBlocks: { hiddenBlockIds, blockOrder } }；null=默认全开。
// 目录单一源：core/constants OUTPUT_BLOCK_DEFS（attendance/inspection/publicity/materials）。

/** 解析产出块策略：{ hidden:Set, order:string[]|null }（纯） */
export function getOutputBlockPolicy(blocks) {
  const cfg = blocks?.outputBlocks;
  return {
    hidden: new Set(Array.isArray(cfg?.hiddenBlockIds) ? cfg.hiddenBlockIds : []),
    order: Array.isArray(cfg?.blockOrder) && cfg.blockOrder.length ? [...cfg.blockOrder] : null,
  };
}

/** 读支部产出块配置（null=全开） */
export function getBranchOutputBlocks(branchId) {
  const raw = getBranchById(branchId)?.config?.blocks ?? null;
  const state = getBranchCapabilityPackageState(branchId);
  const hiddenOutputIds = disabledCapabilityChildIds(state, 'outputBlockIds');
  const hiddenWorkflowIds = disabledCapabilityChildIds(state, 'workflowBlockIds');
  if (!hiddenOutputIds.length && !hiddenWorkflowIds.length) return raw;
  const blocks = raw && typeof raw === 'object' ? raw : {};
  const outputHidden = new Set(blocks.outputBlocks?.hiddenBlockIds || []);
  const workflowHidden = new Set(blocks.workflowBlocks?.hiddenBlockIds || []);
  hiddenOutputIds.forEach((id) => outputHidden.add(id));
  hiddenWorkflowIds.forEach((id) => workflowHidden.add(id));
  return {
    ...blocks,
    outputBlocks: { ...(blocks.outputBlocks || {}), hiddenBlockIds: [...outputHidden] },
    workflowBlocks: { ...(blocks.workflowBlocks || {}), hiddenBlockIds: [...workflowHidden] },
  };
}

/**
 * 按支部自定义 order 重排 id 列表（纯）——产出块 / 工作流块**共用单一实现**。
 * 语义：order 内出现的靠前，未出现的保持传入原序、统一排在已列出者之后
 * （Infinity 同值 ⇒ 依赖 Array.sort 稳定性保持原序）。
 * @param {string[]} defIds - 注册目录顺序的 id 列表
 * @param {string[]|null} order - 支部自定义顺序（null/空 ⇒ 原样返回）
 */
export function orderByIds(defIds, order) {
  if (!Array.isArray(order) || !order.length) return defIds.slice();
  const idx = new Map(order.map((id, i) => [id, i]));
  return defIds.slice().sort((a, b) => {
    const ia = idx.has(a) ? idx.get(a) : Infinity;
    const ib = idx.has(b) ? idx.get(b) : Infinity;
    return ia - ib;
  });
}

/** 按支部产出块策略过滤/排序块 id 列表（纯：传 defIds + config.blocks） */
export function applyOutputBlockPolicy(defIds, blocks) {
  const { hidden, order } = getOutputBlockPolicy(blocks);
  return orderByIds(defIds.filter(id => !hidden.has(id)), order);
}

// ── 工作流块策略（L3 S3，2026-09-03 支书裁定：config.blocks 增 workflowBlocks）──────
// config.blocks.workflowBlocks = { hiddenBlockIds: string[], blockOrder?: string[] }；null/缺省=全开、注册顺序。
// L3「流程组合」（2026-09-28 批次 246，支书定「块差异＝流程组合」）：**启停 ＋ 顺序** 两个面都归支部可配——
//   顺序复用上方 orderByIds 单一实现（与产出块同口径，不再另写排序）。
// 目录单一源：workflow/blocks/manifests.js BLOCK_MANIFESTS（主题党日/专班等整条 SOP 入口块）。

/** 解析工作流块策略：{ hidden:Set, order:string[]|null }（纯） */
export function getWorkflowBlockPolicy(blocks) {
  const cfg = blocks?.workflowBlocks;
  return {
    hidden: new Set(Array.isArray(cfg?.hiddenBlockIds) ? cfg.hiddenBlockIds : []),
    order: Array.isArray(cfg?.blockOrder) && cfg.blockOrder.length ? cfg.blockOrder : null,
  };
}

/** 按支部工作流块策略过滤 / 排序块 id 列表（纯：传 defIds + config.blocks） */
export function applyWorkflowBlockPolicy(defIds, blocks) {
  const { hidden, order } = getWorkflowBlockPolicy(blocks);
  return orderByIds(defIds.filter(id => !hidden.has(id)), order);
}

// ── ② 表单条目轴：块级「字段策略」（契约 §8.2，2026-09-29 批次 275）──────────────
// config.blocks.workflowBlocks.fieldPolicies ＝ { [blockId]: { hiddenFieldIds, requiredOverrides } }
// 读侧与 `getWorkflowBlockPolicy` **同族**（同取 config.blocks.workflowBlocks 段）；净化单一实现
//   ＝ `services/branch/config-clean.js::cleanFieldPolicies`（勿在别处另写净化）。
// 语义：支部可配面**只开两类**——字段启停 ＋ 必填覆盖；第三类（重命名/重排/新增）不开。

/** 解析某块的字段策略：{ hidden:Set, requiredOverrides:Object }（纯；无配置=全开、维持 manifest 必填） */
export function getWorkflowBlockFieldPolicy(blockId, blocks) {
  const pol = blocks?.workflowBlocks?.fieldPolicies?.[blockId];
  return {
    hidden: new Set(Array.isArray(pol?.hiddenFieldIds) ? pol.hiddenFieldIds : []),
    requiredOverrides: (pol?.requiredOverrides && typeof pol.requiredOverrides === 'object' && !Array.isArray(pol.requiredOverrides))
      ? pol.requiredOverrides : {},
  };
}

/**
 * 按字段策略对齐一份 manifest 声明字段（纯）：过滤被隐藏项、按 requiredOverrides 覆盖必填。
 * `carrier:'template-card'` 条目**本就不在 Step2 呈现**（由 Step1 模板卡承担），一律不进结果——
 * 这正是 §8.2「声明 ↔ 实现不再有第三态」的落点。
 * @param {Array} fields manifest.inputs.fields
 * @param {string} blockId
 * @param {Object|null} blocks config.blocks
 */
export function applyWorkflowBlockFieldPolicy(fields, blockId, blocks) {
  const { hidden, requiredOverrides } = getWorkflowBlockFieldPolicy(blockId, blocks);
  return (Array.isArray(fields) ? fields : [])
    .filter((f) => f && f.carrier !== 'template-card' && !hidden.has(f.fieldId))
    .map((f) => (Object.prototype.hasOwnProperty.call(requiredOverrides, f.fieldId)
      ? { ...f, required: !!requiredOverrides[f.fieldId] } : f));
}

// ── ③ 参与人范围轴：块级「名单解析模式」（契约 §8.3，2026-09-29 批次 275）──────────
// config.blocks.workflowBlocks.participantPolicies ＝ { [blockId]: { mode?, orgMode? } }
// 读侧与字段策略同族；净化单一实现 ＝ `services/branch/config-clean.js::cleanParticipantPolicies`。
// ⚠ 本轴**只配「解析模式」，具体人名一律不落 config**（§8.3）；缺省（无覆盖）= 取 manifest 声明。
/** 解析某块的「名单解析模式」覆盖：{ mode?, orgMode? }（纯；无覆盖 ⇒ {}） */
export function getWorkflowBlockParticipantPolicy(blockId, blocks) {
  const pol = blocks?.workflowBlocks?.participantPolicies?.[blockId];
  if (!pol || typeof pol !== 'object' || Array.isArray(pol)) return {};
  const out = {};
  if (pol.mode === 'fixed' || pol.mode === 'configurable') out.mode = pol.mode;
  if (pol.orgMode === 'none' || pol.orgMode === 'organizer-deep') out.orgMode = pol.orgMode;
  return out;
}

/** 产出块配置净化（outputBlocks/workflowBlocks；null=恢复默认）——单一实现 = services/branch/config-clean.js sanitizeConfigBlocks（2026-09-03 P1a 收口，勿另写） */
function _sanitizeBlocks(blocks) {
  return sanitizeConfigBlocks(blocks);
}

/** 保存支部产出块配置（支书/副支书操作，副书同权 2026-09-09 支书批；blocks=null=恢复默认；opts.why=依据出处） */
export async function updateBranchBlocks(branchId, blocks, opts = {}) {
  return updateBranchModules(branchId, undefined, [], blocks, opts);
}

/** 核心 tab id 集合（供配置 UI 展示「固定」与隐藏校验） */
export function getCoreTabIds(tabs) {
  return _splitTabs(tabs).core.map(t => t.id);
}

// ── 配置变更留痕（2026-09-06 换组织向导支书 R4：即时生效 + 留痕，低频可回滚）─────────
// config.configChangeHistory: Array<{ by, at, what, from?, to?, why? }>——谁/何时/改了什么配置键。
// 2026-09-09 支书批「审计内核」：why=依据/出处（可选，来源页回填如 REVIEW_QUEUE 附录编号；
//   默认 undefined 不写、向后兼容）；保留上限 CONFIG_HISTORY_MAX（追加即裁剪最早）；
//   what ∈ CONFIG_ROLLBACK_KEYS（单一源 = config-clean）的单键留痕可回滚（见 rollbackBranchConfig）。
// 现有审计风格对照：roster.saveResidenceChange.residenceHistory（{from,to,updatedBy,updatedAt}）
// 与 auth 赋权快照（authorizedBy/authorizedAt）——本域取 {by,at,what,from,to}（任务口径）。
// 操作者取登录快照 personId：与 services/core/auth.js LOGIN_KEY 同键（跨模块约定，避免 import auth 循环依赖）。
function _actorId() {
  try {
    if (typeof localStorage === 'undefined') return null;
    const raw = localStorage.getItem('gsm1921-login-user');
    if (!raw) return null;
    const d = JSON.parse(raw);
    return d.personId || d.userId || d.id || null;
  } catch (_) { return null; }
}

/** 配置键等值比较（undefined/null 归一；对象按 JSON 序） */
function _sameConfigVal(a, b) {
  return JSON.stringify(a ?? null) === JSON.stringify(b ?? null);
}

/** 裁剪留痕至 CONFIG_HISTORY_MAX（保留最近 N 条、丢弃最早；返回新数组） */
function _trimHistory(history) {
  return history.length > CONFIG_HISTORY_MAX ? history.slice(-CONFIG_HISTORY_MAX) : history;
}

/** 单条留痕构造（可选 why 透传；空串/undefined 不写键） */
function _historyRow(by, at, what, from, to, why) {
  const row = { by, at, what, from, to };
  if (why !== undefined && why !== null && String(why).trim()) row.why = String(why).trim();
  return row;
}

/** 统一写配置（modules/blocks/workforce 共用：adapter 落库 + mock 同步 + persist；opts.why=依据出处） */
async function _saveBranchConfig(branchId, payload, opts = {}) {
  const cur = getBranchById(branchId);
  const prev = cur?.config || {};
  const at = new Date().toISOString();
  const by = _actorId();
  const why = (opts && opts.why) || undefined;
  let history = Array.isArray(prev.configChangeHistory) ? [...prev.configChangeHistory] : [];
  // 留痕：payload 各配置键相对旧值有实质变化才追加（重复保存不产生冗余条目）
  for (const [key, to] of Object.entries(payload)) {
    if (key === 'configChangeHistory') continue;
    const from = prev[key] ?? null;
    const next = to ?? null;
    if (!_sameConfigVal(from, next)) history.push(_historyRow(by, at, key, from, next, why));
  }
  history = _trimHistory(history);
  const withHistory = { ...payload, configChangeHistory: history };
  // why 一并透传适配器（api 形态 → PATCH body.why，由 server /branches/:id/config 落到服务端留痕行）
  const next = await getAdapter().branches.updateConfig(branchId, withHistory, { why });
  const idx = (mockDB.branches || []).findIndex(b => b.id === branchId);
  if (idx >= 0) {
    mockDB.branches = [...mockDB.branches.slice(0, idx), next, ...mockDB.branches.slice(idx + 1)];
  } else if (next) {
    mockDB.branches = [...mockDB.branches, next];
  }
  persist();
  return next;
}

// ── 配置回滚原语（2026-09-09 支书批「审计内核」B2：单键回滚 + 回滚留痕 + 上限裁剪）────────
// 定位历史一条单键变更 → 将其 to→from 写回该配置键（跨键不动）→ 追加 {what:'rollback', from:回滚前该键
// 现值, to:回滚值, by, why?} 并裁剪至 CONFIG_HISTORY_MAX。mock（本地直写）与 server
// （PATCH /branches/:id/config/rollback）两形态同源语义（同 CONFIG_ROLLBACK_KEYS 白名单与行结构）。
// 角色门（同 config 写权口径，2026-09-09 副书同权支书批）：party-staff / 本支部现任支书 / 本副支书。
function _syncBranchRecord(branchId, next) {
  const idx = (mockDB.branches || []).findIndex(b => b.id === branchId);
  if (idx >= 0) {
    mockDB.branches = [...mockDB.branches.slice(0, idx), next, ...mockDB.branches.slice(idx + 1)];
  } else if (next) {
    mockDB.branches = [...mockDB.branches, next];
  }
  persist();
  return next;
}

/** 纯判定：某人能否回滚该支部 config（party-staff / 本支部现任支书 / 本副支书；供 UI 可见性共用） */
export function canRollbackBranchConfig(actor, branchId) {
  const personId = actor && actor.personId;
  const branch = getBranchById(branchId);
  if (!personId || !branch) return { ok: false, reason: '目标支部不存在或未登录' };
  const role = _actorRoleOf(actor);
  if (role === 'party-staff') return { ok: true, reason: '' };
  if (role === 'secretary') {
    if (branch.secretaryId && branch.secretaryId === personId) return { ok: true, reason: '' };
    return { ok: false, reason: '仅本支部现任支书/副支书或党委组织员可回滚配置' };
  }
  if (role === 'deputy-secretary') {
    if (getBranchIdOfPerson(personId) === branch.id) return { ok: true, reason: '' };
    return { ok: false, reason: '仅本支部现任支书/副支书或党委组织员可回滚配置' };
  }
  return { ok: false, reason: '无该配置回滚权（仅支书/副支书或党委组织员可调）' };
}

/**
 * 回滚该支部一条单键配置变更（B2 原语）。
 * @param {string} branchId
 * @param {{ by?: string, targetEntryAt?: string, index?: number }} target
 *   定位方式二选一：targetEntryAt=历史条目的 at；index=历史数组序号（0 起）。
 *   by 缺省取登录快照（mock 直写留痕 by）；api 形态操作者以服务端会话为准。
 * @param {string} [why] 回滚依据/出处（可选）
 * @returns {Promise<{ok:boolean, branch?:Object, reason?:string}>}
 *   约束：仅 支书/副支书/party-staff 可调；单键写回（what ∈ CONFIG_ROLLBACK_KEYS，
 *   跨键/聚合留痕如 branch-created/config-copied 拒绝）；回滚后裁剪至历史上限。
 */
export async function rollbackBranchConfig(branchId, { by = null, targetEntryAt, index } = {}, why) {
  const branch = getBranchById(branchId);
  if (!branch) return { ok: false, reason: '目标支部不存在' };
  const actorId = by || _actorId();
  if (!actorId) return { ok: false, reason: '未登录（无法记录操作者）' };
  const perm = canRollbackBranchConfig({ personId: actorId }, branchId);
  if (!perm.ok) return { ok: false, reason: perm.reason };

  const history = Array.isArray(branch.config && branch.config.configChangeHistory)
    ? [...branch.config.configChangeHistory]
    : [];
  let entry = null;
  if (typeof targetEntryAt === 'string' && targetEntryAt) {
    entry = history.find(e => e && e.at === targetEntryAt) || null;
  } else if (Number.isInteger(index) && index >= 0 && index < history.length) {
    entry = history[index];
  }
  if (!entry) return { ok: false, reason: '未找到该条变更记录（须提供 targetEntryAt 或 index）' };
  if (!CONFIG_ROLLBACK_KEYS.includes(entry.what)) {
    return { ok: false, reason: `该条为「${entry.what}」留痕（跨键/聚合/回滚），不支持单键回滚` };
  }

  // 单键写回：将该条 to→from 写回目标配置键（from 为旧值归一形态，直接回写等价旧态）
  const revert = entry.from === undefined ? null : entry.from;
  const liveVal = (branch.config || {})[entry.what] ?? null; // 回滚前该键实际现值（留痕 from 口径）

  // api 形态：语义交服务端 /branches/:id/config/rollback（服务端角色门+同规则回滚，返回权威分支）
  if (getDataSource() === 'api') {
    try {
      const { ApiAdapter } = await import('../../data/api-adapter.js?v=20261028b');
      const updated = await ApiAdapter.branches.rollbackConfig(branchId, {
        ...(typeof targetEntryAt === 'string' && targetEntryAt ? { targetEntryAt } : {}),
        ...(Number.isInteger(index) ? { index } : {}),
        ...(why !== undefined && why !== null && String(why).trim() ? { why: String(why).trim() } : {}),
      });
      _syncBranchRecord(branchId, updated);
      return { ok: true, branch: updated };
    } catch (e) {
      console.error('[branch] 回滚失败', e);
      return { ok: false, reason: (e && (e.reason || e.message)) || '回滚失败（服务端拒绝）' };
    }
  }

  // mock 形态：本地同规则写回（to→from）+ 追加回滚留痕 + 裁剪上限
  const at = new Date().toISOString();
  const nextHistory = _trimHistory([...history, _historyRow(actorId, at, CONFIG_ROLLBACK_WHAT, liveVal, revert, why)]);
  const prevConfig = { ...(branch.config || {}) };
  const nextConfig = { ...prevConfig, [entry.what]: revert, configChangeHistory: nextHistory };
  const next = await getAdapter().branches.updateConfig(branchId, nextConfig);
  _syncBranchRecord(branchId, next);
  return { ok: true, branch: next };
}

/**
 * 保存支部工作流配置（UI 供本支部支书/副支书使用；最终写权由 server PATCH /branches/:id/config 校验。
 * 2026-10-21 批次 501（D-825）：**党委（party-staff）可代支部配置** modules / blocks / capabilityPackages，
 *   每次写入进 `config.configChangeHistory` 并带 `byRole`（标明是党委代配）；支部可自行覆盖。
 *   modules —— config.modules：模块/业务 tab 配置（null=恢复默认全开；undefined=不改）；
 *   blocks  —— config.blocks：活动产出块配置（null=恢复默认；undefined=不改）
 * tabs 仅用于防御核心 tab 不可隐藏。
 * @param {Object} [opts] opts.why=依据/出处（可选，来源页回填；undefined 不写留痕行）
 */
export async function updateBranchModules(branchId, modules, tabs = [], blocks, opts = {}) {
  const payload = {};
  if (modules !== undefined) {
    if (modules === null) {
      payload.modules = null;
    } else {
      // 核心 tab 不可隐藏/不参与排序（配置 UI 只读展示）；限长与严格字符串口径见 services/branch/config-clean.js
      const coreIds = new Set(getCoreTabIds(tabs));
      payload.modules = sanitizeConfigModules(modules, { coreIds });
    }
  }
  if (blocks !== undefined) payload.blocks = _sanitizeBlocks(blocks);
  return _saveBranchConfig(branchId, payload, opts);
}

/** 支部自主采用能力目录中的 optional/local 包；目录与版本由党委维护。 */
export async function updateBranchCapabilityPackages(branchId, selected, opts = {}) {
  const payload = selected === null ? { capabilityPackages: null } : {
    capabilityPackages: sanitizeConfigCapabilityPackages({
      schemaVersion: 1,
      packages: Object.fromEntries(CAPABILITY_PACKAGES
        .filter((definition) => ['optional', 'local'].includes(definition.applicability))
        .map((definition) => [definition.id, {
          version: definition.version,
          enabled: selected?.[definition.id] !== false,
        }])),
    }),
  };
  return _saveBranchConfig(branchId, payload, opts);
}

// ── L4 支部分工（workforce）───────────────────────────────────
// config.workforce = { [moduleId]: { ownerType:'role'|'person', ownerId } }；null=缺省分工。
// 模块目录单一源 = core/domain/work-map.js（WORK_MAP_MODULES 14 项）；分工调整走支委会议题（M2）。

/** 读取支部分工快照（纯）：config.workforce 覆盖 + 未覆盖模块按缺省主责（expandWorkforce 兜底） */
export function getBranchWorkforce(branchId) {
  const branch = getBranchById(branchId);
  return expandWorkforce(branch?.config?.workforce);
}

/** 保存支部分工（支书/副支书操作，副书同权 2026-09-09 支书批/议题通过后落库；workforce=null 恢复缺省分工；opts.why=依据出处） */
export async function updateBranchWorkforce(branchId, workforce, opts = {}) {
  const payload = workforce === null
    ? { workforce: null }
    : { workforce: sanitizeConfigWorkforce(workforce) };
  return _saveBranchConfig(branchId, payload, opts);
}

// ── 批4 域参数 policyOverrides（2026-09-09 支书批「域参数」L2 下放；config 独立域）────────
// config.policyOverrides = { 节: { 叶: 值 } }（节/叶白名单单一源 = policy-defaults POLICY_OVERRIDABLE；
// 净化唯一实现 = services/branch/config-clean.js sanitizeConfigPolicyOverrides，与 server PATCH /branches/:id/config 同源）。
// 角色守卫（批3 副书同权谓词同口径扩展）：
//   · party-staff / 本支部现任支书 / 本副支书 → 全量 policyOverrides；
//   · 本支部域负责人（纪检=inspection/attendance/review/makeup · 组织=memberConfirmation/thoughtReport ·
//     组长=leader）→ 仅自己域节（含 null=恢复该域默认）。
// 消费点：设置中心「支部治理 · 域参数」卡（L2）保存/恢复默认；读侧注入 = applyEffectivePolicyDefaultsForPerson。

/** 域负责人角色 → 可管域节集合（R10-B10：由 policy-defaults.js::POLICY_OVERRIDABLE 的 domain 字段派生，
 *  与 server 侧 policySectionsByRole() 同源；勿再手写第二份清单） */
export const POLICY_SECTION_BY_DOMAIN_ROLE = policySectionsByRole();

/**
 * 某支部的有效策略（R10-D06 单一源）：出厂基准 + 该支部 config.policyOverrides（白名单净化后）合并。
 * 纯读：不改 POLICY_DEFAULTS 全局，按支部 id 取——报送/提示文案都从这里取值，不直读 POLICY_DEFAULTS。
 * @param {string} [branchId]
 * @returns {Object} 有效策略（独立副本）
 */
export function getEffectivePolicy(branchId) {
  const branch = getBranchById(branchId);
  const clean = branch?.config ? sanitizeConfigPolicyOverrides(branch.config.policyOverrides) : null;
  return effectivePolicyWith(clean);
}

/** 操作者角色解析（actor.role 优先；缺省回退档案角色） */
function _actorRoleOf(actor) {
  const role = (actor && actor.role) || (actor && actor.personId ? (getPersonById(actor.personId) || {}).role : '') || '';
  return role;
}

/**
 * 纯判定：某人能否管理 policyOverrides（批4；供 UI 可见性与写口共用，勿在别处另写规则）。
 * @param {{ personId: string, role?: string }} actor
 * @param {string} branchId
 * @returns {{ ok: boolean, scope: 'all'|string[]|null, reason?: string }}
 *   scope='all'=支书/副支书/party-staff 全量；scope=域节数组=仅该域各节；null=无权
 */
export function canManagePolicyOverrides(actor, branchId) {
  const personId = actor && actor.personId;
  const branch = getBranchById(branchId);
  if (!personId || !branch) return { ok: false, scope: null, reason: '目标支部不存在或未登录' };
  const role = _actorRoleOf(actor);
  if (role === 'party-staff') return { ok: true, scope: 'all' };
  if (role === 'secretary') {
    if (branch.secretaryId && branch.secretaryId === personId) return { ok: true, scope: 'all' };
    return { ok: false, scope: null, reason: '仅本支部现任支书/副支书或党委组织员可改全量域参数' };
  }
  if (role === 'deputy-secretary') {
    if (getBranchIdOfPerson(personId) === branch.id) return { ok: true, scope: 'all' };
    return { ok: false, scope: null, reason: '仅本支部现任支书/副支书或党委组织员可改全量域参数' };
  }
  const own = POLICY_SECTION_BY_DOMAIN_ROLE[role];
  if (own && getBranchIdOfPerson(personId) === branch.id) return { ok: true, scope: own };
  return { ok: false, scope: null, reason: '无该域参数管理权' };
}

/**
 * 保存域参数覆盖（批4 写口；overrides = { 节: 值 | null }——节值 null=恢复该域默认（删除该节覆盖）；
 * 支书/副支书/party-staff 可全量；域负责人自动收窄到自己的域节；净化走 sanitizeConfigPolicyOverrides，
 * 非法值/未知键丢弃不写坏；留痕与 modules/blocks/workforce 同 config.configChangeHistory。
 * @param {Object} [opts] opts.actor=操作者；opts.why=依据/出处（可选，来源页回填；undefined 不写）
 * @returns {Promise<{ ok: boolean, changed: boolean, reason?: string }>}
 */
export async function savePolicyOverrides(branchId, overrides, opts = {}) {
  const branch = getBranchById(branchId);
  if (!branch) return { ok: false, changed: false, reason: '目标支部不存在' };
  const actor = (opts && opts.actor) || {};
  const perm = canManagePolicyOverrides(actor, branchId);
  if (!perm.ok) return { ok: false, changed: false, reason: perm.reason || '无权限' };
  if (overrides === null || overrides === undefined) overrides = {};
  if (!overrides || typeof overrides !== 'object' || Array.isArray(overrides)) {
    return { ok: false, changed: false, reason: 'policyOverrides 须为对象（节 → 值/null）' };
  }
  // 与既有覆盖合并：节=null → 删该节（恢复该域默认）；节=对象 → 净化后整节替换
  const prevPo = (branch.config && branch.config.policyOverrides !== null && typeof branch.config.policyOverrides === 'object' && !Array.isArray(branch.config.policyOverrides))
    ? JSON.parse(JSON.stringify(branch.config.policyOverrides))
    : {};
  const nextPo = { ...prevPo };
  let changed = false;
  for (const sec of Object.keys(overrides)) {
    if (!POLICY_OVERRIDE_SECTIONS.includes(sec)) continue; // 未知节忽略（白名单外）
    if (perm.scope !== 'all' && !perm.scope.includes(sec)) continue; // 域负责人不可改他人域节
    if (overrides[sec] === null) {
      if (Object.prototype.hasOwnProperty.call(nextPo, sec)) { delete nextPo[sec]; changed = true; }
      continue;
    }
    const clean = sanitizeConfigPolicyOverrides({ [sec]: overrides[sec] });
    if (!clean || !clean[sec]) continue; // 全非法/空 → 该节不写
    if (!_sameConfigVal(nextPo[sec], clean[sec])) {
      nextPo[sec] = clean[sec];
      changed = true;
    }
  }
  if (!changed) return { ok: true, changed: false };
  const payload = Object.keys(nextPo).length ? { policyOverrides: nextPo } : { policyOverrides: null };
  const oldArchiveUnit = prevPo.archive?.periodic?.unit || POLICY_DEFAULTS.archive.periodic.unit;
  const nextArchiveUnit = nextPo.archive?.periodic?.unit || POLICY_DEFAULTS.archive.periodic.unit;
  const archiveVersion = Math.max(1, Number(branch.config?.periodicArchiveVersion) || 1);
  payload.periodicArchiveVersion = oldArchiveUnit === nextArchiveUnit ? archiveVersion : archiveVersion + 1;
  await _saveBranchConfig(branchId, payload, { why: opts.why });
  return { ok: true, changed: true };
}

/**
 * 读侧有效默认注入（批4 便捷入口）：当前人所属支部 config.policyOverrides 注入 POLICY_DEFAULTS。
 * 调用时机 = 数据加载完成路径（services/core/mock.js loadDB mock/api 两形态均调用）——跨支部切换/每次
 * loadDB 先复位出厂默认再覆盖（幂等）；未登录/档案缺 branchId → 兜底 'br-b1'（同 getBranchIdOfPerson）。
 * @param {string} [personId] 当前登录人（缺省 = 按登录快照兜底 br-b1）
 */
export function applyEffectivePolicyDefaultsForPerson(personId) {
  const bid = getBranchIdOfPerson(personId);
  return applyBranchPolicyOverrides(getBranchById(bid));
}

/**
 * 人 → 有效归属支部（2026-09-09 支书批「支部归属显式化」A1）：
 *   person 不存在 / person.branchId 为 null 或空 / branchId 查无该支部 → null；否则返回该支部记录。
 * 支部语境判定（"我属于哪个支部 / 是否存在我的支部"）一律用本函数——不再回退示例支部；
 * getBranchIdOfPerson 仅为数据解析兜底（演示/存量兼容），勿用于归属语境判定。
 */
export function getBoundBranch(personId) {
  if (!personId) return null;
  const person = getPersonById(personId);
  if (!person) return null;
  if (!person.branchId) return null;
  return getBranchById(person.branchId);
}

/**
 * 人 → 所属支部 id ——【数据解析兜底】（2026-09-09 支书批 A1 定位说明）：
 * 无档案/档案缺 branchId（含党委级 party-staff）→ 兜底 'br-b1'（演示/存量兼容惰性维度迁移用，
 * 如 withinBranch 行过滤、工作流策略按支部读取等纯数据读写位）。
 * ⚠️ 支部语境判定（"是否存在我的支部 / header 归属 / 治理区是否可达"）一律用 getBoundBranch，
 * 勿用本函数兜底判定归属——否则无归属者会被误判为 br-b1 成员（泄漏示例支部）。
 */
export function getBranchIdOfPerson(personId) {
  if (!personId) return DEFAULT_BRANCH_ID;
  const person = getPersonById(personId);
  return person?.branchId || DEFAULT_BRANCH_ID;
}

// 静态壳兜底名：分支数据尚未加载时的兜底（时序竞态用）——**单一源派生，不再复制字面量**：
// 取自 data/mock/branches.js 演示支部 br-b1 的档案名（DEFAULT_BRANCH_DISPLAY_NAME）。
// ⚠ 段②（真实归属：支部 config.headerTitle / name）与段③（本兜底）在本演示实例下取到**同一个字面量**，
//   但来源不同：段②读 mockDB.branches 里的支部数据（改支部名/页眉名即变），段③是模块加载期固化的兜底
//   （数据未加载时根本读不到支部记录）。肉眼分辨不了时看 getAffiliationShape().segment（1–5 段号 + 业务语言）。
const STATIC_HEADER_FALLBACK = DEFAULT_BRANCH_DISPLAY_NAME;

// 未登录静态壳显示名（2026-09-10 支书批「归属显示不一致」修复；2026-10-11 去演示化）：
// 未登录/查无档案时不再走 getBranchIdOfPerson 的 br-b1 数据解析兜底（那会像真有归属），
// 改为落**支部显示名**（数据驱动，缺省取支部名兜底）——与 STATIC_HEADER_FALLBACK（数据未加载兜底）同源。
const GUEST_HEADER_PLACEHOLDER = STATIC_HEADER_FALLBACK;

/** 分支数据是否已加载（mockDB 已从存储/后端恢复）——用于区分「数据未加载」与「真无归属」 */
export function isLoaded() {
  return !!mockDB._loaded;
}

/**
 * header 品牌软编码（2026-09-09 支书批「支部归属显式化」A2；2026-09-10 时序/占位修复）：
 *   config.headerTitle → branch.name；支部名随支部配置档案更换显示——不硬编码示例支部名。
 * 判定顺序（段号 = 本注释序号，getAffiliationShape() 回报同一段号）：
 *   1) party-staff（党委级角色，不属于任一支部）→ 院系党委名（前置不变）；
 *   2) getBoundBranch 有效归属 → 该支部 config.headerTitle / name / 静态兜底名；
 *      ⚠ 段②与段③在本演示实例下**取到同一个字面量**，来源不同：段②=支部数据（可被改支部名/页眉名改变）
 *   （数据来自 mockDB.branches）；段③=模块加载期固化的兜底常量。肉眼分辨不了就看段号。
 *   3) 有 person 档案但分支数据尚未加载（loadDB 未完成）→ 静态兜底名 STATIC_HEADER_FALLBACK
 *      （时序修复：避免加载竞态把登录人误报「未绑定支部」；数据到达后 header 重绘归还真实支部名）；
 *   4) 有 person 档案且数据已加载、确无有效归属支部（branchId 空/查无）→ 中性占位「未绑定支部」
 *      （不再泄漏示例支部名；opts.placeholder 可覆盖）；
 *   5) 无 person（未登录静态壳/查无档案）→ 支部显示名 GUEST_HEADER_PLACEHOLDER
 *      （数据驱动，缺省取支部名兜底）。
 * ⚠ 本函数是**唯一判定实现**（getHeaderTitle / getAffiliationShape 共用），勿在别处复制判定。
 * @param {string} [personId] 当前登录人 personId（缺省 = 未登录静态壳）
 * @param {{ placeholder?: string, role?: string }} [opts] role 由登录态直接传入：
 *   党委组织员在通用成员列表按支部隔离后可能查不到自己的档案，不能只靠 person 记录判定
 * @returns {{ title: string, segment: number }}
 */
function _resolveHeaderTitle(personId, opts = {}) {
  const placeholder = (opts && opts.placeholder) || '未绑定支部';
  const person = personId ? getPersonById(personId) : null;
  const role = (opts && opts.role) || person?.role || '';
  // 段① 党委级角色：header 显示院系党委名（不属于任一支部）
  if (role === 'party-staff') return { title: PARTY_COMMITTEE.name, segment: 1 };
  const bound = getBoundBranch(personId);
  // 段② 真实归属（支部数据可改）：支部页眉显示名 config.headerTitle → name
  if (bound) return { title: bound.config?.headerTitle || bound.name || STATIC_HEADER_FALLBACK, segment: 2 };
  // 段③ 分支数据尚未加载（时序）：加载期兜底名，而非误报「未绑定支部」
  if (person && !isLoaded()) return { title: STATIC_HEADER_FALLBACK, segment: 3 };
  // 段④ 登录且有 person 档案、但无有效归属支部 → 中性占位（支书语义：真无支部不显示示例支部名）
  if (person) return { title: placeholder, segment: 4 };
  // 段⑤ 未登录 / 查无档案（静态壳）：支部显示名（数据驱动，缺省取支部名兜底）
  return { title: GUEST_HEADER_PLACEHOLDER, segment: 5 };
}

export function getHeaderTitle(personId, opts = {}) {
  return _resolveHeaderTitle(personId, opts).title;
}

/** header 归属判定段号（1–5，顺序同 getHeaderTitle）→ 业务语言（「当前形态」指示卡与注释共用本表） */
export const HEADER_SEGMENT_LABELS = {
  1: '党委级角色，不属于任一支部',
  2: '按你的支部档案解析到本支部',
  3: '数据加载中，暂用默认支部名',
  4: '已登录，但档案里没有有效归属支部',
  5: '未登录 / 查无档案，按支部显示名展示',
};

/**
 * 当前形态 · 归属判定（2026-09-23 支书批「判别依据可感」）——单一源查询，供「设置 → 当前形态」指示卡使用：
 * 不开调试器即可核对「当前数据源是哪个 / 顶栏那个组织名是哪一段判定命中的 / 所属支部 id / 登录人」。
 * 判定段与最终组织名 = _resolveHeaderTitle（本函数不复制判定）。
 * ⚠ 不回报 token 原文，只回报有/无（tokenPresent）。
 * @param {string} [personId] 当前登录人 personId（缺省 = 未登录静态壳）
 * @returns {{ source: 'mock'|'api', tokenPresent: boolean, segment: number, segmentLabel: string,
 *             branchId: string, title: string, dataLoaded: boolean }}
 */
export function getAffiliationShape(personId) {
  const { title, segment } = _resolveHeaderTitle(personId);
  const bound = getBoundBranch(personId);
  let tokenPresent = false;
  try { tokenPresent = !!sessionStorage.getItem('gsm1921-api-token'); } catch (_) { /* 隐私模式/无 sessionStorage */ }
  return {
    source: getDataSource(),
    tokenPresent,
    segment,
    segmentLabel: HEADER_SEGMENT_LABELS[segment] || '',
    branchId: bound ? bound.id : '',
    title,
  };
}

/**
 * 党委机构名（2026-09-03 数据域接线收口：党委台 UI 原直连 mock/branches PARTY_COMMITTEE）
 * 机构信息单一源（接入真实党委机构配置时替换本实现，UI 零改动）
 */
export function getCommitteeName() {
  return PARTY_COMMITTEE?.name || '光华管理学院党委';
}

/**
 * 支部内资源隔离过滤（收敛点，防止各 tab 手写过滤未同步的情况）：
 * 按当前人所属支部过滤行；老数据无 branchId 视为 br-b1（惰性维度迁移兼容）。
 * 单支部时代恒等（全部 br-b1）；党委创建新支部并挂入跨支部数据后自然生效。
 */
export function withinBranch(rows, personId) {
  const bid = getBranchIdOfPerson(personId);
  return rows.filter(r => (r.branchId || DEFAULT_BRANCH_ID) === bid);
}

// ── 党委支部管理写操作（P1；adapter CRUD 实时写 + 本地 mockDB 同步，刷新不丢）────────
// 立项⑤ 阶段A（2026-09-06）：支部创建收敛为「空组织模板 / 复制现有」双形态（EMPTY_BRANCH_TEMPLATE +
// createBranch mode），原「党委随手建支部」同一写口升级；?reset=1 仍回演示种子、不混（阶段 B 分层语义）。
// 域名分区事实（2026-09-06 核查登记）：业务域（activities/attendance/taskforces/notices/thought-reports 等）
// 当前为「单支部全域、非 branch 分区」（种子无 branchId 键），people 全员挂 br-b1（党委组织员 null）。
// 因此「空支部业务为空」落实为：新建动作只写 branches 集合，记录本身不产生业务引用（验收 1/2 可达）；
// 全域 branch 分区属 spec 风险段登记缺口，不在本立项重架构——新建支部先用于配置/模板，业务数据待分区能力落地。

/** 新建支部名长度上限（与 services/branch/config-clean.js ORG_MAX.name 对齐） */
const NEW_BRANCH_NAME_MAX = 80;

/**
 * 空组织模板（立项⑤ 阶段A）：结构 = 支部记录骨架、业务为空。
 * 语义：
 *   - name = 占位名「新支部（待配置）」（名待填；创建时未显式给名则沿用，向导步骤①可改）。
 *   - headerTitle 空 → header 回退 branch.name（占位名）展示；desc 空、themePreset null（默认红调）。
 *   - config.modules/blocks null = 默认全开（同 br-b1）；config.workforce null = 缺省分工（expandWorkforce 兜底）。
 *   - secretaryId null = 席位空缺待党委任命。
 *   - 不引用支部成员 id（学号/工号）与任何业务域（people/activities/attendance/agenda/taskforces/notices/
 *     thought-reports 等）——域内引用为空，按换壳工作单逐项填入。
 */
export const EMPTY_BRANCH_TEMPLATE = Object.freeze({
  name: '新支部（待配置）',
  type: '',                       // 类别标签（自由文本，待党委录入；br-b1 例='本科生'）
  config: Object.freeze({
    headerTitle: '',
    accent: null,                 // null=默认党建红
    modules: null,                // null=工作流模块默认全开（同 br-b1 语义）
    blocks: null,                 // null=产出块/工作流块默认全开
    workforce: null,              // null=缺省分工
    desc: '',
    themePreset: null,            // null=默认红调（THEME_PRESET_IDS 外）
    fileSpaceIsolated: true,
  }),
  secretaryId: null,              // 席位空缺待任命
  status: 'active',
});

/** 空支部创建名校验（与 server POST /branches 同规则；缺省键 → 模板占位名，显式空/超长 → 拒绝） */
function _validateNewBranchName(name) {
  if (name === undefined || name === null) return { ok: true, value: EMPTY_BRANCH_TEMPLATE.name };
  const t = String(name).trim();
  if (!t) return { ok: false, reason: '支部名不能为空' };
  if (t.length > NEW_BRANCH_NAME_MAX) return { ok: false, reason: `支部名过长（不超过 ${NEW_BRANCH_NAME_MAX} 字）` };
  return { ok: true, value: t };
}

function _cloneOrNull(v) {
  return v === undefined || v === null ? null : JSON.parse(JSON.stringify(v));
}

/**
 * 纯构造：新支部记录（空模板初始化 / 以源支部为模板复制）。零副作用，mock 本地直写与
 * server POST /branches（内联同语义）双形态共用此口径——双形态一致性由
 * server/test/empty-template.test.mjs ⑤ 断言守护。
 * @param {Object} opts
 * @param {string} [opts.id] 缺省时自生成 br-*
 * @param {string} [opts.name] 支部名（缺省=模板占位名；显式空/超长 → throw {reason}）
 * @param {'empty'|'copy'} [opts.mode='empty'] 空模板初始化 / 复制现有
 * @param {Object|null} [opts.sourceBranch] mode='copy' 的源支部记录（缺省 → throw {reason}）
 * @param {string} [opts.by] 操作者 personId（留痕）
 * @param {string} [opts.type] 类别标签（仅 empty 模式透传；copy 取源 type）
 * @param {string} [opts.now] 时间（测试可注入）
 */
export function buildNewBranchRecord({ id, name, mode = 'empty', sourceBranch = null, by = null, type = '', now } = {}) {
  const isCopy = mode === 'copy';
  const nameRes = _validateNewBranchName(name);
  if (!nameRes.ok) throw Object.assign(new Error(nameRes.reason), { reason: nameRes.reason, code: 'BRANCH_NAME_INVALID' });
  if (isCopy && !sourceBranch) throw Object.assign(new Error('源支部不存在'), { reason: '源支部不存在', code: 'SOURCE_BRANCH_MISSING' });
  const finalName = nameRes.value;
  const at = now || new Date().toISOString();
  const srcCfg = isCopy ? (sourceBranch.config || {}) : null;
  // 复制语义（与「复制配置到支部」applyConfigCopy 面向既有支部不同——本动作=以源支部为模板建新支部）：
  // config 域 modules/blocks/workforce 深拷贝（源缺省 → null 默认全开/缺省分工）；
  // org 档案域复制 desc/themePreset；headerTitle 取新支部名（保持 name→headerTitle 同步不变式，
  // 与 renameBranch/updateBranchOrg 一致，避免创建即「页眉≠名」错位）；secretaryId 不带走（席位待任命）。
  const config = {
    headerTitle: isCopy ? finalName : '',
    accent: null,
    modules: isCopy ? _cloneOrNull(srcCfg.modules) : null,
    blocks: isCopy ? _cloneOrNull(srcCfg.blocks) : null,
    workforce: isCopy ? _cloneOrNull(srcCfg.workforce) : null,
    desc: isCopy ? (srcCfg.desc ?? '') : '',
    themePreset: isCopy ? (srcCfg.themePreset ?? null) : null,
    fileSpaceIsolated: isCopy ? (srcCfg.fileSpaceIsolated ?? true) : true,
    // 建支部留痕（与 config 各域写同一 configChangeHistory 数组，{by,at,what,from,to} 审计口径）
    configChangeHistory: [{
      by: by ?? null,
      at,
      what: 'branch-created',
      from: isCopy ? `branch:${sourceBranch.id}` : 'empty-template',
      to: null,
    }],
  };
  const record = {
    name: finalName,
    type: isCopy ? (sourceBranch.type || '') : String(type || '').trim(),
    config,
    secretaryId: null,
    status: 'active',
    createdAt: at,
  };
  // 支部 id 形态 `br-<8hex>` 是**既有契约**（server/test/empty-template.test.mjs 与
  //   branch-roster-import.test.mjs 均断言 /^br-[0-9a-f]{8}$/；支部 id 还会出现在
  //   `?branch=br-…` URL 与配置留痕里）——故保留 8 位十六进制，随机段仍经唯一源
  //   core/base/id.js::randomHex(4)（4 字节 → 8 位 hex）。**勿改长度**。
  //   2026-09-13 Q-21-2：原 `_newBranchId()` 自建「randomUUID→Math.random」降级链，
  //   已删除并收敛到 randomHex（同一降级链，且保证所有分支路径都产出真十六进制）。
  record.id = id || ('br-' + randomHex(4));
  return record;
}

/**
 * 党委创建支部（立项⑤ 阶段A 双形态；支部管理「+ 新建支部」与向导「新建支部…」共用同一写口）：
 * @param {Object} opts
 * @param {'empty'|'copy'} [opts.mode='empty'] empty=空组织模板初始化；copy=复制现有支部配置为模板
 * @param {string} [opts.sourceId] mode='copy' 源支部 id（不存在 → {ok:false, reason:'源支部不存在'}）
 * @param {string} [opts.name] 支部名（缺省=占位名「新支部（待配置）」；显式空/超长 → {ok:false, reason}）
 * @param {string} [opts.type] 类别标签（empty 模式透传，兼容原支部管理表单）
 * @param {string} [opts.by] 操作者 personId（留痕 by）
 * @param {string} [opts.actorRole] 操作者角色（提供时校验须为 party-staff——UI/测试双保险；
 *   mock 模式本无角色门控，入参校验与 server POST /branches 门控同口径，防绕过）
 * @returns {Promise<{ok:boolean, branch?:Object, reason?:string}>}
 */
export async function createBranch({ mode = 'empty', sourceId, name, type, by, actorRole } = {}) {
  if (actorRole && actorRole !== 'party-staff') {
    return { ok: false, reason: '无权限：仅党委组织员/党务老师可创建支部' };
  }
  const m = mode === 'copy' ? 'copy' : 'empty';
  const nameRes = _validateNewBranchName(name);
  if (!nameRes.ok) return { ok: false, reason: nameRes.reason };
  const sourceBranch = m === 'copy' ? getBranchById(sourceId) : null;
  if (m === 'copy' && !sourceBranch) return { ok: false, reason: '源支部不存在' };
  try {
    let record;
    if (getDataSource() === 'api') {
      // API 模式：语义请求交服务端构造（server POST /branches 同源逻辑 + party-staff 门控净化），
      // 以服务端返回为权威（防止两端未同步的情况；mock 模式本地同口径构造见下）。
      const created = await getAdapter().branches.create({
        mode: m,
        ...(m === 'copy' ? { sourceId } : {}),
        name: nameRes.value,
        ...(m === 'empty' && type ? { type: String(type).trim() } : {}),
      });
      if (!created || created.ok === false) {
        return { ok: false, reason: (created && created.reason) || '服务端拒绝创建支部' };
      }
      record = created.branch || created;
    } else {
      // mock 模式：本地纯构造直写 mockDB + persist（语义对齐 mock-adapter branches.create 骨架，
      // 但保留完整 config——mock-adapter create 会按简版骨架重造 config，丢 org/blocks/workforce 细域）
      record = buildNewBranchRecord({ name: nameRes.value, mode: m, sourceBranch, type, by });
    }
    // 本地 mockDB 同步（API 模式 adapter 只 POST server；mock 模式已写入，防重复）
    if (!(mockDB.branches || []).some(b => b.id === record.id)) {
      mockDB.branches = [...mockDB.branches, record];
    }
    persist();
    return { ok: true, branch: record };
  } catch (err) {
    console.error('[branch] 创建支部失败', err);
    return { ok: false, reason: (err && (err.reason || err.message)) || '创建支部失败' };
  }
}

/** 党委改支部名（同步 config.headerTitle——header 软编码随之变化） */
export async function renameBranch(id, name) {
  const next = await getAdapter().branches.update(id, { name: String(name || '').trim() });
  const idx = (mockDB.branches || []).findIndex(b => b.id === id);
  if (idx >= 0) {
    mockDB.branches = [...mockDB.branches.slice(0, idx), next, ...mockDB.branches.slice(idx + 1)];
  }
  persist();
  return next;
}

/** 党委**停用 / 恢复**支部（软停用 · 2026-10-02 批次 344 · 支书裁 `D-744`③「补『停用（软）』入口」）：
 *  只改顶层 `status`（`active` ↔ `inactive`），**不物理删**——支部实例仍可被读（监控台账 / 进去只读），
 *  任期档案（`appointment_records`）与成员档案**全部保留**；与 `renameBranch` 同一写口
 *  （`getAdapter().branches.update` → 本地 mockDB 同步 → `persist()`；服务端通用 branches PATCH 为 party-staff 门控）。 */
export async function setBranchActive(id, active) {
  const next = await getAdapter().branches.update(id, { status: active ? 'active' : 'inactive' });
  const idx = (mockDB.branches || []).findIndex(b => b.id === id);
  if (idx >= 0) {
    mockDB.branches = [...mockDB.branches.slice(0, idx), next, ...mockDB.branches.slice(idx + 1)];
  }
  persist();
  return next;
}

// ── 换组织向导 · 支部组织档案写口（2026-09-06 支书 R3/R4：向导吸收合并 party-config）────────
// org = { name?, headerTitle?, desc?, themePreset? }（undefined=不改；净化唯一实现 = config-clean sanitizeConfigOrg）。
// 权限轨（沿用既有校验语义；2026-09-09 支书批副书同权——本支部现任支书/副支书均视同支部层配置权）：
//   · name（顶层治理字段）→ adapter.branches.update（server 端 = 通用 branches PATCH，仅 party-staff）；
//     mock 模式无门控、UI 层已按角色禁用（支书/副支书均不可改官方支部名）。
//   · headerTitle/desc/themePreset（config 域）→ adapter.updateConfig（server 端 = PATCH /branches/:id/config，
//     party-staff / 本支部现任支书或副支书（同支部）均可写；设置中心支部治理与向导即走此轨）。
// 留痕：与 modules/blocks/workforce 同一 config.configChangeHistory 数组（{by,at,what,from?,to?,why?}）。
// opts.why=依据/出处（可选，来源页回填；undefined 不写行）。
export async function updateBranchOrg(branchId, org = {}, opts = {}) {
  const cur = getBranchById(branchId);
  if (!cur) return null;
  const clean = sanitizeConfigOrg(org);
  const prev = cur.config || {};
  const by = (opts && opts.by) || _actorId() || null;
  const at = new Date().toISOString();
  const why = (opts && opts.why) || undefined;
  let history = Array.isArray(prev.configChangeHistory) ? [...prev.configChangeHistory] : [];
  const topPatch = {};
  const cfgPatch = {};
  let dirty = false;

  if (clean.name !== undefined && clean.name !== cur.name) {
    topPatch.name = clean.name;
    cfgPatch.headerTitle = clean.name; // 顶层改名 → headerTitle 同步（与 renameBranch/mock-adapter 语义一致）
    history.push(_historyRow(by, at, 'name', cur.name ?? null, clean.name, why));
    dirty = true;
  }
  if (clean.headerTitle !== undefined && !topPatch.name && clean.headerTitle !== (prev.headerTitle ?? '')) {
    cfgPatch.headerTitle = clean.headerTitle;
    history.push(_historyRow(by, at, 'headerTitle', prev.headerTitle ?? null, clean.headerTitle, why));
    dirty = true;
  }
  if (clean.desc !== undefined && clean.desc !== (prev.desc ?? '')) {
    cfgPatch.desc = clean.desc;
    history.push(_historyRow(by, at, 'desc', prev.desc ?? null, clean.desc, why));
    dirty = true;
  }
  if (clean.themePreset !== undefined && clean.themePreset !== (prev.themePreset ?? null)) {
    cfgPatch.themePreset = clean.themePreset;
    history.push(_historyRow(by, at, 'themePreset', prev.themePreset ?? null, clean.themePreset, why));
    dirty = true;
  }
  if (!dirty) return cur; // 无实质变化：不写、不留痕

  history = _trimHistory(history);
  const nextConfig = { ...prev, ...cfgPatch, configChangeHistory: history };
  // 含顶层 name → 通用 branches PATCH（party-staff）；仅 config 域 → PATCH /branches/:id/config（支书/党委均可）
  // why 一并透传适配器（api 形态 PATCH body.why → 服务端同源落行）
  const next = Object.keys(topPatch).length
    ? await getAdapter().branches.update(branchId, { ...topPatch, config: nextConfig })
    : await getAdapter().branches.updateConfig(branchId, nextConfig, { why });
  const idx = (mockDB.branches || []).findIndex(b => b.id === branchId);
  if (idx >= 0) {
    mockDB.branches = [...mockDB.branches.slice(0, idx), next, ...mockDB.branches.slice(idx + 1)];
  } else if (next) {
    mockDB.branches = [...mockDB.branches, next];
  }
  persist();
  return next;
}

/** 支部主题预设 id（null=默认红调；换组织向导步骤①/运行时写 CSS 变量用） */
export function getBranchThemePreset(branchId) {
  return getBranchById(branchId)?.config?.themePreset ?? null;
}

// ── 配置覆盖写（2026-09-06 立项④阶段二：JSON 配置包导入 / 复制配置到支部 共用落地）────────
// domains = { org?: { headerTitle?, desc?, themePreset? }, modules?, blocks?, workforce? }
//   域显式提供才处理；null = 该域恢复默认（与 updateBranchModules 等 null 语义一致）；缺省 = 不改。
//   逐域净化唯一实现 = services/branch/config-clean.js（sanitizeConfigOrg/sanitizeConfigModules/
//   sanitizeConfigBlocks/sanitizeConfigWorkforce）——非法 id / 白名单外值丢弃，不写坏。
//   一次调用 = 一次 adapter 写 + 一条聚合留痕 { by, at, what, from, to: fields }
//   （批量/覆盖类操作一操作一痕可读；逐 key 明细可从 config 现读核对）。
/** 支部配置域覆盖写（内部落地：applyConfigCopy / org-config-package.applyConfigPackage 共用） */
export async function applyBranchConfig(branchId, domains = {}, opts = {}) {
  const cur = getBranchById(branchId);
  if (!cur) return { branchId, ok: false, reason: '目标支部不存在', changed: false, updatedFields: [] };
  const by = (opts && opts.by) || _actorId() || null;
  const at = new Date().toISOString();
  const prev = cur.config || {};
  let history = Array.isArray(prev.configChangeHistory) ? [...prev.configChangeHistory] : [];
  const patch = {};
  const fields = [];

  // org 域（headerTitle/desc/themePreset；desc 允许清空为 ''，其余空串丢弃——sanitizeConfigOrg 口径）
  if (domains && domains.org && typeof domains.org === 'object' && !Array.isArray(domains.org)) {
    const clean = sanitizeConfigOrg(domains.org);
    for (const key of ['headerTitle', 'desc', 'themePreset']) {
      if (clean[key] === undefined) continue;
      const old = key === 'desc' ? (prev.desc ?? '') : (prev[key] ?? null);
      const next = key === 'desc' ? (clean[key] ?? '') : (clean[key] ?? null);
      if (!_sameConfigVal(old, next)) { patch[key] = clean[key]; fields.push(key); }
    }
  }
  if (domains && Object.prototype.hasOwnProperty.call(domains, 'modules')) {
    const next = sanitizeConfigModules(domains.modules === undefined ? null : domains.modules);
    const old = prev.modules ?? null;
    if (!_sameConfigVal(old, next)) { patch.modules = next; fields.push('modules'); }
  }
  if (domains && Object.prototype.hasOwnProperty.call(domains, 'blocks')) {
    const next = sanitizeConfigBlocks(domains.blocks === undefined ? null : domains.blocks);
    const old = prev.blocks ?? null;
    if (!_sameConfigVal(old, next)) { patch.blocks = next; fields.push('blocks'); }
  }
  if (domains && Object.prototype.hasOwnProperty.call(domains, 'workforce')) {
    const next = sanitizeConfigWorkforce(domains.workforce === undefined ? null : domains.workforce);
    const old = prev.workforce ?? null;
    if (!_sameConfigVal(old, next)) { patch.workforce = next; fields.push('workforce'); }
  }
  if (!fields.length) return { branchId, ok: true, changed: false, updatedFields: [] }; // 与现状一致：不写不留痕

  const what = (opts && opts.what) || 'config-overwrite';
  const from = (opts && opts.from) || null;
  const why = (opts && opts.why) || undefined;
  history.push(_historyRow(by, at, what, from, [...fields], why));
  history = _trimHistory(history);
  const nextConfig = { ...prev, ...patch, configChangeHistory: history };
  const next = await getAdapter().branches.updateConfig(branchId, nextConfig, { why });
  const idx = (mockDB.branches || []).findIndex(b => b.id === branchId);
  if (idx >= 0) {
    mockDB.branches = [...mockDB.branches.slice(0, idx), next, ...mockDB.branches.slice(idx + 1)];
  } else if (next) {
    mockDB.branches = [...mockDB.branches, next];
  }
  persist();
  return { branchId, ok: true, changed: true, updatedFields: fields };
}

/**
 * 复制配置到支部（2026-09-06 立项④阶段二：党委台向导工具条「复制配置到支部…」落地点）
 * 语义：把源支部 config 的 modules/blocks/workforce（保留既有结构）复制给每个目标；
 *   includeOrg=true 时连同 org 档案域（headerTitle/desc/themePreset）一并复制。
 *   源 config 缺省（undefined/null）即「默认全开/默认分工」→ 目标相应域恢复默认（与源一致）。
 * 留痕：逐 target 追加一条 { by, at, what:'config-copied', from:`branch:${sourceId}`, to: fields }。
 * 净化：复用 config-clean sanitize（主题预设白名单外回退——非法值丢弃、themePreset:null 清除回默认红调）。
 * 返回：Array<{ targetId, ok, fields: string[], reason? }>；非法/不存在返回 reason（不 throw）。
 */
export async function applyConfigCopy(sourceId, targetIds, opts = {}) {
  const by = (opts && opts.by) || _actorId() || null;
  const includeOrg = !(opts && opts.includeOrg === false);
  const ids = [...new Set((Array.isArray(targetIds) ? targetIds : []).map(String).filter(Boolean))];
  const source = getBranchById(sourceId);
  if (!source) {
    return ids.map(targetId => ({ targetId, ok: false, fields: [], reason: '源支部不存在' }));
  }
  const srcCfg = source.config || {};
  const results = [];
  for (const targetId of ids) {
    if (targetId === sourceId) {
      results.push({ targetId, ok: false, fields: [], reason: '目标与源为同一支部' });
      continue;
    }
    if (!getBranchById(targetId)) {
      results.push({ targetId, ok: false, fields: [], reason: '目标支部不存在' });
      continue;
    }
    const domains = {
      modules: srcCfg.modules === undefined ? null : srcCfg.modules,
      blocks: srcCfg.blocks === undefined ? null : srcCfg.blocks,
      workforce: srcCfg.workforce === undefined ? null : srcCfg.workforce,
    };
    if (includeOrg) {
      domains.org = {
        headerTitle: srcCfg.headerTitle || source.name || '',
        desc: srcCfg.desc ?? '',
        themePreset: srcCfg.themePreset ?? null,
      };
    }
    const res = await applyBranchConfig(targetId, domains, { by, what: 'config-copied', from: `branch:${sourceId}` });
    results.push({
      targetId,
      ok: res.ok && !res.reason,
      fields: res.updatedFields || [],
      ...(res.reason ? { reason: res.reason } : {}),
    });
  }
  return results;
}

/** 支部组织档案读取（name/headerTitle/desc/themePreset 收口，UI 勿逐键直连 config） */
export function getBranchOrg(branchId) {
  const b = getBranchById(branchId);
  return {
    id: b?.id || null,
    name: b?.name || '',
    type: b?.type || '',
    secretaryId: b?.secretaryId || null,
    headerTitle: b?.config?.headerTitle || b?.name || '',
    desc: b?.config?.desc || '',
    themePreset: b?.config?.themePreset ?? null,
  };
}

// ── 立项⑤ 阶段A · 空模板/空支部引用审计分层（2026-09-06）──────────────
// 空模板与「空模板初始化」产出的支部记录应满足：不含业务域键、不含支部成员 id（学号/工号）、
// 席位空缺（无 secretaryId 任命）。纯校验函数供测试/审计断言使用（mock-integrity 演示侧不动）。

/** 空支部记录不应携带的业务域键（全域单支部演示下新建支部不产生业务引用；含即异常） */
const EMPTY_BRANCH_FORBIDDEN_DOMAIN_KEYS = [
  'people', 'members', 'memberIds', 'activities', 'attendances', 'inspections',
  'agenda', 'agendaVotes', 'taskforces', 'notices', 'todos', 'assignments',
  'makeupTasks', 'thoughtReports', 'reviews', 'archiveRecords', 'signups',
];

/** 支部成员 id（学号/工号）集合——审计空支部记录时用于识别成员引用；党委组织员 branchId:null 不在其中 */
const BRANCH_MEMBER_IDS = new Set(PEOPLE.filter((p) => p.branchId !== null && p.branchId !== undefined).map((p) => p.id));

function _referencesBranchMember(value) {
  if (typeof value === 'string') return BRANCH_MEMBER_IDS.has(value);
  if (Array.isArray(value)) return value.some(_referencesBranchMember);
  if (value && typeof value === 'object') return Object.values(value).some(_referencesBranchMember);
  return false;
}

/**
 * 引用审计（纯）：空模板/新建空支部记录不得引用演示业务数据。
 * @param {Object} branch 待审计支部记录（空模板常量或 createBranch 产物）
 * @returns {string|null} null=通过；否则返回问题描述
 */
export function auditEmptyBranchRecord(branch) {
  if (!branch || typeof branch !== 'object' || Array.isArray(branch)) return '记录非对象';
  const present = EMPTY_BRANCH_FORBIDDEN_DOMAIN_KEYS.filter(k => branch[k] !== undefined && branch[k] !== null && branch[k] !== '');
  if (present.length) return `含业务域键：${present.join('、')}`;
  // 不含支部成员 id（学号/工号 = 人员主键）；留痕 by 允许党委组织员（组织级、branchId:null）
  if (_referencesBranchMember(branch)) return '含支部成员 id 引用';
  if (branch.secretaryId) return '含 secretaryId（席位应空缺待任命）';
  return null;
}
