// role: [工程师]+[AI]
// ════════════════════════════════════════════════════════════════
//  service.taskforce.js — 专班数据模型
//  提供 TaskForceRecordStore：专班的 CRUD + mockDB 持久化
//  关联 ActivityRecordStore 用于活动维度的专班关联
// ════════════════════════════════════════════════════════════════

import {
  mockDB, TaskforceStatus, TASKFORCE_TERMINAL_STATUSES, TASKFORCE_PRE_OPEN_STATUSES,
  TASKFORCE_DIRECT_TRANSITIONS, WorkgroupStatus, workgroupStatusForTaskforce,
  TASK_TERMINAL_STATUSES, OUTPUT_TERMINAL_STATUSES,
} from '../../core/domain/domain.js?v=20261028a';
import { getAdapter, getDataSource, notifyDataChanged, persist, refreshRemoteCollections } from '../../data/data-adapter.js?v=20261028a';
import { bumpToken } from '../../core/base/version-token.js?v=20261028a'; // P0 域缓存失效（spec §二.3）
import { MOCK_TASKFORCES } from '../../data/mock/index.js?v=20261028a';
import { isInitStateActive } from '../core/init-reset.js?v=20261028a'; // C2 修复（2026-09-08）：init 态跳过演示种子兜底
import { getPersonName } from '../member/person.js?v=20261028a';
import { evaluateWorkforceVotes } from '../branch/workforce.js?v=20261028a';
// 附录⑩ B批（3.3）专班议案排入支委会表决所需的活动/通知基建：
// 与 services/branch/workforce.js 同路径（BranchService.createActivity + NoticeStore.add），
// 仅函数体内使用（懒加载语义），不新增模块初始化期副作用。
import { BranchService } from '../core/runtime.js?v=20261028a';
import { NoticeStore } from '../governance/notice.js?v=20261028a';
import { defaultVoteConfig, resolveVoterIds } from './vote-config.js?v=20261028a';
import { loadActivities } from './activity.js?v=20261028a';
import { AuthStore } from '../core/auth.js?v=20261028a';
import { DEFAULT_BRANCH_ID, BRANCH_COMMISSION_ROLES } from '../../core/domain/constants.js?v=20261028a'; // 支委层应到名单单一源（勿手写）
import { generateId } from '../../core/base/id.js?v=20261028a';
import { todayLocal } from '../../core/base/utils.js?v=20261028a';

// 附录⑩ B批（S3 专班生命周期 · 支书裁定 2026-09-06）：
//   治理按事项判定：仅制度或议程明确要求的发起/解散事项进入支委会表决；其余按业务流程办理并留痕。
//   R3-3：成员贡献=成员填报（addContributions 写口，by=填报成员）、组织委员逐条核
//     （verifyContributions：同意入档 / 退回补料，全程留痕）；纪检结项复盘兜底。
//   数据形态（无新顶层域）：专班记录字段 committeeRequest = 当前待表决请求，
//     committeeDecision[] = 历次表决留痕（append-only）。status/approvalStatus 沿用既有语义。

const TASKFORCE_STORAGE_KEY = 'workflowos_taskforces_v1';
const COMMITTEE_DISSOLUTION_WRITE = Symbol('committee-dissolution-write');

function _mockTaskforceClosureReady(taskforce) {
  const workgroupId = taskforce?.workgroupId || `wg-taskforce-${taskforce?.id}`;
  const tasks = (Array.isArray(mockDB.workgroupTasks) ? mockDB.workgroupTasks : [])
    .filter((task) => task.workgroupId === workgroupId);
  const outputs = (Array.isArray(mockDB.workgroupOutputs) ? mockDB.workgroupOutputs : [])
    .filter((output) => output.workgroupId === workgroupId);
  return tasks.length > 0
    && tasks.every((task) => TASK_TERMINAL_STATUSES.includes(task.status))
    && outputs.every((output) => OUTPUT_TERMINAL_STATUSES.includes(output.status));
}

function _isApprovedDissolution(current, updated) {
  const previousDecisions = Array.isArray(current?.committeeDecision) ? current.committeeDecision : [];
  const nextDecisions = Array.isArray(updated?.committeeDecision) ? updated.committeeDecision : [];
  const decision = nextDecisions.at(-1);
  return current?.status === TaskforceStatus.ACTIVE
    && current.committeeRequest?.kind === 'dissolve'
    && current.committeeRequest?.status === 'pending'
    && updated?.status === TaskforceStatus.DISSOLVED
    && updated.committeeRequest === null
    && nextDecisions.length === previousDecisions.length + 1
    && decision?.kind === 'dissolve'
    && decision?.decision === 'approved'
    && !!decision?.decisionRef;
}

function _loadTaskForces() {
  try {
    return [...mockDB.taskforces];
  } catch (e) {
    console.warn('[TaskForceRecordStore] 加载失败：', e);
    return [];
  }
}

function _saveTaskForces(records) {
  try {
    mockDB.taskforces = [...records];
    bumpToken('taskforce'); // P0：专班写口统一 bump（add/update/remove/表决落果/贡献核验等均经本函数）
    persist();
  } catch (e) {
    console.warn('[TaskForceRecordStore] 保存失败：', e);
  }
}

export const TaskForceRecordStore = {
  _records: [],

  init() {
    const persisted = _loadTaskForces();
    if (persisted.length > 0) {
      this._records = persisted;
    } else if (getDataSource() === 'api') {
      // API 返回空集合是合法的支部状态；禁止把演示种子灌进服务器快照。
      this._records = [];
    } else if (isInitStateActive()) {
      // C2 修复（2026-09-08）：init 态下「无持久化专班 = 合法空支部态」——不兜底演示种子
      //（否则 MOCK_TASKFORCES 会经 _saveTaskForces 重新写回 mockDB/持久层）。
      this._records = [];
    } else {
      this._records = [...MOCK_TASKFORCES];
      _saveTaskForces(this._records);
    }

    const migrationResult = this.migrateFromLegacy();
    if (migrationResult.migrated > 0) {
      console.log('[TaskForceRecordStore] 历史数据迁移完成：', migrationResult.report);
    } else if (migrationResult.report.length > 0) {
      console.info('[TaskForceRecordStore] 发现含义待核对的历史键，原始数据已保留：', migrationResult.report);
    }
  },

  list(filter = {}) {
    // 软删除记录（deletedAt 留痕）不进入业务视图
    let result = this._records.filter(r => !r.deletedAt);

    if (filter.status) {
      result = result.filter(r => r.status === filter.status);
    }

    if (filter.manager) {
      result = result.filter(r => r.manager === filter.manager);
    }

    if (filter.activityId) {
      result = result.filter(r => r.activityId === filter.activityId);
    }

    result.sort((a, b) => b.createdAt.localeCompare(a.createdAt));

    return result;
  },

  add(record) {
    const newRecord = {
      ...record,
      id: record.id || generateId('tf', '-'),
      createdAt: record.createdAt || todayLocal(),
      members: record.members || [],
      status: record.status || TaskforceStatus.RECRUITING,
    };
    this._records = [...this._records, newRecord];
    _saveTaskForces(this._records);
    // 派生赋权待办给组织委员（最小三成本原则·阶段1C-3）
    // T-190：招募时已内联选初始成员（members 非空）则不再派生；未选人保留待办兜底
    // 使用 dynamic import 避免与 todo.js 的潜在循环依赖
    // 联动赋权（`R-29⑤` · `D-804` 批次 425）：**收件人取 `taskforce` 模块主责**——把本支部**分工快照**
    //   一并传进去；`branch.js` 亦走动态 import（与 todo.js 同法，免成环）。
    if (!newRecord.members || newRecord.members.length === 0) {
      const me = AuthStore.getCurrentUser && AuthStore.getCurrentUser();
      const pid = newRecord.manager || newRecord.initiator || (me && (me.personId || me.id)) || null;
      Promise.all([
        import('../governance/todo.js?v=20261028a'),
        import('../branch/branch.js?v=20261028a'),
      ]).then(([{ LifecycleTodoDeriver }, branch]) => {
        const snapshot = branch.getBranchWorkforce(branch.getBranchIdOfPerson(pid));
        LifecycleTodoDeriver.deriveFromTaskforceCreate(newRecord, { snapshot });
      }).catch(e => console.warn('[TaskForceRecordStore] 派生专班赋权待办失败：', e));
    }
    return newRecord;
  },

  /** 创建专班时走语义写口：服务端与 mock 都同时建立工作组、成员和主任务。 */
  async create(record) {
    const actor = AuthStore.getCurrentUser?.();
    const payload = {
      ...record,
      id: record.id || generateId('tf', '-'),
      branchId: record.branchId || actor?.branchId || DEFAULT_BRANCH_ID,
      createdAt: record.createdAt || todayLocal(),
      members: Array.isArray(record.members) ? record.members : [],
      status: record.status || TaskforceStatus.RECRUITING,
    };
    const created = await getAdapter().taskforces.create(payload);
    if (!created?.id) return null;
    this._records = [...this._records.filter((row) => row.id !== created.id), created];
    mockDB.taskforces = [...mockDB.taskforces.filter((row) => row.id !== created.id), created];
    bumpToken('taskforce');
    notifyDataChanged();
    // MockAdapter 自己派生无成员的赋权待办；API 服务端已建组，但仍由前端既有派生器建同一待办。
    if (getDataSource() === 'api' && created.members.length === 0) {
      const actorId = created.manager || created.initiator || actor?.personId || actor?.id || null;
      Promise.all([
        import('../governance/todo.js?v=20261028a'),
        import('../branch/branch.js?v=20261028a'),
      ]).then(([{ LifecycleTodoDeriver }, branch]) => {
        const snapshot = branch.getBranchWorkforce(branch.getBranchIdOfPerson(actorId));
        LifecycleTodoDeriver.deriveFromTaskforceCreate(created, { snapshot });
      }).catch((error) => console.warn('[TaskForceRecordStore] 派生专班赋权待办失败：', error));
    }
    return created;
  },

  update(id, patch, writePermit = null) {
    const idx = this._records.findIndex(r => r.id === id);
    if (idx === -1) return null;
    const current = this._records[idx];
    const updated = { ...current, ...patch };
    if (TASKFORCE_TERMINAL_STATUSES.includes(updated.status) && updated.status !== current.status) {
      const approvedDissolution = writePermit === COMMITTEE_DISSOLUTION_WRITE
        && _isApprovedDissolution(current, updated)
        && (getDataSource() !== 'mock' || _mockTaskforceClosureReady(current));
      if (!approvedDissolution) return null;
    }
    // 工作组状态随专班状态同源更新（draft/pending_review/recruiting/active/terminal 全部映射），
    // 避免专班已通过发起表决而工作组仍停在 pending_review、被写权限判据误锁。
    if (patch.status && patch.status !== current.status) {
      const workgroupId = updated.workgroupId || `wg-taskforce-${updated.id}`;
      mockDB.workgroups = (Array.isArray(mockDB.workgroups) ? mockDB.workgroups : []).map((workgroup) => (
        workgroup.id === workgroupId
          ? { ...workgroup, status: workgroupStatusForTaskforce(updated.status) }
          : workgroup
      ));
    }
    this._records = [
      ...this._records.slice(0, idx),
      updated,
      ...this._records.slice(idx + 1),
    ];
    _saveTaskForces(this._records);
    return updated;
  },

  // 仅保留招募启动的普通状态流转；运行中工作组必须通过语义收尾写口结束。
  updateStatus(id, newStatus) {
    const tf = this._records.find(r => r.id === id);
    if (!tf) return null;
    const allowed = TASKFORCE_DIRECT_TRANSITIONS[tf.status] || [];
    if (!allowed.includes(newStatus)) return null;
    return this.update(id, { status: newStatus });
  },

  /** 按事项办理收尾；只有明确的制度/议程依据才提交支委会表决。 */
  async dissolve(id, { requiresCommitteeVote = false, governanceReason = '', note = '', by = null } = {}) {
    const current = this._records.find((record) => record.id === id);
    const basis = String(governanceReason || '').trim();
    if (!current || current.status !== TaskforceStatus.ACTIVE || current.committeeRequest?.status === 'pending') return null;
    if (typeof requiresCommitteeVote !== 'boolean' || (requiresCommitteeVote && !basis)) return null;
    const result = await getAdapter().taskforces.dissolve(id, {
      requiresCommitteeVote, governanceReason: basis, note: String(note || '').trim(), by: by || null,
    });
    const updated = result?.taskforce;
    if (!updated) return null;
    this._records = this._records.map((record) => record.id === id ? updated : record);
    mockDB.taskforces = mockDB.taskforces.map((record) => record.id === id ? updated : record);
    if (result.workgroup) {
      mockDB.workgroups = mockDB.workgroups.map((workgroup) => workgroup.id === result.workgroup.id ? result.workgroup : workgroup);
    }
    bumpToken('taskforce');
    notifyDataChanged();
    return updated;
  },

  async listWorkgroupTasks(id) {
    const record = this._records.find((item) => item.id === id);
    if (!record) return [];
    const workgroupId = record.workgroupId || `wg-taskforce-${record.id}`;
    let tasks = await getAdapter().workgroups.tasks.list(workgroupId);
    // Mock 旧数据也需要把原任务说明变成可闭合记录；API 端点则服务端惰性迁移。
    if (!tasks.length && String(record.task || '').trim()) {
      try {
        await getAdapter().workgroups.tasks.create(workgroupId, {
          id: `wgt-purpose-${record.id}`, title: String(record.task).trim(), isPurpose: true,
        });
        tasks = await getAdapter().workgroups.tasks.list(workgroupId);
      } catch (error) {
        if (!/已存在|exists/i.test(String(error?.message || ''))) throw error;
        tasks = await getAdapter().workgroups.tasks.list(workgroupId);
      }
    }
    mockDB.workgroupTasks = [...mockDB.workgroupTasks.filter((task) => task.workgroupId !== workgroupId), ...tasks];
    return tasks;
  },

  async listWorkgroupOutputs(id) {
    const record = this._records.find((item) => item.id === id);
    if (!record) return [];
    const workgroupId = record.workgroupId || `wg-taskforce-${record.id}`;
    const outputs = await getAdapter().workgroups.outputs.list(workgroupId);
    mockDB.workgroupOutputs = [...mockDB.workgroupOutputs.filter((item) => item.workgroupId !== workgroupId), ...outputs];
    return outputs;
  },

  async createWorkgroupTask(id, data = {}) {
    const record = this._records.find((item) => item.id === id);
    if (!record) return null;
    const workgroupId = record.workgroupId || `wg-taskforce-${record.id}`;
    const task = await getAdapter().workgroups.tasks.create(workgroupId, data);
    mockDB.workgroupTasks = [...mockDB.workgroupTasks.filter((item) => item.id !== task.id), task];
    notifyDataChanged();
    return task;
  },

  async createWorkgroupOutput(id, data = {}) {
    const record = this._records.find((item) => item.id === id);
    if (!record) return null;
    const workgroupId = record.workgroupId || `wg-taskforce-${record.id}`;
    const output = await getAdapter().workgroups.outputs.create(workgroupId, data);
    mockDB.workgroupOutputs = [...mockDB.workgroupOutputs.filter((item) => item.id !== output.id), output];
    notifyDataChanged();
    return output;
  },

  async updateWorkgroupTask(id, taskId, patch = {}) {
    const record = this._records.find((item) => item.id === id);
    if (!record) return null;
    const workgroupId = record.workgroupId || `wg-taskforce-${record.id}`;
    const currentUser = AuthStore.getCurrentUser?.();
    const updated = await getAdapter().workgroups.tasks.update(workgroupId, taskId, {
      ...patch, by: currentUser?.personId || currentUser?.id || null,
    });
    mockDB.workgroupTasks = [...mockDB.workgroupTasks.filter((task) => task.id !== taskId), updated];
    notifyDataChanged();
    return updated;
  },

  remove(id) {
    const prev = this._records.length;
    this._records = this._records.filter(r => r.id !== id);
    if (this._records.length === prev) return false;
    _saveTaskForces(this._records);
    return true;
  },

  /**
   * 软删除（B6③ 2026-09-12）：撤销并删除专班——记录保留 deletedAt/deletedBy 留痕（可审计），
   * 从 list/getAll 业务视图剔除；替代不可恢复的物理删除。
   */
  softRemove(id, { by = null } = {}) {
    const idx = this._records.findIndex(r => r.id === id);
    if (idx === -1) return false;
    this._records = [
      ...this._records.slice(0, idx),
      { ...this._records[idx], deletedAt: new Date().toISOString(), deletedBy: by || null },
      ...this._records.slice(idx + 1),
    ];
    _saveTaskForces(this._records);
    return true;
  },

  // ══════════════════════════════════════════════════════════════
  //  专班中间进度（立项③阶段a · 最小闭环）
  //  数据域：mockDB.taskforces[].progressList
  //  数组项：{ id:'tp-'+时间戳, stage, note, by, at }
  //  语义：组织委员在运行中（active）专班分阶段填报进展，
  //        纪检委员/党小组组长经只读专班查看（taskforce-view）可见；
  //  兼容旧数据：老专班无 progressList 字段（undefined）按 [] 读写，不报错。
  // ══════════════════════════════════════════════════════════════

  /** 追加一条中间进度（写仅组织委员；by=填报人 personId，由调用方传入） */
  addTaskforceProgress(taskforceId, { stage = '', note = '', by = null } = {}) {
    const tf = this._records.find(r => r.id === taskforceId);
    if (!tf || !String(note || '').trim()) return null;
    const list = Array.isArray(tf.progressList) ? tf.progressList : [];
    const item = {
      id: generateId('tp', '-'),
      stage: String(stage || '').trim(),
      note: String(note).trim(),
      by: by || null,
      at: new Date().toISOString(),
    };
    return this.update(taskforceId, { progressList: [...list, item] });
  },

  /** 删除一条中间进度（按记录 id；by=当前操作者 personId，本人可删校验） */
  removeTaskforceProgress(taskforceId, progressId, by = null) {
    const tf = this._records.find(r => r.id === taskforceId);
    if (!tf) return null;
    const list = Array.isArray(tf.progressList) ? tf.progressList : [];
    const target = list.find(p => p && p.id === progressId);
    if (!target) return null;
    // 本人可删：仅填报人本人可删；记录无 by（旧数据）时不拦截
    if (by && target.by && target.by !== by) return null;
    return this.update(taskforceId, { progressList: list.filter(p => p && p.id !== progressId) });
  },

  /**
   * 加入专班成员（R9 Task 4.2 单一源）：
   *   ① 先写**工作组主源** `workgroup_members`（适配器 `members.add`，服务端同事务回写
   *      `taskforces.members` 兼容镜像；旧镜像此后只读保留）；
   *   ② 再把服务端 / mock 权威行同步进本店缓存，供同步读口立即看到。
   * 失败不落本地镜像（不制造「界面加上了、主源没写」的假成功）。
   * @returns {Promise<Object|null>} 同步后的专班记录
   */
  async addMember(tfId, member) {
    const tf = this._records.find(r => r.id === tfId);
    if (!tf || !member?.personId) return null;
    const workgroupId = tf.workgroupId || `wg-taskforce-${tfId}`;
    let addedRow = null;
    try {
      addedRow = await getAdapter().workgroups.members.add(workgroupId, { personId: member.personId, role: member.role });
    } catch (e) {
      console.warn('[TaskForceRecordStore] 专班成员写入工作组主源失败：', e);
      return null;
    }
    // D11：把服务端返回的成员行并入 mockDB.workgroupMembers（按 id / workgroupId+personId 去重）——
    //   组织台同屏读的是这份缓存，不并入就得等下一次全量刷新才看得到新成员。
    if (addedRow && addedRow.personId) {
      const rows = Array.isArray(mockDB.workgroupMembers) ? mockDB.workgroupMembers : [];
      const idx = rows.findIndex((row) => row && (row.id === addedRow.id
        || (row.workgroupId === workgroupId && row.personId === addedRow.personId)));
      mockDB.workgroupMembers = idx >= 0
        ? rows.map((row, i) => (i === idx ? { ...row, ...addedRow } : row))
        : [...rows, addedRow];
    }
    const stored = (Array.isArray(mockDB.taskforces) ? mockDB.taskforces : []).find(r => r.id === tfId) || tf;
    const mirrored = (Array.isArray(stored.members) && stored.members.some(m => m?.personId === member.personId))
      ? stored
      : { ...stored, members: [...(stored.members || []), { ...member, contributions: member.contributions || [] }] };
    this._records = this._records.map(r => r.id === tfId ? mirrored : r);
    bumpToken('taskforce');
    mockDB.taskforces = (Array.isArray(mockDB.taskforces) ? mockDB.taskforces : [])
      .map(r => r.id === tfId ? mirrored : r);
    if (getDataSource() === 'mock') {
      persist();
    } else {
      // 服务端成员端点已 bump taskforces 版本 ⇒ 重拉缓存与版本基线，避免后续快照以陈旧成员表撞 409/403。
      try {
        await refreshRemoteCollections(['taskforces']);
        const authoritative = (Array.isArray(mockDB.taskforces) ? mockDB.taskforces : []).find(r => r.id === tfId);
        if (authoritative) this._records = this._records.map(r => r.id === tfId ? authoritative : r);
      } catch (e) {
        console.warn('[TaskForceRecordStore] 专班成员写入后刷新缓存失败（本地镜像已保留）：', e);
      }
      notifyDataChanged();
    }
    return mirrored;
  },

  // ══════════════════════════════════════════════════════════════
  //  成员贡献录入/填报（立项③阶段b · 写入位补全）
  //  数据域：mockDB.taskforces[].members[].contributions
  //  数组项：种子为字符串摘要（历史只读形态）；本次写入为对象条目
  //         { id: generateId('tc','-'), desc, by, at }
  //  语义：附录⑩ B批（S3 R3-3，2026-09-06 支书裁定）起，写口=专班成员本人逐条填报
  //        （by=填报人）或组织委员代录，随后由组织委员 verifyContributions 逐条核
  //        （同意入档 / 退回补料，留痕）。历史字符串条目不参与核验（只读展示）。
  //  兼容旧数据：老成员无 contributions 字段（undefined）按 [] 处理。
  // ══════════════════════════════════════════════════════════════

  /**
   * 录入/填报贡献（by=填报成员本人或组织委员代录；desc 非空且 personIds 均为该专班成员才受理）
   * R9 Task 4.2：贡献先进**工作组主源** `workgroup_outputs`（每人一条产出，kind='contribution'）；
   *   `taskforces.members[].contributions` 作为兼容镜像同步（旧核验读口只读沿用）。
   *   本地镜像在首个 await 前同步落好（旧同步读口保持即时可见），主源写入失败仅告警不吞业务事实。
   */
  async addContributions(taskforceId, { personIds = [], desc = '', by = null } = {}) {
    const tf = this._records.find(r => r.id === taskforceId);
    const note = String(desc || '').trim();
    const ids = Array.isArray(personIds) ? [...new Set(personIds.filter(Boolean))] : [];
    if (!tf || !note || ids.length === 0) return null;
    // 校验：所选人员必须均为该专班成员（含历史数据无 personId 的成员条目过滤）
    const memberIds = (tf.members || []).map(m => m && m.personId);
    if (!ids.every(pid => memberIds.includes(pid))) return null;
    const at = new Date().toISOString();
    const addedIds = [];
    const members = (tf.members || []).map(m => {
      if (!m || !ids.includes(m.personId)) return m;
      const list = Array.isArray(m.contributions) ? m.contributions : [];
      const entry = { id: generateId('tc', '-'), desc: note, by: by || null, at };
      addedIds.push({ personId: m.personId, contributionId: entry.id });
      return { ...m, contributions: [...list, entry] };
    });
    const updated = this.update(taskforceId, { members });
    if (!updated) return null;
    // 工作组主源：产出登记（mock / api 适配器同名口）
    try {
      const adapter = getAdapter();
      const workgroupId = tf.workgroupId || `wg-taskforce-${taskforceId}`;
      for (const item of addedIds) {
        const output = await adapter.workgroups.outputs.create(workgroupId, {
          title: note, description: note, personId: item.personId,
          kind: 'contribution', contributionId: item.contributionId,
        });
        if (output?.id) {
          mockDB.workgroupOutputs = [
            ...(Array.isArray(mockDB.workgroupOutputs) ? mockDB.workgroupOutputs : []).filter((row) => row.id !== output.id),
            output,
          ];
        }
      }
      notifyDataChanged();
    } catch (e) {
      console.warn('[TaskForceRecordStore] 贡献写入工作组产出失败（镜像已保留）：', e);
    }
    return { added: ids.length };
  },

  getAll() {
    // 软删除记录（deletedAt 留痕）不进入业务视图
    return this._records.filter(r => !r.deletedAt);
  },

  // ══════════════════════════════════════════════════════════════
  //  旧 localStorage 专班相关键 — 保留待人工核对
  //  旧白名单不足以判断工作组任务、类别、责任人与结束状态，不自动转换或删除
  // ══════════════════════════════════════════════════════════════

  _migrationReport: [],

  migrateFromLegacy() {
    const legacyPatterns = [
      /propaganda/i,
      /whitelist/i,
      /宣传.*专班/i,
      /taskforce.*legacy/i,
      /prop_.*roster/i,
      /sop.*white/i,
    ];

    const allKeys = [];
    for (let i = 0; i < localStorage.length; i++) {
      allKeys.push(localStorage.key(i));
    }

    const candidateKeys = allKeys.filter(k =>
      legacyPatterns.some(p => p.test(k)) && k !== TASKFORCE_STORAGE_KEY
    );

    if (candidateKeys.length === 0) return { migrated: 0, report: [] };

    const report = [];
    candidateKeys.forEach(legacyKey => {
      try {
        const raw = localStorage.getItem(legacyKey);
        if (!raw) return;
        const value = JSON.parse(raw);
        const count = Array.isArray(value)
          ? value.length
          : Array.isArray(value?.members) ? value.members.length : null;
        report.push({
          key: legacyKey,
          count,
          status: 'needs-review',
          reason: '旧数据不能确定工作组任务、类型、成员角色或结束状态；原样保留，需人工核对后经语义接口登记。',
        });
      } catch (e) {
        report.push({ key: legacyKey, status: 'failed', error: e.message });
      }
    });

    this._migrationReport = report;
    return { migrated: 0, report };
  },

  // ══════════════════════════════════════════════════════════════
  //  专班支委会表决域（附录⑩ B批 · S3 R3-1/R3-2 · 支书裁定 2026-09-06）
  //  数据域：mockDB.taskforces[].committeeRequest / committeeDecision[]
  //  形态：报送归集·例会表决——申请方将发起或解散「报送支委会」，归集为待议；
  //        支书召开线上支委会时纳入表决（判据=R2-3：应到严格 >2/3 出席且无反对，
  //        object/oppose 均视为反对、弃权允许——透传 services/branch/workforce.js
  //        evaluateWorkforceVotes 单一判据），达标后 applyCommitteeDecision 落结果。
  //  语义：committeeRequest.status='pending' 期间专班保持现态（只读等待）；
  //        表决落果后请求清空、留痕 committeeDecision[]（append-only）。
  // ══════════════════════════════════════════════════════════════

  /** 报送支委会（发起或解散）：kind 'initiate'=发起 / 'dissolve'=中途解散；by=报送人 */
  submitForCommittee(tfId, { kind = 'initiate', by = null, note = '' } = {}) {
    const tf = this._records.find(r => r.id === tfId);
    if (!tf) return null;
    const valid = kind === 'initiate'
      ? TASKFORCE_PRE_OPEN_STATUSES.includes(tf.status) // 新发起 / 未通过后修改重报
      : kind === 'dissolve'
        ? tf.status === TaskforceStatus.ACTIVE          // 仅运行中可报解散
        : false;
    if (!valid) return null;
    return this.update(tfId, {
      committeeRequest: {
        kind,
        by: by || null,
        note: String(note || '').trim(),
        at: new Date().toISOString(),
        status: 'pending',
      },
    });
  },

  /** 支委会表决判据（R2-3：应到严格 >2/3 出席且无反对）——透传 workforce 单一判据 */
  evaluateCommitteeVote({ roster = [], votes = [], agendaItemId = null }) {
    return evaluateWorkforceVotes({ roster, votes, agendaItemId });
  },

  /** 归集视图数据：全部「待支委会表决」的报送（供支书线上支委会纳入表决） */
  listCommitteeRequests() {
    return this._records
      .filter(r => !r.deletedAt && r.committeeRequest && r.committeeRequest.status === 'pending')
      .map(r => ({
        id: r.id,
        name: r.name || '',
        task: r.task || '',
        status: r.status,
        kind: r.committeeRequest.kind,
        note: r.committeeRequest.note || '',
        by: r.committeeRequest.by,
        at: r.committeeRequest.at,
        initiator: r.initiator || null,
        createdAt: r.createdAt || '',
        deadline: r.deadline || '',
      }))
      .sort((a, b) => (a.at || '').localeCompare(b.at || '')); // 先报先议
  },

  /**
   * 应用支委会表决结果：approved=执行（发起→招募中；解散→已解散+时间戳留痕）；
   * rejected=退回（发起→草稿可改重报；解散→回运行中）。请求清空、留痕 append-only。
   * @param {Object} opts
   * @param {'approved'|'rejected'} [opts.decision]
   * @param {Object|null} [opts.outcome]  判定 tally（透传 evaluateCommitteeVote 结果供展示）
   * @param {string|null} [opts.decisionRef] 表决来源（如支委会活动 id+议程项 id）
   */
  applyCommitteeDecision(tfId, { decision = 'approved', outcome = null, by = null, note = '', decisionRef = null } = {}) {
    const tf = this._records.find(r => r.id === tfId);
    if (!tf || !tf.committeeRequest || tf.committeeRequest.status !== 'pending') return null;
    const req = tf.committeeRequest;
    if (!['approved', 'rejected'].includes(decision)) return null;
    const decisions = Array.isArray(tf.committeeDecision) ? tf.committeeDecision : [];
    const trace = {
      kind: req.kind,
      decision,
      by: by || null,
      note: String(note || '').trim(),
      at: new Date().toISOString(),
      outcome: outcome || null,
      decisionRef: decisionRef || null,
    };
    let patch = { committeeRequest: null, committeeDecision: [...decisions, trace] };
    if (req.kind === 'initiate') {
      patch.status = decision === 'approved' ? TaskforceStatus.RECRUITING : TaskforceStatus.DRAFT;
      patch.approvalStatus = decision; // approved / rejected（UI 展示：已通过 / 未通过）
    } else if (req.kind === 'dissolve') {
      if (decision === 'approved') {
        patch.status = TaskforceStatus.DISSOLVED;
        patch.dissolvedAt = todayLocal();
      } else {
        patch.status = TaskforceStatus.ACTIVE; // 未通过：专班保持运行中
      }
    }
    const updated = this.update(tfId, patch, COMMITTEE_DISSOLUTION_WRITE);
    if (updated && req.kind === 'dissolve' && decision === 'approved') {
      const workgroupId = tf.workgroupId || `wg-taskforce-${tf.id}`;
      mockDB.workgroups = mockDB.workgroups.map((workgroup) => workgroup.id === workgroupId
        ? { ...workgroup, status: WorkgroupStatus.DISSOLVED, updatedAt: trace.at, updatedBy: by || null }
        : workgroup);
      if (getDataSource() === 'mock') persist();
    }
    return updated;
  },

  // ══════════════════════════════════════════════════════════════
  //  成员贡献逐条核（附录⑩ B批 · S3 R3-3 · 支书裁定 2026-09-06）
  //  语义：成员在专班内逐条填报产出（addContributions，by=填报人）→ 组织委员逐条核
  //    （verifyContributions：同意入档 / 退回补料，全程留痕）；纪检结项复盘兜底。
  //  仅作用于对象形态条目 { id, desc, by, at }；历史字符串摘要不参与核验（只读展示）。
  // ══════════════════════════════════════════════════════════════

  /** 逐条核验贡献：'approve' 同意入档 / 'reject' 退回补料；已核条目幂等跳过 */
  verifyContributions(tfId, { contributionIds = [], decision = 'approve', by = null, note = '' } = {}) {
    const tf = this._records.find(r => r.id === tfId);
    const ids = Array.isArray(contributionIds) ? [...new Set(contributionIds.filter(Boolean))] : [];
    if (!tf || !['approve', 'reject'].includes(decision) || ids.length === 0) return null;
    const at = new Date().toISOString();
    let updated = 0;
    const members = (tf.members || []).map(m => {
      if (!m) return m;
      const list = Array.isArray(m.contributions) ? m.contributions : [];
      let changed = false;
      const next = list.map(c => {
        if (!c || typeof c !== 'object' || !c.id || !ids.includes(c.id)) return c;
        if (c.verifiedStatus) return c; // 已核幂等跳过
        changed = true;
        updated += 1;
        return decision === 'approve'
          ? { ...c, verifiedStatus: 'approved', verifiedBy: by || null, verifiedAt: at, rejectNote: undefined }
          : { ...c, verifiedStatus: 'rejected', verifiedBy: by || null, verifiedAt: at, rejectNote: String(note || '').trim() };
      });
      return changed ? { ...m, contributions: next } : m;
    });
    if (updated === 0) return { updated: 0 };
    this.update(tfId, { members });
    return { updated };
  },
};

// ══════════════════════════════════════════════════════════════
//  专班议案 → 线上支委会表决活动（附录⑩ B批 · 3.2-3 / 3.3）
//  支书在待办页「专班待议（支委会）」将专班报送（发起/解散）排入表决：
//  以 BranchService.createActivity（services/core/mock.js 的通用创建口，禁用的
//  calendar-tab UI 向导不是服务函数）创建一场 type='支委会' 的线上表决活动；
//  委员沿用既有「活动详情在线表态」（activity.html / inspector），本服务不实现投票 UI。
//  字段要求（3.3）：type='支委会'、status='published'、scenarioId='branch-committee'、
//    voteConfig 与 defaultVoteConfig('branch-committee') 一致 + voterIds 固化现时支委应到名单
//    （resolveVoterIds('committee')，roster 口径；历史活动快照不回改）、
//    agenda 含带 id 的审议项（表决面板/记录结果均以议程项 id 关联 agendaVotes）、
//    extras.taskforceProposal 挂专班关联供「查看表决结果并生效」反查。
//  说明：本次做成「新增活动 + 发通知/待办提示」，暂不派生其它任务（最小可演示闭环）。
// ══════════════════════════════════════════════════════════════

/** 专班报送 kind → 中文标签（活动标题/议程文案共用） */
function _taskforceProposalKindLabel(kind) {
  return kind === 'dissolve' ? '解散' : '发起';
}

/**
 * 创建专班议案的线上支委会表决活动（3.3 服务小助手）
 * @param {Object} params
 * @param {string} params.taskforceId 专班 id
 * @param {'initiate'|'dissolve'} [params.kind] 报送类型（缺省读专班当前 committeeRequest.kind）
 * @param {string} [params.note] 报送说明（写入活动描述）
 * @returns {Promise<Object>} 创建的 activity
 * @throws 专班不存在 / 当前无待表决报送时抛错（由调用方 toast 提示）
 */
export async function createTaskforceVoteActivity({ taskforceId, kind = 'initiate', note = '' } = {}) {
  const tf = TaskForceRecordStore.getAll().find(r => r.id === taskforceId);
  if (!tf) throw new Error('专班不存在，无法排入表决');
  const req = (tf.committeeRequest && tf.committeeRequest.status === 'pending') ? tf.committeeRequest : null;
  if (!req) throw new Error('该专班当前无待支委会表决的报送，无需排入');
  const reqKind = (kind === 'initiate' || kind === 'dissolve') ? kind : req.kind;
  const name = tf.name || '未命名专班';
  const kindLabel = _taskforceProposalKindLabel(reqKind);
  const today = todayLocal();
  const voterIds = resolveVoterIds('committee');
  if (!voterIds.length) throw new Error('支委名单不可用：请先维护成员角色（secretary/副支书/三委员）后再排入表决');
  const me = AuthStore.getCurrentUser();
  // P1-11：排入人必须真实登录人——不再回落到支书 p13（否则 organizer/assignments 记到别人名下）。
  if (!me?.personId) throw new Error('登录态已失效，请重新登录后再排入表决');
  const byName = req.by ? getPersonName(req.by) : '组织委员';
  const atText = String(req.at || '').slice(0, 16).replace('T', ' ') || '';
  // assignments 非空 → BranchService.createActivity 不再派生「组长赋权」待办（最小噪音）；
  // 组织者 = 当前排入人（支书工作台操作），参与者 = 应到支委（表决名单由 voteConfig.voterIds 固化）
  const activity = await BranchService.createActivity({
    type: '支委会',
    scenarioId: 'branch-committee',
    organizingScope: 'branch',
    hostGroupId: null,
    title: `线上支委会：审议专班「${name}」（${kindLabel}）`,
    date: today,
    status: 'published',
    visibility: 'branch',
    domain: 'party-building',
    // S-3（2026-09-10）默认描述精简：长文→一句（专班名/类型+报送人+时间+表态要求）
    description: `专班「${name}」${kindLabel}由${byName}${atText ? '（' + atText + '）' : ''}报送支委会表决，请支委表态（同意/异议/附言）。${note ? `说明：${note}。` : ''}`,
    voteConfig: { ...defaultVoteConfig('branch-committee'), voterIds },
    agenda: [{ id: generateId('ag-tf', '-'), item: `审议专班「${name}」（${kindLabel}）`, host: '支书' }],
    extras: { taskforceProposal: { taskforceId: tf.id, kind: reqKind } },
    organizer: me.personId,
    assignments: [{ personId: me.personId, role: 'organizer' },
      ...voterIds.filter(pid => pid !== me.personId).map(pid => ({ personId: pid, role: 'participant' }))],
  });

  // 给各支委角色发通知（+派生待办提示）：「有新的线上支委会表决（专班议案）待表态」。
  // R-22（2026-09-13）：系统派生通知改由服务端生成（kind 注册表复算授权 + 文案 + 落点）；
  // 支委点通知（targetType/targetId）直达活动详情页在线表态。失败不阻断排入结果。
  try {
    // R2-18（2026-10-20）：通知支部取**活动/专班/操作人**的真实归属，不再写死 br-b1——
    //   否则非 br-b1 支部的专报表决通知会落到错误支部，目标支委收不到。三处都缺失则不发送并留痕。
    const notifyBranchId = activity.branchId || tf.branchId || me.branchId || null;
    if (!notifyBranchId) {
      console.warn('[TaskForceRecordStore] 支委通知缺少支部归属（活动/专班/操作人均为空），已跳过');
    } else {
      NoticeStore.addSystem('taskforce-vote-requested', activity.id, {
        activityTitle: activity.title,
        date: today,
        branchId: notifyBranchId,
        actionRoles: [...BRANCH_COMMISSION_ROLES],
      });
    }
  } catch (e) {
    console.warn('[TaskForceRecordStore] 支委通知失败（不影响排入表决）：', e);
  }
  return activity;
}

/**
 * 反查某专班「当前待表决报送」已排入的线上支委会活动（3.2-4 查看表决结果用）
 * 只认该报送发起（committeeRequest.at）之后创建的表决活动，多场取最新；
 * 无（尚未排入 / 报送已失效）返回 null。
 */
export function findTaskforceVoteActivity(taskforceId) {
  if (!taskforceId) return null;
  const tf = TaskForceRecordStore.getAll().find(r => r.id === taskforceId);
  if (!tf) return null;
  const reqAt = (tf.committeeRequest && tf.committeeRequest.status === 'pending') ? tf.committeeRequest.at : null;
  return loadActivities()
    .filter(a => a.extras && a.extras.taskforceProposal && a.extras.taskforceProposal.taskforceId === taskforceId)
    .filter(a => !reqAt || String(a.createdAt || '') >= String(reqAt))
    .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')))[0] || null;
}

/**
 * 专班「组织者」判据（2026-09-23 支书 nudge 裁定 · 单一源）——「这个专班的承担人（组织者）是不是他」。
 * 赋权形态与活动同法（`services/activity/activity.js::isActivityOrganizer`，两者各一份、勿混用）：
 * 专班组织者＝`members` 中被赋 `role === 'organizer'` 的人（写口单一源＝专班详情「成员角色」的
 * `AuthStore.syncProjectRoles`，读侧预填同判据）。供「专班上传 / 代录」位的「越俎代庖」nudge 判本位。
 * @param {string} personId
 * @param {string} taskforceId
 * @returns {boolean}
 */
export function isTaskforceOrganizer(personId, taskforceId) {
  if (!personId || !taskforceId) return false;
  const tf = TaskForceRecordStore.getAll().find(r => r.id === taskforceId);
  if (!tf || !Array.isArray(tf.members)) return false;
  return tf.members.some(m => m && m.personId === personId && m.role === 'organizer');
}

