// role: [工程师]+[AI]
// ════════════════════════════════════════════════════════════════
//  attendance.js — 考勤记录 CRUD 服务
// ════════════════════════════════════════════════════════════════

import { mockDB, AttendanceStatus, ATTENDANCE_STATUS_LABELS } from '../../core/domain/domain.js?v=20261028b';
import { POLICY_DEFAULTS, isAttendanceOverdue } from '../../core/domain/policy-defaults.js?v=20261028b';
import { persist, getDataSource, getAdapter } from '../../data/data-adapter.js?v=20261028b';
import { generateId } from '../../core/base/id.js?v=20261028b';
import { bumpToken } from '../../core/base/version-token.js?v=20261028b'; // P0 域缓存失效（spec §二.3）
import { ATTENDANCE_RECORDS } from '../../data/mock/index.js?v=20261028b';
import { isInitStateActive } from '../core/init-reset.js?v=20261028b'; // C2 修复（2026-09-08）：init 态空态不回退演示种子
import { PersonStore, getPersonById, getPersonName } from '../member/person.js?v=20261028b';
import { getRosterStats } from '../member/roster.js?v=20261028b';
import { getMeetingRosterIds } from '../member/roster.js?v=20261028b';
import { loadActivities, isActivityOrganizer } from './activity.js?v=20261028b';
import { SignupStore } from './signup.js?v=20261028b';
import { deriveExpectedRosterIds } from './attendance-roster.js?v=20261028b';
import { trackWrite } from '../../core/session/pending-writes.js?v=20261028b';
import { isPartyGroupLeaderRole } from '../../core/domain/constants.js?v=20261028b';

export function loadAttendanceRecords() {
  if (mockDB.attendances.length > 0) return [...mockDB.attendances];
  // Task 3（2026-10-26）：api 形态禁止 mock 回退——空库显示空态，不返回演示种子。
  if (getDataSource() === 'api') return [];
  // C2 修复（2026-09-08）：init 态下 mockDB 空 = 合法空支部态，不回退演示种子（同 loadActivities）。
  return isInitStateActive() ? [] : [...ATTENDANCE_RECORDS];
}

/**
 * 读取活跃活动的考勤记录（2026-08-08 归档闭环）
 * 已归档活动的考勤随活动退出工作区展示。
 * ⚠️ 写流程（确认考勤等读取→修改→整表写回）必须使用 loadAttendanceRecords 原始版，
 *    否则整表写回会丢失已归档活动的考勤记录。
 */
export function loadActiveAttendanceRecords() {
  const activeIds = new Set(loadActivities().filter(a => !a.archived).map(a => a.id));
  return loadAttendanceRecords().filter(r => activeIds.has(r.activityId));
}

/** 读取活动创建时冻结的应到名单；矩阵需要用它区分“应到未录”和“不适用”。 */
export function loadAttendanceRosterSnapshots() {
  return Array.isArray(mockDB.attendanceRosters) ? [...mockDB.attendanceRosters] : [];
}

export function saveAttendanceRecords(records) {
  mockDB.attendances = [...records];
  bumpToken('attendance'); // P0：考勤写口统一 bump（纪检确认/组织者上传/纪检录入等均经本函数落库）
  persist();
}

/** 出勤/已补的「源头审校」确认人标记（R10-D08）：出勤与已补不改写 `confirmedBy`，由本标记表达自动确认。 */
export const AUTO_ATTENDANCE_CONFIRMER = 'auto';
/** 自动确认的展示文案（页面与导出共用，勿各写一份） */
export const AUTO_ATTENDANCE_CONFIRMER_LABEL = '自动确认';

/**
 * 考勤确认人（单一源，R10-D08）：**只有 `confirmedBy` 才算确认**；`recordedBy` 仅是上传人留痕，不参与判定。
 * 出勤 / 已补 = 源头审校自动确认，返回 `AUTO_ATTENDANCE_CONFIRMER`；其余未确认返回 null。
 */
export function attendanceConfirmerId(record) {
  if (!record) return null;
  if (record.confirmedBy) return record.confirmedBy;
  if (record.status === AttendanceStatus.PRESENT || record.status === AttendanceStatus.MADE_UP) return AUTO_ATTENDANCE_CONFIRMER;
  return null;
}

/** 考勤是否已确认（显式 confirmedBy 或 出勤/已补的自动确认，同一判据） */
export function isAttendanceConfirmed(record) {
  return !!attendanceConfirmerId(record);
}

/** 是否「出勤/已补」的源头审校自动确认（页面文案与统计共用同一判据） */
export function isAutoConfirmedAttendance(record) {
  return attendanceConfirmerId(record) === AUTO_ATTENDANCE_CONFIRMER;
}

/**
 * 考勤「待确认」判据（D06 单一源）：待纪检确认＝**尚未落确认人**、非出勤/已补、且不在打回回退态。
 * 会议考勤（党课/党员大会）走 `upsertMeetingAttendance` 时 `recordedBy` 即录入人本人 ⇒
 * 「录入即确认」，**不会**进入本判据/待确认队列；组织者经 `appendAttendanceRecords` 上传的记录
 * `recordedBy: null` ⇒ 才进队列等纪检确认。页面与单测同读本函数，勿各写一份条件。
 */
export function isAttendancePendingConfirm(record) {
  if (!record) return false;
  if (isAttendanceConfirmed(record)) return false;   // 已有确认人（含会议考勤录入即确认）
  if (record.returnedBy) return false;               // 打回回退态交上传方，不在纪检待确认
  return record.status !== AttendanceStatus.PRESENT && record.status !== AttendanceStatus.MADE_UP;
}

/**
 * 纪检 / 支书 / 副支书确认考勤：只写确认字段，**不改 recordedBy**（上传人留痕不可改写）。
 * 说明：服务端快照门只放行「确认字段变更 + 确认权」，上传位（canUploadAttendance）不参与确认判定。
 * @param {string[]} recordIds
 * @param {{confirmerId?:string, at?:string}} [opts]
 * @returns {number} 实际确认条数
 */
export function confirmAttendanceRecords(recordIds, { confirmerId, at = new Date().toISOString() } = {}) {
  if (!confirmerId || !Array.isArray(recordIds) || recordIds.length === 0) return 0;
  const ids = new Set(recordIds);
  const records = loadAttendanceRecords();
  let n = 0;
  for (const rec of records) {
    if (!ids.has(rec.id) || isAttendanceConfirmed(rec)) continue;
    rec.confirmed = true;
    rec.confirmedBy = confirmerId;
    rec.confirmedAt = at;
    n += 1;
  }
  if (n > 0) saveAttendanceRecords(records);
  return n;
}

/** 列出待确认考勤（缺省＝活跃记录；D06 待确认队列数据源） */
export function listPendingAttendanceConfirm(records) {
  const src = records || loadActiveAttendanceRecords();
  return src.filter(isAttendancePendingConfirm);
}

/** 冻结一场活动创建时适用的「原应到名单」；实际到场名单在汇总时与其去重并集。 */
export async function freezeExpectedRosterForActivity(activityId) {
  const activity = loadActivities().find((row) => row.id === activityId);
  if (!activity) throw Object.assign(new Error('活动不存在，无法冻结应到名单'), { type: 'NotFoundError' });
  const groupId = activity.type === '党小组会'
    ? (activity.hostGroup || getPersonById(activity.organizer)?.partyGroup || '')
    : undefined;
  if (activity.type === '党小组会' && !groupId) {
    throw Object.assign(new Error('党小组会缺少承办党小组，无法冻结应到名单'), { type: 'ValidationError' });
  }
  const originalPersonIds = getMeetingRosterIds({ type: activity.type, groupId, branchId: activity.branchId || undefined });
  const personIds = deriveExpectedRosterIds({ activity, originalPersonIds, signups: SignupStore.getAll() });
  const frozen = await getAdapter().attendanceRosters.freeze(activityId, personIds);
  const rows = Array.isArray(mockDB.attendanceRosters) ? mockDB.attendanceRosters : [];
  mockDB.attendanceRosters = [...rows.filter((row) => row.activityId !== activityId), frozen];
  return frozen;
}

// ── A1 写入门禁（2026-09-05 落代码，操作位语义见 SYSTEM_ROLE_PERMISSION §9b/§9f + CF §C.1a）──

/**
 * 会议考勤的类型清单（CF §C.1a「会议考勤」；应到名单口径 / 表单列活动用）。
 * 上传位**按会议类型分**（2026-09-21 批次 132 · 支书当日口径一，**修正批次 124 · `D-548` 的
 *   「一刀切＝会议考勤上传一律归组织者」**）：**党课 / 支部党员大会＝纪检委员**（支书 / 副支书照例
 *   可代上传）· **党小组会＝该场会议的组织者**（兼本组组长）· **组织生活会 / 主题党日 / 其余＝该场
 *   组织者** · **支委会＝不考勤**（`noAttendanceTypes`，故不在本清单内）。判据一律走
 *   `canUploadAttendance`（本文件），勿在消费点另判。
 * P3c 单一源 = core/domain/policy-defaults.js（派生导出，导出去重冻结导出面）：
 * 默认=本科生党支部口径（党课/支部党员大会/组织生活会）；
 * 支委会归 noAttendanceTypes；党小组会/主题党日归组长·组织者位，不入此列。见 .ctx/ENGINEERING_ASSESSMENT.md 行动线 P3b。
 */
export const MEETING_ATTENDANCE_TYPES = [...POLICY_DEFAULTS.attendance.meetingTypes];

/** 考勤记录是否已闭环锁定（不可由上传侧覆盖）：出勤/已补 = 源头审校已确认；确认人非空 = 纪检已复核 */
function isAttendanceLocked(r) {
  if (!r) return true;
  return isAttendanceConfirmed(r);
}

/**
 * 活动归属党小组（dogfood 权限专项 2026-09-13）
 * 判据：优先活动 hostGroup（组长写入时固化）；缺省回退组织者所属小组（种子活动无 hostGroup）。
 * 与之同判据的实现见 inspection.js::_activityPartyGroup（勿各自改口径）。
 */
function _activityPartyGroup(activity) {
  if (!activity) return null;
  if (activity.hostGroup) return activity.hostGroup;
  const orgId = activity.organizer
    || (Array.isArray(activity.assignments) ? (activity.assignments.find(x => x.role === 'organizer') || {}).personId : null);
  return orgId ? ((getPersonById(orgId) || {}).partyGroup || null) : null;
}

/**
 * 考勤上传位门禁：谁可对某活动做「上传（追加提交）」
 * **按会议类型分**（2026-09-21 批次 132 · 支书当日口径一，**修正批次 124 · `D-548` 的「一刀切」**）：
 * - **支委会＝不考勤**（`POLICY_DEFAULTS.attendance.noAttendanceTypes`，规模小）⇒ **任何人无上传位**；
 * - **党课 / 支部党员大会＝纪检委员**（判据由 `recorderByType` 的表内角色键给出）；
 * - **党小组会＝该场会议的组织者**（兼本组组长：本组上传位，跨组只读）；
 * - **组织生活会 / 主题党日 / 其余活动＝该场活动组织者**（判据单一源 = services/activity/activity.js::isActivityOrganizer）
 *   ——**「会议和活动不一样」**：活动类与组织者位不受本批改动影响。
 * - 支书/副支书：例外承担（§9b 注，制度固定）
 */
export function canUploadAttendance(personId, activityId) {
  if (!personId || !activityId) return false;
  const activity = loadActivities().find(a => a.id === activityId);
  if (!activity || activity.archived) return false;
  // 支委会（不考勤的会议类型）：规模小、不设考勤 ⇒ 一律无上传位（含组织者与纪检）
  if (POLICY_DEFAULTS.attendance.noAttendanceTypes.includes(activity.type)) return false;
  const role = (getPersonById(personId) || {}).role;
  // 支书/副支书例外承担（§9b 注）：角色数组单源 = policy-defaults attendance.uploaderExceptions.secretaryDeputy
  if (POLICY_DEFAULTS.attendance.uploaderExceptions.secretaryDeputy.includes(role)) return true;
  if (activity.type === '党小组会') {
    // 本组上传位（组长手册 §2.1「上传本组考勤」）：本组组长可传；跨组只能督促（只读）。
    // dogfood 权限专项 2026-09-13：此前仅判类型 → 任一组长可代录他组小组会考勤（实测下拉出现
    //   别组小组会且可提交成功），与制度「本组」口径不符。
    const myGroup = (getPersonById(personId) || {}).partyGroup;
    if (isPartyGroupLeaderRole(role) && !!myGroup && _activityPartyGroup(activity) === myGroup) return true;
    // 该场会议的组织者（2026-09-21 批次 132 · 支书口径一「党小组会 那就是 会议组织者」）
    return isActivityOrganizer(personId, activityId);
  }
  // 「非组织者位」的会议类型（本批＝党课 / 支部党员大会）＝**纪检委员**：判据单一源 = policy
  //   recorderByType 的表内角色键（同一份表既管上传位门禁、又是设置中心的「记录人」默认值 ⇒ 界面与
  //   默认值一致；批次 124 曾登记「表与门禁不一致」的缺口，本批按支书口径收口）。
  const recorderRoles = ATTENDANCE_RECORDER_BY_TYPE[activity.type] || [];
  if (recorderRoles.length > 0) return recorderRoles.includes(role);
  // 组织者位活动（组织生活会 / 主题党日 / 其余）——判据单一源 = services/activity/activity.js::isActivityOrganizer
  // （2026-09-19 批次 91 · SOP-B-17：组织者是「这场事上被指定的人」，不是静态角色）
  return isActivityOrganizer(personId, activityId);
}

/**
 * 会议考勤录入（**录入即确认**，recordedBy=录入人本人；CF §C.1a 会议考勤）
 * D06 明确口径（2026-10-20，取方案 b）：本入口的录入人同时就是确认人——不另设「另一名支委确认」，
 * 也不把自己刚录的记录再扔回「待确认队列」（判据见 `isAttendancePendingConfirm`）。
 * 因此本函数落 `recordedBy: actorId` 是**语义本身**（不是自确认漏洞）：待确认队列只服务
 * 组织者上传的异常记录（`appendAttendanceRecords` 落 `recordedBy: null`）。
 * 上传主体（2026-09-21 批次 132 · 支书口径一，**修正批次 124 · `D-548` 的「一刀切」**）＝**按会议类型分**：
 *   **党课 / 支部党员大会＝纪检委员**（支书 / 副支书照例可代上传）· **党小组会＝该场会议的组织者**·
 *   组织生活会 / 主题党日 / 其余＝该场组织者 · **支委会不考勤**——门禁一律走 `canUploadAttendance`。
 *   纪检的位置另在「待确认队列 · 打包确认」与考勤明细 / 统计核对（不变）。
 * - 默认（不传 opts.overwrite）：同人同活动已有记录（含待复核异常）→ 跳过（不可覆盖已有记录，改走纪检确认界面）
 * - 上传者更正（opts.overwrite=true，支书已批方案A 2026-09-06）：
 *   批量上传时，若该 (activityId,personId) 已有记录且为本人权威所录（recordedBy===actorId，即本人
 *   此前经本入口录入/确认），按本次状态覆盖更正，并写 updatedBy/updatedAt；
 *   他人权威所录记录仍跳过（不可覆盖非本人录入，改走纪检确认界面）。
 * @param {Object} params
 * @param {string} params.actorId 操作人（该场会议组织者本人）
 * @param {Array}  params.records 待录入记录（含 personId/activityId/status）
 * @param {Object} [opts={}]     可选参数
 * @param {boolean} [opts.overwrite=false] true=更正模式：允许覆盖本人已录记录
 * @returns {{ added: number, updated: number, skipped: number }}
 */
export function upsertMeetingAttendance({ actorId, records = [] }, opts = {}) {
  const res = { added: 0, updated: 0, skipped: 0 };
  if (!actorId || !Array.isArray(records) || records.length === 0) return res;
  const overwrite = !!opts.overwrite;
  const all = loadAttendanceRecords();
  records.forEach(r => {
    if (!r.personId || !r.activityId) return;
    if (!canUploadAttendance(actorId, r.activityId)) { res.skipped += 1; return; }
    const exist = all.find(x => x.personId === r.personId && x.activityId === r.activityId);
    if (exist) {
      // 纪检更正（方案A）：仅同一权威（recordedBy===纪检本人）的已录记录可覆盖更正；他人权威仍跳过
      if (overwrite && exist.recordedBy === actorId) {
        exist.status = r.status;
        // 附录⑩ A批·S1 · R1-2/R1-3：更正同步「标因 + 滞留补录标记」——
        //   未到（缺勤/请假）携固定枚举标因 absenceReason；更正为到场（出勤/已补）时清除旧标因；
        //   detainedMakeup 仅当本次携带时写入（普通行重提 → 清除滞留补录标记，防历史补录误延续）。
        if (r.status === AttendanceStatus.PRESENT || r.status === AttendanceStatus.MADE_UP) {
          delete exist.absenceReason;
          // 线上参会标记同族处置（D-293 / SOP-B-5）：状态更正为到场时清除——否则「线上参会只免补课」
          // 的标记会挂在一个「已出勤」的记录上，补课判据读到自相矛盾的两件事。
          delete exist.onlineAttend;
        } else if (r.absenceReason) {
          exist.absenceReason = r.absenceReason;
        }
        // 线上参会（申报来源：发布三会一课通知 → 确认收到时填写）经纪检更正入口一并落库
        if (r.status === AttendanceStatus.LEAVE && r.onlineAttend !== undefined) {
          exist.onlineAttend = !!r.onlineAttend;
        }
        if (r.detainedMakeup !== undefined) exist.detainedMakeup = !!r.detainedMakeup;
        else delete exist.detainedMakeup;
        exist.updatedBy = actorId;
        exist.updatedAt = new Date().toISOString();
        res.updated += 1;
      } else {
        res.skipped += 1;
      }
      return;
    }
    // R10-D08：`recordedBy` 只作上传人留痕；会议考勤的「录入即确认」改由 `confirmedBy` 表达
    //   （出勤/已补仍走统一判据的 auto，不重复写确认人）。
    const isRegularStatus = r.status === AttendanceStatus.PRESENT || r.status === AttendanceStatus.MADE_UP;
    all.push({
      ...r,
      submittedBy: actorId,
      recordedBy: actorId,
      overdue: false,
      ...(isRegularStatus ? {} : { confirmed: true, confirmedBy: actorId, confirmedAt: new Date().toISOString() }),
    });
    res.added += 1;
  });
  if (res.added > 0 || res.updated > 0) saveAttendanceRecords(all);
  return res;
}

/**
 * 考勤追加提交（组织者上传位语义）：
 * - 同人同活动已有记录且已闭环锁定（出勤/已补/纪检已复核）→ 跳过（重复上传，不覆盖已确认记录）
 * - 同人同活动已有待纪检复核的异常（缺勤/请假）→ 拦截（改/删走纪检确认流程，见 CF §C.1a）
 * - 其余 → 追加（submittedBy=上传者）
 * @returns {{ added: number, skipped: number, blocked: number, denied: boolean }}
 */
export function appendAttendanceRecords({ actorId, actorRole, records = [] }) {
  const res = { added: 0, skipped: 0, blocked: 0, denied: false };
  if (!actorId || !Array.isArray(records) || records.length === 0) return res;
  const all = loadAttendanceRecords();
  records.forEach(r => {
    if (!r.personId || !r.activityId) return;
    // 上传位门禁：每一条记录的活动都须在上传者权限内
    if (!canUploadAttendance(actorId, r.activityId)) {
      res.blocked += 1;
      return;
    }
    const exist = all.find(x => x.personId === r.personId && x.activityId === r.activityId);
    if (exist) {
      if (isAttendanceLocked(exist)) { res.skipped += 1; return; }
      // 待纪检复核的异常记录：组长改状态走纪检确认，不上传侧直改
      res.blocked += 1;
      return;
    }
    all.push({ ...r, submittedBy: actorId, recordedBy: null, overdue: false });
    res.added += 1;
  });
  if (res.added > 0) saveAttendanceRecords(all);
  return res;
}

/**
 * 线上参会申报落考勤（SOP-B-5 / `D-293`，2026-09-18 批次 83）
 * 场景：发布三会一课通知时关联本次活动 → 被通知人在通知详情「确认读取」时申报**能线上参会**。
 * 落库形状：该场考勤记 **status = 请假**（线上参会**不计入出席**）+ `onlineAttend = true`（**只免补课**）。
 * 说明：**不**代填出勤——实际到会与否由该场考勤记录与纪检确认决定；`recordedBy` 留空（待纪检确认）。
 * 幂等：同人同活动已有记录一律不覆盖（重复申报返回已申报；状态更正走纪检更正入口）。
 * @param {{ activityId: string, personId: string }} params
 * @returns {{ ok: boolean, reason?: string }}
 */
export function declareOnlineAttend({ activityId, personId } = {}) {
  if (!activityId || !personId) return { ok: false, reason: '缺少活动或申报人' };
  const all = loadAttendanceRecords();
  const exist = all.find(x => x.personId === personId && x.activityId === activityId);
  if (exist) {
    if (exist.status === AttendanceStatus.LEAVE && exist.onlineAttend === true) return { ok: true, reason: 'already' };
    return { ok: false, reason: '该活动已有您的考勤记录，如需更正请联系纪检委员' };
  }
  all.push({
    id: generateId('att'),
    personId,
    activityId,
    status: AttendanceStatus.LEAVE,
    onlineAttend: true,
    // SOP-B-16⑤（2026-09-19 批次 94）：线上参会**不由人认档**（不是事假、也不是病假）⇒ 沿用通用键
    // `leave`（显示「请假」，见 ABSENCE_REASON_LEGACY_LABELS）；档别由纪检复核时认定。
    absenceReason: 'leave',
    submittedBy: personId,
    recordedBy: null,
    overdue: false,
  });
  saveAttendanceRecords(all);
  return { ok: true };
}

// ════════════════════════════════════════════════════════════════
//  出勤申诉与「打回」回退态（SOP-B-42 / `D-456`，2026-09-18 批次 85）
// ════════════════════════════════════════════════════════════════
// 制度原文（纪检委员工作流程指南 §1.1）：「确认后数据锁定……如需更正，由纪检委员打回，
//   交活动组织方重新确认，修改痕迹留存。同学反映『出勤了但没记上』时，纪检委员先调查核实，
//   确属漏记的按打回处理。」`D-456`：**打回是「打包确认」里的例外处理路径**。
// 落成：
//   · 申诉队列 = `mockDB.attendanceAppeals`（内存读链）＋ 双形态持久（2026-09-24 批次 169 收口）：
//       - mock 形态：自管 localStorage 键 `gsm1921-attendance-appeals`（`gsm1921-` 前缀 →
//         `?reset=demo` 自动清理；做法同 services/member/member-confirmation.js 的自管键；原路径不变）；
//       - api 形态：服务端表 `attendance_appeals`（端点 `GET/POST/PATCH /api/v1/attendance-appeals`，
//         见 server/routes/resources.js 末「申诉队列」段），`init()` 拉取填 `mockDB.attendanceAppeals`
//         ⇒ **清本机缓存不丢队列**；写在 api 形态同发端点（fire-and-forget，本地已记、下次 init 以服务端为准）。
//   · 「打回」的**回退态**落在考勤记录本体上（`returnedBy / returnedAt / returnReason`）：
//     记录回到「待确认」，且打回留痕**可见**（不再只藏 updatedBy/updatedAt）。
export const ATTENDANCE_APPEALS_KEY = 'gsm1921-attendance-appeals';

/** 是否 api 形态（申诉队列以服务端表为权威） */
function _isApiForm() {
  try { return getDataSource() === 'api'; } catch (_) { return false; }
}

/** api 形态：把一次申诉写同步到服务端（R3-P1（F-09）：登记 pending-writes，失败让调用方感知） */
function _syncAppealToServer(fn, what) {
  if (!_isApiForm()) return;
  try {
    const call = fn(getAdapter());
    if (call && typeof call.then === 'function') {
      trackWrite(call).catch((e) => console.warn(`[AttendanceAppeal] api 形态${what}落服务端失败（本地已记，下次 init 以服务端为准）：`, e));
    }
  } catch (e) {
    console.warn(`[AttendanceAppeal] api 形态${what}落服务端失败（本地已记，下次 init 以服务端为准）：`, e);
    trackWrite(Promise.reject(e));
  }
}

/** 读取出勤申诉队列（api 形态读 init 拉取的服务端缓存；mock 形态读本地键；不可用 / 损坏 → []） */
export function loadAttendanceAppeals() {
  if (Array.isArray(mockDB.attendanceAppeals)) return [...mockDB.attendanceAppeals];
  try {
    if (typeof localStorage === 'undefined') return [];
    const arr = JSON.parse(localStorage.getItem(ATTENDANCE_APPEALS_KEY) || '[]');
    return Array.isArray(arr) ? arr : [];
  } catch (_) { return []; }
}

function _saveAttendanceAppeals(list) {
  mockDB.attendanceAppeals = [...list]; // 内存读链（两形态同源）
  if (_isApiForm()) return;             // api 形态：不落本机（服务端表为权威）
  try {
    if (typeof localStorage !== 'undefined') localStorage.setItem(ATTENDANCE_APPEALS_KEY, JSON.stringify(list));
  } catch (_) { /* 存储不可用：不阻塞流程 */ }
}

/**
 * 提交出勤申诉（成员侧「我参加了但没记上」）。
 * 同人同活动已有未处理（pending）申诉 → 不重复登记。
 * @param {{personId:string, activityId:string, note?:string}} params
 * @returns {{ok:boolean, reason?:string}}
 */
export function createAttendanceAppeal({ personId, activityId, note } = {}) {
  if (!personId || !activityId) return { ok: false, reason: '缺少活动或申诉人' };
  const all = loadAttendanceAppeals();
  if (all.some(a => a.personId === personId && a.activityId === activityId && a.status === 'pending')) {
    return { ok: false, reason: 'already' };
  }
  all.push({
    id: generateId('appeal'),
    personId,
    activityId,
    note: String(note || '').trim(),
    status: 'pending',
    createdAt: new Date().toISOString(),
  });
  _saveAttendanceAppeals(all);
  // api 形态：同发服务端入队端点（本地已乐观入队；服务端在下一次 init 成为权威）
  _syncAppealToServer(a => (a.attendanceAppeals ? a.attendanceAppeals.create(all[all.length - 1]) : null), '申诉提交');
  return { ok: true };
}

/**
 * 关闭申诉（纪检核实后：不属实 / 已另行处理）——留痕可见。
 * @param {string} appealId
 * @param {{by?:string, note?:string, status?:string}} [opts]
 */
export function closeAttendanceAppeal(appealId, { by, note, status = 'closed' } = {}) {
  const all = loadAttendanceAppeals();
  const it = all.find(a => a.id === appealId);
  if (!it) return { ok: false };
  it.status = status;
  it.decidedBy = by || null;
  it.decidedAt = new Date().toISOString();
  if (note) it.decisionNote = String(note);
  _saveAttendanceAppeals(all);
  _syncAppealToServer(a => (a.attendanceAppeals ? a.attendanceAppeals.patch(appealId, { status, note: note || '' }) : null), '申诉关闭');
  return { ok: true };
}

/**
 * 纪检核实属实 → 打回，交活动组织方确认（`D-456`）。
 * ① 申诉置 `returned`（留痕：谁在何时打回、打回说明）；
 * ② 若该人该场**已有考勤记录**，记录一并置回退态（清确认人 + 写 returnedBy/returnedAt/returnReason）
 *    ——回到「待确认」，由组织者重新确认或更正，修改痕迹留存。
 * @returns {{ok:boolean, hadRecord:boolean}}
 */
export function returnAttendanceAppeal(appealId, { by, note } = {}) {
  const all = loadAttendanceAppeals();
  const it = all.find(a => a.id === appealId);
  if (!it || it.status !== 'pending') return { ok: false, hadRecord: false };
  const at = new Date().toISOString();
  it.status = 'returned';
  it.returnedBy = by || null;
  it.returnedAt = at;
  it.returnNote = String(note || '').trim();
  _saveAttendanceAppeals(all);
  _syncAppealToServer(a => (a.attendanceAppeals ? a.attendanceAppeals.patch(appealId, { status: 'returned', note: it.returnNote }) : null), '申诉打回');
  const records = loadAttendanceRecords();
  const rec = records.find(r => r.personId === it.personId && r.activityId === it.activityId);
  if (rec) {
    rec.returnedBy = by || null;
    rec.returnedAt = at;
    rec.returnReason = it.returnNote || '出勤申诉核实';
    delete rec.recordedBy;
    delete rec.recordedAt;
    delete rec.confirmed;
    delete rec.confirmedBy;
    delete rec.confirmedAt;
    saveAttendanceRecords(records);
  }
  return { ok: true, hadRecord: !!rec };
}

/**
 * 对单个考勤记录打回（纪检「打包确认」的例外路径）：清确认人 + 写打回留痕 → 回到「待确认」。
 * @returns {{ok:boolean}}
 */
export function returnAttendanceRecord(recordId, { by, note } = {}) {
  const records = loadAttendanceRecords();
  const rec = records.find(r => r.id === recordId);
  if (!rec) return { ok: false };
  rec.returnedBy = by || null;
  rec.returnedAt = new Date().toISOString();
  rec.returnReason = String(note || '').trim() || '纪检打回';
  delete rec.recordedBy;
  delete rec.recordedAt;
  delete rec.confirmed;
  delete rec.confirmedBy;
  delete rec.confirmedAt;
  saveAttendanceRecords(records);
  return { ok: true };
}

/** 组织者确认的公共写口（改状态 + 清打回痕 + 回「待确认」；异常仍待纪检复核，出勤/已补由源头审校自动确认） */
function _applyOrganizerReconfirmation(rec, records, { actorId, status, absenceReason } = {}) {
  if (status) rec.status = status;
  if (rec.status === AttendanceStatus.PRESENT || rec.status === AttendanceStatus.MADE_UP) {
    delete rec.absenceReason;
    delete rec.onlineAttend;
  } else if (absenceReason) {
    rec.absenceReason = absenceReason;
  }
  delete rec.returnedBy;
  delete rec.returnedAt;
  delete rec.returnReason;
  rec.submittedBy = actorId || rec.submittedBy;
  delete rec.recordedBy;
  delete rec.recordedAt;
  delete rec.confirmed;
  delete rec.confirmedBy;
  delete rec.confirmedAt;
  saveAttendanceRecords(records);
  return { ok: true };
}

/**
 * 组织者重新确认（打回后可恢复的另一半）：把回退态记录改成组织者认定的状态、清打回痕、回「待确认」。
 * @param {string} recordId
 * @param {{actorId:string, status?:string, absenceReason?:string}} opts
 */
export function reconfirmReturnedRecord(recordId, { actorId, status, absenceReason } = {}) {
  const records = loadAttendanceRecords();
  const rec = records.find(r => r.id === recordId);
  if (!rec) return { ok: false };
  return _applyOrganizerReconfirmation(rec, records, { actorId, status, absenceReason });
}

/**
 * 组织者对「出勤申诉」的确认（打回后闭环）：按核实结论写入/更正该场该人的考勤（组织者口径），并关闭申诉。
 * @param {{appealId:string, actorId:string, status?:string, absenceReason?:string, note?:string}} params
 */
export function resolveAttendanceAppeal({ appealId, actorId, status, absenceReason, note } = {}) {
  const all = loadAttendanceAppeals();
  const it = all.find(a => a.id === appealId);
  if (!it) return { ok: false };
  const records = loadAttendanceRecords();
  const rec = records.find(r => r.personId === it.personId && r.activityId === it.activityId);
  if (rec) {
    _applyOrganizerReconfirmation(rec, records, { actorId, status, absenceReason });
  } else {
    const next = {
      id: generateId('att'),
      personId: it.personId,
      activityId: it.activityId,
      status: status || AttendanceStatus.PRESENT,
      submittedBy: actorId,
      recordedBy: null,
      overdue: false,
    };
    if (next.status !== AttendanceStatus.PRESENT && next.status !== AttendanceStatus.MADE_UP) {
      next.absenceReason = absenceReason || 'other';
    }
    records.push(next);
    saveAttendanceRecords(records);
  }
  it.status = 'closed';
  it.decidedBy = actorId || null;
  it.decidedAt = new Date().toISOString();
  if (note) it.decisionNote = String(note);
  _saveAttendanceAppeals(all);
  _syncAppealToServer(a => (a.attendanceAppeals ? a.attendanceAppeals.patch(appealId, { status: 'closed', note: note || '' }) : null), '申诉确认关闭');
  return { ok: true };
}

// ── 展示格式化（2026-09-03 数据域接线批次二：自 data/mock/attendance.js 原样提升）──
const _personName = (id) => getPersonName(id);
// R-16（2026-09-13）：改从 loadActivities()（mockDB 优先）取——API 模式下新建活动不在静态种子
// ACTIVITIES 中，此前台账只显示 act-xxxx 原始 id（人会看不懂是哪场活动）
const _activityTitle = (id) => loadActivities().find(a => a.id === id)?.title || id;
const _activityType = (id) => loadActivities().find(a => a.id === id)?.type || '未知';
const _activityDate = (id) => loadActivities().find(a => a.id === id)?.date || '';

/** 考勤记录展示长格式（记录 → 姓名/学号/发展阶段/所属党小组/活动/类别/状态/确认人） */
export function attendanceToLong(records) {
  return records.map(r => {
    // SOP-B-20（D-331）：汇总表第一列是人——人员的三项属性（学号/发展阶段/所属党小组）
    // 与活动侧字段同表呈现；人员属性一律现取（禁用记录内快照）。
    const m = getPersonById(r.personId) || {};
    return {
      id: r.id,
      name: _personName(r.personId),
      // Q-21-7（2026-09-13）：透出 personId 供「考勤明细」姓名列接成员档案页入口（与 activityId 同型——
      // 服务层唯一出口，勿在页面各自反查记录）
      personId: r.personId,
      studentId: m.studentId || '',
      developStage: m.developStage || '',
      partyGroup: m.partyGroup || '',
      // R-16：透出来源活动标识，供台账行补「查看该活动」链接（服务层唯一出口，勿在页面各自反查）
      activityId: r.activityId || null,
      activity: _activityTitle(r.activityId),
      type: _activityType(r.activityId),
      status: ATTENDANCE_STATUS_LABELS[r.status] || r.status,
      statusKey: r.status,
      // 线上参会（D-293 / SOP-B-5）：线上参会不计入出席（记「请假」）、只免补课——
      // 单列字段供各展示点标注「· 线上参会」，勿把它并进 status 中文标签（状态筛选按 statusKey 判）。
      onlineAttend: r.onlineAttend === true,
      confirmer: isAutoConfirmedAttendance(r) ? AUTO_ATTENDANCE_CONFIRMER_LABEL : (attendanceConfirmerId(r) ? _personName(attendanceConfirmerId(r)) : '—'),
      // R7-33：超期按「活动日 + 补课时限」现算（存储字段 overdue 仅作历史兼容，不再直读）
      overdue: isAttendanceOverdue({ ...r, date: r.date || _activityDate(r.activityId) }),
    };
  });
}

/**
 * 活动参与汇总（SOP-B-30 / `D-396`）：**以人为第一列**、按**各类活动**汇总参与情况（写工作总结时可直接引用）。
 * 口径：**参与＝出勤 / 已补**（线上参会只免补课、不计出席，故不计入）；一条记录计一次；请假 / 缺勤不计。
 * 列＝数据里出现过的活动类别（活动 type，按中文序）；行＝有过考勤记录的人（无记录者不占位）。
 * 纯数据辅助（无 DOM）：组织委员台「发展数据」tab 的「活动参与汇总」卡消费；单测可直导。
 * @param {Array} [records] 考勤记录（缺省 = 活跃记录）
 * @returns {{ types: string[], rows: Array<Object> }}
 */
export function listActivityParticipationByPerson(records) {
  const src = records || loadActiveAttendanceRecords();
  const actById = new Map(loadActivities().map(a => [a.id, a]));
  const byPerson = new Map();
  const typeSet = new Set();
  for (const r of src) {
    const act = actById.get(r.activityId);
    if (!act) continue; // 活动已下架（无类别可归）不计入，避免造「未知」列
    const type = act.type || '';
    if (!type) continue;
    typeSet.add(type);
    if (!byPerson.has(r.personId)) {
      const m = getPersonById(r.personId) || {};
      byPerson.set(r.personId, {
        personId: r.personId,
        name: _personName(r.personId),
        studentId: m.studentId || '',
        partyGroup: m.partyGroup || '',
        developStage: m.developStage || '',
        role: m.role || '',
        counts: {},
        total: 0,
      });
    }
    if (r.status === AttendanceStatus.PRESENT || r.status === AttendanceStatus.MADE_UP) {
      const row = byPerson.get(r.personId);
      row.counts[type] = (row.counts[type] || 0) + 1;
      row.total += 1;
    }
  }
  const zh = (a, b) => String(a).localeCompare(String(b), 'zh');
  return {
    types: [...typeSet].sort(zh),
    rows: [...byPerson.values()].sort((a, b) => b.total - a.total || zh(a.name, b.name)),
  };
}

/**
 * 出勤率汇总（SOP-B-35 / `D-412`，2026-09-18 批次 85）：**按场次（活动）**汇总本月出勤率——
 * 出勤含「已补」；线上参会不计出席（记请假）——口径与全站各处一致（单一源，勿在页面另算）。
 * 供纪检台「导出出勤率汇总（支委会内部）」与支书台「偏低提示」同一读口消费。
 * @param {{month?:string, records?:Array}} [params] month 形如 '2026-09'（缺省 = 全部活动）
 * @returns {{month:string, rows:Array<Object>, total:number, presentTotal:number, rate:number}}
 */
export function summarizeAttendanceByActivity({ month, records, rosterSnapshots } = {}) {
  const src = records || loadActiveAttendanceRecords();
  const snapshots = rosterSnapshots || mockDB.attendanceRosters || [];
  const signups = SignupStore.getAll();
  const rows = [];
  for (const a of loadActivities()) {
    if (month && !(a.date || '').startsWith(month)) continue;
    // 支委会等「不考勤」类型不进入出勤率分母（policy 单一源）
    if (POLICY_DEFAULTS.attendance.noAttendanceTypes.includes(a.type)) continue;
    const recordByPerson = new Map();
    for (const record of src) {
      if (record.activityId === a.id && record.personId) recordByPerson.set(record.personId, record);
    }
    const snapshot = snapshots.find((row) => row.activityId === a.id && row.frozen === true);
    let expectedIds;
    let rosterFrozen = !!snapshot;
    if (snapshot) {
      expectedIds = new Set(Array.isArray(snapshot.personIds) ? snapshot.personIds.map(String) : []);
    } else {
      // R2-46：未冻结名单的活动也不能把「实际到场」当分母（会恒等于 100%）。
      // 回退到支部在册应到名单（党小组会按本组），再叠加主题党日报名口径——与 freeze 时同源。
      const groupId = a.type === '党小组会'
        ? (a.hostGroup || getPersonById(a.organizer)?.partyGroup || '')
        : undefined;
      const original = getMeetingRosterIds({ type: a.type, groupId, branchId: a.branchId || undefined });
      expectedIds = new Set(deriveExpectedRosterIds({ activity: a, originalPersonIds: original, signups }).map(String));
    }
    const actualIds = new Set([...recordByPerson.values()]
      .filter((record) => record.status === AttendanceStatus.PRESENT || record.status === AttendanceStatus.MADE_UP)
      .map((record) => String(record.personId)));
    const rosterIds = new Set([...expectedIds, ...actualIds]);
    if (rosterIds.size === 0) continue; // 尚无应到名单且没有记录的活动不占位
    const counted = [...rosterIds].map((personId) => recordByPerson.get(personId)).filter(Boolean);
    const present = counted.filter(r => r.status === AttendanceStatus.PRESENT || r.status === AttendanceStatus.MADE_UP).length;
    const leave = counted.filter(r => r.status === AttendanceStatus.LEAVE).length;
    const absent = counted.filter(r => r.status === AttendanceStatus.ABSENT).length;
    const unrecorded = rosterIds.size - counted.length;
    const coverage = Math.round((counted.length / rosterIds.size) * 100);
    rows.push({
      activityId: a.id, activity: a.title, date: a.date || '', type: a.type || '',
      total: rosterIds.size, present, leave, absent, unrecorded, coverage,
      rosterFrozen, estimate: !rosterFrozen,
      rate: Math.round((present / rosterIds.size) * 100),
    });
  }
  rows.sort((x, y) => (y.date || '').localeCompare(x.date || ''));
  const total = rows.reduce((s, r) => s + r.total, 0);
  const presentTotal = rows.reduce((s, r) => s + r.present, 0);
  const recordedTotal = rows.reduce((s, r) => s + r.total - r.unrecorded, 0);
  return {
    month: month || '', rows, total, presentTotal, recordedTotal,
    coverage: total > 0 ? Math.round((recordedTotal / total) * 100) : 0,
    rate: total > 0 ? Math.round((presentTotal / total) * 100) : 0,
  };
}

/**
 * 我的出勤率（SOP-B-15 当事人可见侧，2026-09-20 批次 116 支书定案「支委会 ＋ 当事人本人」）：
 * **只算传入的这一人**——调用侧只传当前登录人（成员台「考勤概况」），故当事人看不到别人的出勤率。
 * 口径与全站一致（单一源，勿在页面另算）：出勤 ＝ 出勤 / 已补；分母 ＝ 该人当月有考勤记录的场次；
 * 线上参会记「请假」、不计出席（与 `summarizeAttendanceByActivity` 同口径）。
 * @param {{personId:string, month?:string}} [params] month 形如 '2026-09'（缺省 = 该人全部活跃记录）
 * @returns {{total:number, present:number, leave:number, absent:number, rate:number}}
 */
export function summarizePersonAttendance({ personId, month } = {}) {
  const empty = { total: 0, present: 0, leave: 0, absent: 0, rate: 0 };
  if (!personId) return empty;
  const actById = new Map(loadActivities().map(a => [a.id, a]));
  const mine = loadActiveAttendanceRecords().filter(r => {
    if (r.personId !== personId) return false;
    const act = actById.get(r.activityId);
    if (!act) return false;
    return !month || (act.date || '').startsWith(month);
  });
  if (mine.length === 0) return empty;
  const present = mine.filter(r => r.status === AttendanceStatus.PRESENT || r.status === AttendanceStatus.MADE_UP).length;
  const leave = mine.filter(r => r.status === AttendanceStatus.LEAVE).length;
  const absent = mine.filter(r => r.status === AttendanceStatus.ABSENT).length;
  return { total: mine.length, present, leave, absent, rate: Math.round((present / mine.length) * 100) };
}

/**
 * 出勤率配色分档（R2-14 / R2-47，2026-10-20）：全站唯一阈值源。
 * 为什么需要：首页 90/70、成员台 90/提示线、单场 90/70 三套色阶会让同一人同一月一绿一黄。
 * 口径：良好线固定 90（展示口径）；偏低线 = 制度参数 `attendance.lowRateHint`（默认 80，支部可调）。
 * 仅返回语义档位，具体颜色由各展示层映射（颜色不进服务层）。
 * @param {number|null} rate 0–100；null/undefined = 未录（待录入）
 * @returns {'good'|'watch'|'low'|'pending'}
 */
export function attendanceRateTone(rate) {
  if (rate === null || rate === undefined || !Number.isFinite(Number(rate))) return 'pending';
  if (Number(rate) >= 90) return 'good';
  if (Number(rate) >= POLICY_DEFAULTS.attendance.lowRateHint) return 'watch';
  return 'low';
}

/**
 * 按「应到人次」统计**某一个人**的出勤（R2-47，2026-10-20）。
 * 与 `summarizePersonAttendance` 的区别（两者都必须显式标注分母）：
 *   · 本函数：分母 = 该人**应到**的场次（冻结 roster / 在册应到名单，与场次级同一口径）；
 *     未录场次计入 `unrecorded`，`rate` 仍以应到为分母，`coverage` 暴露录入完整度；
 *   · `summarizePersonAttendance`：分母 = 该人**已录**场次（当事人视角的历史兼容口径）。
 * 页面禁止自行相除，二选一并标注用的是哪一个。
 * @param {{personId:string, month?:string}} [params]
 * @returns {{total:number, recorded:number, present:number, leave:number, absent:number,
 *   unrecorded:number, coverage:number, rate:number|null}}
 */
export function summarizePersonAttendanceByRoster({ personId, month } = {}) {
  const empty = { total: 0, recorded: 0, present: 0, leave: 0, absent: 0, unrecorded: 0, coverage: 0, rate: null };
  if (!personId) return empty;
  const src = loadActiveAttendanceRecords();
  const snapshots = mockDB.attendanceRosters || [];
  const signups = SignupStore.getAll();
  let total = 0, recorded = 0, present = 0, leave = 0, absent = 0;
  for (const a of loadActivities()) {
    if (month && !(a.date || '').startsWith(month)) continue;
    // 支委会等「不考勤」类型不进入分母（与场次级汇总同源）
    if (POLICY_DEFAULTS.attendance.noAttendanceTypes.includes(a.type)) continue;
    const snapshot = snapshots.find((row) => row.activityId === a.id && row.frozen === true);
    let expectedIds;
    if (snapshot) {
      expectedIds = new Set(Array.isArray(snapshot.personIds) ? snapshot.personIds.map(String) : []);
    } else {
      const groupId = a.type === '党小组会'
        ? (a.hostGroup || getPersonById(a.organizer)?.partyGroup || '')
        : undefined;
      const original = getMeetingRosterIds({ type: a.type, groupId, branchId: a.branchId || undefined });
      expectedIds = new Set(deriveExpectedRosterIds({ activity: a, originalPersonIds: original, signups }).map(String));
    }
    if (!expectedIds.has(String(personId))) continue;
    total += 1;
    const record = src.find((r) => r.activityId === a.id && r.personId === personId);
    if (!record) continue;
    recorded += 1;
    if (record.status === AttendanceStatus.PRESENT || record.status === AttendanceStatus.MADE_UP) present += 1;
    else if (record.status === AttendanceStatus.LEAVE) leave += 1;
    else if (record.status === AttendanceStatus.ABSENT) absent += 1;
  }
  const unrecorded = total - recorded;
  return {
    total, recorded, present, leave, absent, unrecorded,
    coverage: total > 0 ? Math.round((recorded / total) * 100) : 0,
    // 未录（coverage=0）不得显示 0%/100% ⇒ null，由展示层写「待录入」
    rate: total > 0 && recorded > 0 ? Math.round((present / total) * 100) : null,
  };
}

/**
 * 两个出勤率语义的**显式命名出口**（R2-47）：页面必须从二者选一并标注分母，禁止自己相除。
 * · `attendanceRateByRoster`：按场次 / 应到人次（服务层唯一实现 = summarizeAttendanceByActivity）；
 * · `attendanceRateByRecorded`：按人 / 已录场次（历史兼容口径 = summarizePersonAttendance）。
 */
export const attendanceRateByRoster = summarizeAttendanceByActivity;
export const attendanceRateByRecorded = summarizePersonAttendance;

/**
 * 出勤率偏低提示（SOP-B-15 / `SOP-B-7`，2026-09-18 批次 85）：**只作提示、不触发任何动作**
 * （不生成补课 / 不影响评优 / 不生成任何处置）。
 * 判据 = **提示线**（可调参数 `POLICY_DEFAULTS.attendance.lowRateHint`）——**提示线 ≠ 制度门槛**：
 *   母本不设达标线，本函数只用来「让相关成员知道出勤率偏低这件事」。
 * @param {{month?:string, hint?:number}} [params]
 * @returns {{hint:number, month:string, rows:Array<Object>}}
 */
export function listLowAttendanceSessions({ month, hint } = {}) {
  const line = Number.isFinite(hint) ? hint : POLICY_DEFAULTS.attendance.lowRateHint;
  const sum = summarizeAttendanceByActivity({ month });
  return { hint: line, month: sum.month, rows: sum.rows.filter(r => r.coverage > 0 && r.rate < line) };
}

// ════════════════════════════════════════════════════════════════
//  附录⑩ A批·S1 会务考勤规则域（支书裁定 2026-09-06）
//  派生出口均以 core/domain/policy-defaults.js attendance 为单一源，业务层勿新写字面量
// ════════════════════════════════════════════════════════════════

/** 会议考勤记录人（按活动类型）— 单源 = policy attendance.recorderByType（R1-1 正式化）；深拷贝防消费点改动穿透 */
export const ATTENDANCE_RECORDER_BY_TYPE = Object.fromEntries(
  Object.entries(POLICY_DEFAULTS.attendance.recorderByType).map(([type, roles]) => [type, [...roles]])
);

/** 取某活动类型的记录人角色键数组（拷贝；未入表的类型（如主题党日=组织者位）= 空表） */
export function recorderRolesOf(type) {
  return [...(ATTENDANCE_RECORDER_BY_TYPE[type] || [])];
}

/** 未到标因固定枚举 — 单源 = policy attendance.reasons（R1-2：纪检认定标因，禁造新枚举）
 *  （2026-09-19 批次 94 · SOP-B-16⑤：请假分事假 / 病假两档，各档带时效 note） */
export const ABSENCE_REASONS = POLICY_DEFAULTS.attendance.reasons.map(r => ({ ...r }));

/** 兼容别名（**不出现在可选枚举**，仅供显示）：旧键 `leave`（请假）——存量记录与「线上参会」代记
 *  （`declareOnlineAttend`）仍携该键；显示照旧「请假」，新录入不再可直接选它。 */
const ABSENCE_REASON_LEGACY_LABELS = { leave: '请假' };

/** 标因中文标签（未知键回退键原文；空 → 空串；`leave` 走兼容别名 → 「请假」） */
export function absenceReasonLabel(key) {
  if (!key) return '';
  const it = POLICY_DEFAULTS.attendance.reasons.find(r => r.key === key);
  if (it) return it.label;
  return ABSENCE_REASON_LEGACY_LABELS[key] || key;
}

/** 标因时效提示（SOP-B-16⑤）：事假「须提前 1 天申请」/ 病假「可事后补」——**界面提示，不是校验、不拦提交**。
 *  无 note 的档（无故 / 其它）与未知键返回空串。 */
export function absenceReasonNote(key) {
  if (!key) return '';
  const it = POLICY_DEFAULTS.attendance.reasons.find(r => r.key === key);
  return (it && it.note) || '';
}

/**
 * 纪检应到清点（含滞留到场补录，R1-3 支书 2026-09-06 裁定）：
 * K = 会前预应到 = 口径统计 expected（在册党员 − 滞留剔除）；
 * L = 该活动滞留到场补录人数（落行标记 detainedMakeup=true 的记录数）；
 * 实际应到 = K + L（补录者计「到席」，档案按在场展示）。
 * @param {Object} [params]
 * @param {string} [params.type]     会议类型（'党小组会' 需配 groupId）
 * @param {string} [params.groupId]  党小组名（党小组会必填）
 * @param {string} [params.activityId] 目标活动（缺省 = 不按活动统计 L）
 * @param {Array}  [params.records]  考勤记录（缺省 = 活跃记录，与界面同源）
 * @returns {{ expectedPre:number, makeupArrival:number, actualExpected:number }}
 */
export function countExpectedWithMakeup({ type, groupId, activityId, records } = {}) {
  const stats = getRosterStats({ type, groupId });
  const src = records || loadActiveAttendanceRecords();
  const makeupArrival = activityId
    ? src.filter(r => r.activityId === activityId && r.detainedMakeup).length
    : 0;
  return { expectedPre: stats.expected, makeupArrival, actualExpected: stats.expected + makeupArrival };
}

/**
 * 党小组会考勤只读视图数据（R1-1/裁定④：纪检纪律台只读掌握——组织者上传、不代传不审改）。
 * 按小组会活动聚合：组别 = 活动 organizer 所属党小组（缺省取成员多数党小组）；组长 = 该组
 * role 'leader' 成员（记录人语义）；上传人 = submittedBy（组织者上传即本人，可辨）。
 * 纯数据辅助：纪检 disc attendance-tab 下方只读浏览块消费；单测直导无 DOM。
 * @param {Array} [records] 考勤记录（缺省 = 活跃记录）
 * @returns {Array<Object>} 按活动降序的聚合视图
 */
export function listGroupMeetingAttendance(records) {
  const src = records || loadActiveAttendanceRecords();
  const acts = loadActivities().filter(a => a.type === '党小组会' && !a.archived);
  const people = PersonStore.getMembers();
  const byId = new Map(people.map(p => [p.id, p]));
  const view = [];
  for (const a of acts) {
    const rows = src.filter(r => r.activityId === a.id);
    if (rows.length === 0) continue; // 无考勤记录的小组会不占位
    const org = a.organizer ? byId.get(a.organizer) : null;
    const memberGroups = [...new Set(rows.map(r => byId.get(r.personId)?.partyGroup).filter(Boolean))];
    // 组别推导：活动组织者所属党小组优先；组织者缺失/串组时取成员多数党小组
    const groupName = org?.partyGroup
      || (memberGroups.length > 0
        ? memberGroups.reduce((acc, g) =>
            (rows.filter(r => byId.get(r.personId)?.partyGroup === g).length
              > rows.filter(r => byId.get(r.personId)?.partyGroup === acc).length ? g : acc), memberGroups[0])
        : '');
    const leader = groupName ? people.find(p => p.role === 'leader' && p.partyGroup === groupName) : null;
    const uploaderId = rows[0]?.submittedBy || null;
    view.push({
      activityId: a.id,
      title: a.title,
      date: a.date || '',
      groupName,
      leaderId: leader ? leader.id : null,
      leaderName: leader ? leader.name : '',
      uploaderId,
      uploaderName: uploaderId ? _personName(uploaderId) : '',
      total: rows.length,
      present: rows.filter(r => r.status === AttendanceStatus.PRESENT || r.status === AttendanceStatus.MADE_UP).length,
      rows: rows.map(r => ({
        personId: r.personId,
        name: _personName(r.personId),
        status: r.status,
        statusLabel: ATTENDANCE_STATUS_LABELS[r.status] || r.status,
        absenceReason: r.absenceReason || null,
        absenceReasonLabel: r.absenceReason ? absenceReasonLabel(r.absenceReason) : '',
        detainedMakeup: !!r.detainedMakeup,
      })),
    });
  }
  return view.sort((x, y) => (y.date || '').localeCompare(x.date || ''));
}

/**
 * 考勤「本位」判据（2026-09-23 支书 nudge 裁定 · 单一源）——「这一步**一般由谁**上传」。
 * 与 `canUploadAttendance`（**谁有权**）是两件事：权限面还含**例外承担**（支书 / 副支书有权代上传）、
 * 「本组组长」这一上传位；本函数只答**本位**，供「越俎代庖」nudge 判「操作人是不是本位」。
 * 口径（按支书 2026-09-21 批次 132 当日口径 · `D-558`，修正「会议考勤一律组织者」）：
 *   **支委会＝不考勤**（任何人无本位）· **党课 / 支部党员大会＝纪检委员**
 *   （表内角色键**剔除**「例外承担」的支书 / 副支书 ⇒ 本位唯一为纪检委员）·
 *   **党小组会 / 组织生活会 / 主题党日 / 其余活动＝该场活动的组织者**（判据同 `canUploadAttendance` 末段）。
 * @param {string} personId 操作人
 * @param {string} activityId 目标活动
 * @returns {boolean} 操作人是否处在本步的本位
 */
export function isAttendanceHomePosition(personId, activityId) {
  if (!personId || !activityId) return false;
  const activity = loadActivities().find(a => a.id === activityId);
  if (!activity) return false;
  // 支委会（不考勤的会议类型）：不设考勤 ⇒ 无本位（同 canUploadAttendance 首段判据）
  if (POLICY_DEFAULTS.attendance.noAttendanceTypes.includes(activity.type)) return false;
  // 党小组会＝该场会议的组织者（与 canUploadAttendance 的「本组上传位」分开：本组组长非组织者＝监督位）
  if (activity.type === '党小组会') return isActivityOrganizer(personId, activityId);
  // 「非组织者位」的会议类型（党课 / 支部党员大会）：本位＝表内角色键 − 例外承担
  const exceptions = POLICY_DEFAULTS.attendance.uploaderExceptions.secretaryDeputy;
  const homeRoles = (ATTENDANCE_RECORDER_BY_TYPE[activity.type] || []).filter(r => !exceptions.includes(r));
  if (homeRoles.length > 0) return homeRoles.includes((getPersonById(personId) || {}).role);
  // 组织者位活动（组织生活会 / 主题党日 / 其余）——判据单一源 = services/activity/activity.js::isActivityOrganizer
  return isActivityOrganizer(personId, activityId);
}

