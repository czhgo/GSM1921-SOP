// role: [工程师]+[AI]
// vote-config.js — 线上异步表决配置（voteConfig）解析与场景默认
// 泛化：支委会 deliberative / 支部党员大会 formal+硬校验；optionSet/voterScope/quorumCheck 参数化
// ── voterIds 与「应到名单」联动（支书 2026-09-06 ②批，出处见 data/mock/activities.js act-31 注释）──
//   新活动创建线上表决时固化的 voterIds = 按 voterScope 取现时「应到表决人」：
//     仅党员/支委范围 + 剔除滞留成员（运行期「在校/滞留」覆盖优先，缺省静态在校），
//   实现同型最小改：范围规则沿用本文件（formal-only/formal-plus-prep/committee），
//   滞留剔除复用 services/member/roster.js isDetained（口径单一源 = core/policy-defaults attendance.roster）。
//   历史快照语义：已创建活动（如 mock act-31）的 voteConfig.voterIds 为创建时固化的名单快照，
//   不随成员后续滞留状态变更回改——存量数据不动，仅新创建默认值走现时 roster。
import { PersonStore } from '../member/person.js?v=20261028b';
import { isDetained } from '../member/roster.js?v=20261028b';
// 支委名单单一源（数据生命周期 P1-09）：按 users.role 派生，禁止再维护旧 id 快照。
import { resolveCommitteeIds } from '../../core/domain/constants.js?v=20261028b';

export const OPTION_SETS = {
  deliberative: {
    label: '交流式表态', options: ['agree', 'object', 'comment'],
    labels: { agree: '同意', object: '异议', comment: '附言' },
    objectRequiresNote: true,
  },
  formal: {
    label: '正式表决', options: ['approve', 'oppose', 'abstain'],
    labels: { approve: '赞成', oppose: '反对', abstain: '弃权' },
    objectRequiresNote: false, // 附言选填
  },
};

// 计票方式（ballotMode）单一源转出：常量与强制/默认规则定义在 core/domain/constants.js
// （server 写侧校验与 mock 形态共用同一文件，勿另写规则副本）。
export { BALLOT_MODES, BALLOT_MODE_LABELS, isAnonymousForced, defaultBallotMode, ballotModeOfActivity, isAnonymousActivity } from '../../core/domain/constants.js?v=20261028b';

const DECISION_SCENARIOS = new Set(['branch-committee', 'branch-party-meeting']);

export function isDecisionScenario(scenarioId) { return DECISION_SCENARIOS.has(scenarioId); }

// 场景默认 voteConfig（创建活动预填）
// ballotMode（2026-09-12 支书裁定）：正式表决（formal）按制度锁定无记名（UI 不可改、服务端校验）；
//   事务性表决（deliberative）默认记名，发起人可选无记名（匿名模式可选）。
export function defaultVoteConfig(scenarioId) {
  if (scenarioId === 'branch-party-meeting') {
    return { mode: 'async', optionSet: 'formal', ballotMode: 'anonymous', voterScope: 'formal-only', voterIds: [], quorumCheck: true };
  }
  if (scenarioId === 'branch-committee') {
    return { mode: 'async', optionSet: 'deliberative', ballotMode: 'named', voterScope: 'committee', voterIds: [], quorumCheck: false };
  }
  return null; // 非决策类不支持线上表决
}

// 按 voterScope 解析应到名单（基于 people.js developStage / 支委角色）
// 2026-09-06 ②批：范围选定后再剔除滞留成员（isDetained，roster 口径单一源）——
//   支部党员大会 formal-only（正式党员，有表决权）/ formal-plus-prep（= 支部大会应到名单，
//   与 roster getMeetingRosterIds({type:'支部党员大会'}) 同集）；线上支委会 committee = 支委名单
//   （若支委滞留则剔）。返回现时名单，供新活动创建时固化；历史活动快照不回改。
export function resolveVoterIds(voterScope) {
  const people = PersonStore.getAll();
  let list;
  if (voterScope === 'committee') {
    // 名单 = constants.js::resolveCommitteeIds 单一源（角色派生）；无支委角色时返回空名单 +
    // 明确告警，由创建/写入口显式失败（P1-09：不再回退写死的演示 id）。
    const committee = resolveCommitteeIds(people);
    if (committee.error) console.warn(`[vote-config] ${committee.error}`);
    const ids = new Set(committee.ids);
    list = people.filter((p) => ids.has(p.id));
  } else if (voterScope === 'formal-only') {
    list = people.filter((p) => !p.id.startsWith('u_') && p.developStage === '正式党员');
  } else if (voterScope === 'formal-plus-prep') {
    list = people.filter((p) => !p.id.startsWith('u_') && (p.developStage === '正式党员' || p.developStage === '预备党员'));
  } else {
    return [];
  }
  return list.filter((p) => !isDetained(p)).map((p) => p.id);
}

/**
 * ③ 参与人范围轴（契约 §8.3，2026-09-29 批次 275）：「名单解析模式」的**消费面**（只改「从哪取名单」）。
 * · `orgMode:'none'`（含缺省）⇒ 与 `resolveVoterIds` **逐字一致**（默认零影响）；本函数复用其为唯一实现。
 * · `orgMode:'organizer-deep'` ⇒ 在角色全集上**并入该场活动/专班的指派层**（组织者 ＋ 深度参与者）。
 * ⚠ 指派层是**项目绑定岗位**（支书 2026-09-29「人是人，岗位是岗位」）——**不是档案角色、不新增 tab**；
 *   其效果只落在**该具体 activity/taskforce 的操作权限**上；具体人名**不落 config**（§8.3）。
 * @param {string} voterScope 见 resolveVoterIds
 * @param {{mode?:string, orgMode?:string}} [policy] 生效策略（支部覆盖 ?? manifest 声明）
 * @param {string[]} [assignedIds] 该活动的指派层（组织者 ＋ 深度参与者）
 * @returns {string[]} 候选名单（角色全集在前，指派层按入参顺序去重追加）
 */
export function resolveParticipantIds(voterScope, policy, assignedIds) {
  const base = resolveVoterIds(voterScope);
  if (policy?.orgMode !== 'organizer-deep') return base;
  const seen = new Set(base);
  const out = base.slice();
  for (const id of (Array.isArray(assignedIds) ? assignedIds : [])) {
    if (typeof id === 'string' && id && !seen.has(id)) { seen.add(id); out.push(id); }
  }
  return out;
}

/**
 * **我是否是本场表决的「应到表决人」（单一源）**——2026-09-30 批次 304 立。
 * 依据（支书 2026-09-30 原话）：「**即使是支部书记 / 其他支委 投票，在投票的时候也就是普通党员**」
 *   ⇒ **表态权与角色无关**，只看本场活动**创建时固化的应到名单** `voteConfig.voterIds`（快照，不回改）。
 * 为什么必须单一源：此前该判据在仓库里**有三份各写一遍**——`entries/pages/activity-entry.js` 内联一份、
 *   `components/governance/vote-widget.js` 靠调用方传 `canVote`（自身不判）、而
 *   `components/record/inspector.js` 的表态位**多挂了一道 `isCommittee` 角色门** ⇒ 同一件事两种口径
 *   （**应到名单内的普通党员在支书台看不到表态位**，而活动详情页看得到）。本函数把口径收回一处，
 *   两个调用点同批改成消费它。
 * ⚠ **批次 304 收得不全**（2026-09-30 批次 312 查实并补齐）：`inspector.js` 当时只改了「表态位是否挂」，
 *   而**表态面板的动作门（`!locked && isCommittee`）与填充循环（`if (isCommittee)`）仍是角色门** ⇒
 *   应到名单内的普通党员在支书台**挂得出空槽**（面板无按钮、循环根本不填）。批次 312 把这两处一并改 `canVote`。
 * @param {{voteConfig?:{voterIds?:string[]}}} activity 活动（取固化应到名单）
 * @param {string|null|undefined} personId 当前登录人
 * @returns {boolean}
 */
export function isVoterOf(activity, personId) {
  if (!personId) return false;
  const ids = activity?.voteConfig?.voterIds;
  return Array.isArray(ids) && ids.includes(personId);
}

export function optionSetOf(activity) {
  const os = activity?.voteConfig?.optionSet;
  return (os && OPTION_SETS[os]) ? OPTION_SETS[os] : OPTION_SETS.deliberative;
}
