// role: [工程师]+[AI]
// components/shell/sidebar.js — 共享侧边栏（角色单页制 v2）
// 2026-07-29: 角色单页制重构——合并党建/党务为"工作台"单入口
// - 移除 '党务管理' / '人员管理' 独立入口
// - '党建工作台' → '工作台'（角色自适应跳转）
// - 帮助/关于移入主导航区
// 2026-09-09（设置中心批1）：footer 增「设置」入口（→ settings.html）；
// 原 footer 三块外观控件（字号/主题三态/强调色）迁往设置页外观区（components/shell/appearance-controls.js，
// 键位语义不变）；外观偏好读写改走 core/boot/theme.js 键空间适配层（登录人 person 键 / 访客全局键）。
// 模块顶层调用 syncAppearanceForActiveUser()：每页壳加载即把当前登录人 person 偏好应用到 DOM
// （R1-A 2026-09-09 支书裁决：不写全局键、person 无键=出厂默认不继承；冻结读取点
// theme-init.js 首帧 / bootstrap.js 字号 / constants.js resolveAccentRole 保持全局键语义不改）。

import { getBasePath } from '../../core/base/utils.js?v=20261028a';
import { icon } from '../../core/base/icons.js?v=20261028a';
import { syncAppearanceForActiveUser } from '../../core/boot/theme.js?v=20261028a';
import { readLoginSnapshot } from '../../core/session/login-snapshot.js?v=20261028a';

// 外观键空间适配：页面壳加载即执行（全站每页均渲染 sidebar，天然覆盖公共页/工作台）
syncAppearanceForActiveUser();

// ── 数据层按需加载（静态页隔离，2026-08-12）──
// about/help 等纯静态文档页以 staticShell 渲染侧边栏：不预加载 auth 数据链
// （auth→runtime→mock→domain 全量约 50 模块）。但登录态感知——已登录用户
// （从 app 页跳转过来）需看到完整壳（工作台入口/退出登录/身份主题色），
// 通过 readLoginSnapshot() 轻量读快照判断，确已登录才动态加载 auth 完善壳。
// 动态 import 沿用与原静态 import 相同的版本号 → 与全站其他引用共享同一模块实例。
let AuthStore = null;
let _authModule = null;
function loadAuth() {
  if (!_authModule) _authModule = import('../../services/core/auth.js?v=20261028a');
  return _authModule;
}

// ── 党委视图全局导航收敛（支书立项⑦ A波，2026-09-06）────────────
// 产品口径：party-staff（党委组织员/党务老师）视图 = 全局治理面，不含支部运行功能入口
// （首页/资料查询/意见反馈/归档库等支部数据浏览页）；仅保留治理/必要项——「工作台」按
// ROLE_PAGE_MAP 直达 party-committee.html 党委工作台。判定依据：party-staff 登录直达
// 党委工作台（login-entry），首页 dashboard 无其治理内容（均为支部运行区块），非落点必需。
// 支部层各角色（支书/副支书/三委员/组长/成员）导航行为不变。
const PARTY_STAFF_HIDDEN_NAV = new Set(['dashboard', 'search', 'feedback', 'archive', 'messages']);

// 页脚动作（帮助/设置/登录/退出）共用一档：Caption 12px、紧凑 28px（2026-10-18 支书实报
// 「间距太大」后由 36px 收紧）。样式单一源＝styles.css `.sidebar-footer-action`，此处不再写内联样式。

function getNavItems() {
  const base = getBasePath();
  return [
    { module: 'dashboard', label: '首页', href: base + 'index.html', icon: icon('home', { extra: ' aria-hidden="true"' }) },
    { module: 'workspace', label: '工作台', icon: icon('calendar', { extra: ' aria-hidden="true"' }) },
    // 「消息」（2026-10-25 Task 3）：公告 / 系统通知 / 私信的唯一列表入口；未读角标走 countUnread。
    { module: 'messages', label: '消息', href: base + 'messages.html', icon: icon('mail', { extra: ' aria-hidden="true"' }) },
    { module: 'search', label: '资料查询', href: base + 'search.html', icon: icon('search', { extra: ' aria-hidden="true"' }) },
    { module: 'feedback', label: '意见反馈', href: base + 'feedback.html', icon: icon('message', { extra: ' aria-hidden="true"' }) },
    { module: 'archive', label: '归档库', href: base + 'archive.html', icon: icon('archive', { extra: ' aria-hidden="true"' }) },
  ];
}

function getFooterItems() {
  const base = getBasePath();
  // 图标由下方 _footerIcon(module) 单点决定，此处不再重复声明 icon 字段。
  const items = [
    { module: 'help', label: '帮助', href: base + 'help.html' },
  ];
  // 「关于」撤路由（2026-10-27 Task 12.4）：about.html 文件保留（旧外链仍可直达），
  // 但不再有任何导航入口——侧边栏/帮助目录/README 指针一并撤除。
  // 「设置」入口（设置中心批1，2026-09-09）：全形态可见——访客进设置页仅外观，登录人按角色分组
  items.push({ module: 'settings', label: '设置', href: base + 'settings.html' });
  return items;
}

// footer 图标按模块取（stroke 随 footer 弱化色；设置=齿轮，档案=文档）
function _footerIcon(module) {
  const name = module === 'help' ? 'book' : module === 'settings' ? 'gear' : module === 'profile' ? 'fileText' : 'info';
  return icon(name, { stroke: 'var(--neutral-500)', extra: ' aria-hidden="true"' });
}

export async function renderSidebar(activeModule, opts = {}) {
  const sidebar = document.getElementById('app-sidebar');
  if (!sidebar) return;

  const staticShell = !!opts.staticShell;

  // 登录态感知壳：静态页轻量读快照（零依赖）——已登录才动态加载 auth 完善壳；
  // app 模式按需加载 auth 后按当前用户渲染（模块缓存后即时）
  if (staticShell) {
    if (readLoginSnapshot()) {
      try {
        ({ AuthStore } = await loadAuth());
      } catch (e) {
        console.warn('[sidebar] auth 加载失败，降级为访客壳', e);
      }
    }
  } else {
    try {
      ({ AuthStore } = await loadAuth());
    } catch (e) {
      console.warn('[sidebar] auth 加载失败，降级为访客壳', e);
    }
  }
  const user = AuthStore ? AuthStore.getCurrentUser() : null;
  // 使用常设角色（非 effective role）决定导航结构
  const role = user ? AuthStore.getUserRole(user.personId) : '';

  // party-staff（党委视图）隐藏支部运行导航项（PARTY_STAFF_HIDDEN_NAV）；
  // 其余角色 / 访客不过滤，导航行为与既往完全一致
  const navItems = getNavItems().filter(item => !(role === 'party-staff' && PARTY_STAFF_HIDDEN_NAV.has(item.module)));
  const navHTML = navItems.map(item => {
    // 工作台：根据角色自动跳转对应页面
    let href = item.href;
    if (item.module === 'workspace') {
      const pages = user ? AuthStore.getAccessibleWorkspacePages(user.personId) : [];
      if (pages.length === 0) return '';
      const standingPage = AuthStore.getPageForRole('workspace', role);
      if (!standingPage) return '';
      href = getBasePath() + 'workspace/' + standingPage;
      // 2026-09-03 清理余毒：多身份"选择进入身份"弹窗冗余——项目角色(组织者/深参与)
      // 没有独立工作台页，内容落在成员工作台（workspace/visitor.html）而非首页（2026-09-17 批次 64 实测
      // 首页无「我的角色」区块）；身份切换走 header 下拉；sidebar 工作台一律直达常设工作台。
      // （原 data-workspace-popover 触发 + workspace-popover.js 已删除）
    }

    return `
      <a href="${href}" class="module-tab ${item.module === activeModule ? 'active' : ''}" data-module="${item.module}"${item.module === activeModule ? ' aria-current="page"' : ''}>
        ${item.icon}
        <span class="font-title-cn">${item.label}</span>
        ${item.module === 'messages' ? '<span id="sidebar-message-badge" class="text-xs text-white font-semibold rounded-full items-center justify-center" style="display:none;min-width:16px;height:16px;padding:0 4px;margin-left:auto;background:var(--party-red);"></span>' : ''}
      </a>
    `;
  }).join('');

  const footerItems = getFooterItems();
  // 「我的档案」（2026-10-28）：顶栏同名入口在 ≤640 收起（styles.css 的 #header-my-profile），
  // 390 下改由侧栏页脚承担；该类在桌面 display:none（避免与顶栏重复），≤640 才显示。
  if (role && role !== 'party-staff') {
    footerItems.unshift({ module: 'profile', label: '我的档案', href: getBasePath() + 'person.html', mobileOnly: true });
  }
  const footerHTML = footerItems.map(item => `
    <a href="${item.href}" data-module="${item.module}" class="sidebar-footer-action${item.mobileOnly ? ' sidebar-footer-action--mobile-only' : ''}">
      ${_footerIcon(item.module)}
      <span>${item.label}</span>
    </a>
  `).join('');

  // 登录态对偶入口（支书 2026-09-07 U1 批准）：已登录=「退出登录」；访客/未登录=「登录」→ login.html
  // （同位同样式同 hover；图标为 logout 镜像 → 「进入」感，不新增图标字典项）
  const authEntryHTML = user ? `
      <button id="sidebar-logout" type="button" class="sidebar-footer-action">
        ${icon('logout', { stroke: 'var(--neutral-500)', extra: ' aria-hidden="true"' })}
        <span>退出登录</span>
      </button>` : `
      <a href="${getBasePath()}login.html" id="sidebar-login" class="sidebar-footer-action">
        <span class="sidebar-footer-action__mirror">${icon('logout', { stroke: 'var(--neutral-500)', extra: ' aria-hidden="true"' })}</span>
        <span>登录</span>
      </a>`;

  sidebar.innerHTML = `
    <nav class="sidebar-nav" aria-label="主导航">
      <div class="flex flex-col gap-2 mb-2">${navHTML}</div>
    </nav>
    <div class="sidebar-footer">
      <nav class="flex flex-col gap-0.5 mb-2" aria-label="辅助导航">${footerHTML}</nav>
      ${authEntryHTML}
    </div>
  `;

  if (user) {
    _bindLogout(sidebar);
    // 静态壳页（帮助等）不加载通知数据链，与顶栏铃铛同策略：app 页才挂未读角标。
    if (!staticShell) _bindMessageBadge();
  }
}

// ── 「消息」未读角标（Task 3 · 2026-10-25）───────────────────────────
// 读数单一源 = NoticeStore.countUnread（与消息中心列表 / 顶栏铃铛同源）。
let _badgeBound = false;

async function _refreshMessageBadge() {
  const badge = document.getElementById('sidebar-message-badge');
  if (!badge) return;
  try {
    const { NoticeStore } = await import('../../services/governance/notice.js?v=20261028a');
    const unread = NoticeStore.countUnread(readLoginSnapshot()?.personId || null);
    if (unread > 0) {
      badge.textContent = unread > 9 ? '9+' : String(unread);
      badge.style.display = 'flex';
      badge.setAttribute('aria-label', `${unread} 条未读消息`);
    } else {
      badge.style.display = 'none';
      badge.removeAttribute('aria-label');
    }
  } catch (_) { /* 静态页未加载数据链：静默（无角标可渲染） */ }
}

async function _bindMessageBadge() {
  await _refreshMessageBadge();
  if (_badgeBound) return;
  _badgeBound = true;
  try {
    const { DATA_CHANGED_EVENT, DATA_LOADED_EVENT } = await import('../../data/data-adapter.js?v=20261028a');
    document.addEventListener(DATA_CHANGED_EVENT, _refreshMessageBadge);
    document.addEventListener(DATA_LOADED_EVENT, _refreshMessageBadge);
  } catch (_) { /* 静默 */ }
}

// 外观控件（字号/主题三态/强调色）已迁往设置页外观区：
// components/shell/appearance-controls.js（render+bind 复用，2026-09-09 设置中心批1）

function _bindLogout(sidebar) {
  const btn = sidebar.querySelector('#sidebar-logout');
  if (!btn) return;
  btn.addEventListener('click', () => {
    AuthStore.logout();
    window.location.href = getBasePath() + 'login.html';
  });
}
