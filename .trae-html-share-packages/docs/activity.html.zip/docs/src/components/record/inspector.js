// role: [工程师]+[AI]
// ════════════════════════════════════════════════════════════════
//  inspector.js — 右侧检查器面板渲染逻辑
//  包含：filterTasksByManagementRole, renderInspectorFromState,
//        renderInspectorList, renderInspectorDetail
// ════════════════════════════════════════════════════════════════

import { setState, STATE, getAppState } from '../../core/base/state.js?v=20261028b';
import { ROLE_COLORS, ROLE_LABELS, ROLE_THEME_CLASS, COMMISSIONER_ROLES, SECRETARY_ROLES, ACTIVITY_CLASSIFICATION } from '../../core/domain/constants.js?v=20261028b';
import { _fmtChinese, showToast, escHtml as esc } from '../../core/base/utils.js?v=20261028b';
import { icon } from '../../core/base/icons.js?v=20261028b';
import { openModal, closeModal, confirmDanger } from '../ui/modal.js?v=20261028b';
// 数据域接线收口（2026-09-03）：支部成员名单经 services/member/person.js 获取（原直连 mock PEOPLE）
// 实时视图（非快照）：成员增删即时可见——见 services/member/person.js liveMembers 说明
const PEOPLE = liveMembers();
import { getPersonById } from '../../services/member/person.js?v=20261028b';
import { BranchService } from '../../services/core/runtime.js?v=20261028b';
import { AuthStore } from '../../services/core/auth.js?v=20261028b';
import { liveMembers, PersonStore, getPersonName } from '../../services/member/person.js?v=20261028b';
import { statusBadgeHtml, bindStatusBadge, badgeHtml } from '../ui/badges.js?v=20261028b';
// 表态权判据单一源：`isVoterOf` —— **角色无关**，只看本场固化应到名单。
// 依据：支书 2026-09-30 原话「**即使是支部书记 / 其他支委 投票，在投票的时候也就是普通党员**」。
import { isVoterOf } from '../../services/activity/vote-config.js?v=20261028b';
// 作废确认弹窗（单一源）
import { openVoidModal } from '../ui/void-record.js?v=20261028b';
import { persist, getAuthToken, getApiBaseUrl, getAdapter } from '../../data/data-adapter.js?v=20261028b';
import { withSelectedBranchScope } from '../../data/api-adapter.js?v=20261028b';
import { recordAgendaResultForActivity } from '../../services/activity/agenda-follow-up.js?v=20261028b';
// 制度链（2026-09-21 批次 129）：制度草案议程项在「记录结果」旁给一个「报送党员大会表决」勾选位——
// 判据单一源在 branch-doc.js（勿在界面另写一份 purpose/status 判断）。
import { isInstitutionDraftAgendaItem } from '../../services/branch/branch-doc.js?v=20261028b';
// 品牌认定（2026-09-21 批次 132 · 支书口径二「支委/党小组组长均可以提案，支委会通过后确定」）：判据与写口单一源 = services/activity/activity.js；
// 本处只渲染「提案 / 撤回 / 取消认定」三种动作，**不再有「点一下即认定」**；同源另取三项（2026-09-21 批次 135）：追加复盘要求进关闭判据。
import { canProposeBrand, brandProposalOf, proposeBrandDesignation, withdrawBrandProposal, revokeBrandDesignation, PENDING_APPROVAL_STATUS, canApproveActivity, approveActivity, rejectActivity, activityApprovalVoteOf, openCommitteeVoteForActivity } from '../../services/activity/activity.js?v=20261028b';
// 活动批准门当前档位（2026-09-22 批次 150）：参数本体单一源 = core/domain/policy-defaults.js::activityApproval.mode
import { activityApprovalMode, ACTIVITY_APPROVAL_MODE_LABELS } from '../../core/domain/policy-defaults.js?v=20261028b';
// 议程行内编辑纯函数（2026-09-06 复用激活）：createEditableAgenda 整对象投影随行保留扩展字段；
// normalizeEditedAgenda 保存时 {...原对象, item/host} 重建并剔空行——修复编辑丢 id/配置/结果的数据安全事故
import { createEditableAgenda, normalizeEditedAgenda } from '../../services/activity/agenda-editing.js?v=20261028b';
import { agendaDecisionSource, validateAgendaStructure } from '../../services/activity/agenda-relations.js?v=20261028b';
// 议程更新后通知全员（活动锚定，targetType/targetId 供归档联动）
import { NoticeStore } from '../../services/governance/notice.js?v=20261028b';
import { fetchVotes, submitVote } from '../../services/activity/committee-vote.js?v=20261028b';
import { optionSetOf, resolveVoterIds, OPTION_SETS, isAnonymousActivity } from '../../services/activity/vote-config.js?v=20261028b';
import { renderVoteSummary } from '../governance/vote-summary-panel.js?v=20261028b';
import { loadAttendanceRecords, canUploadAttendance, isAttendanceConfirmed } from '../../services/activity/attendance.js?v=20261028b';
import { loadInspectionRecords } from '../../services/activity/inspection.js?v=20261028b';
import { loadActivityReviews } from '../../services/governance/review.js?v=20261028b';
import { mockDB, OutputType, deriveOutputRoute, ReviewStatus } from '../../core/domain/domain.js?v=20261028b';
// 2026-10-25 批次 510：关闭条件判据迁到服务层（待办派生也要用同一判据）；本文件只转出，调用点不变。
import { checkActivityCloseConditions } from '../../services/activity/close-conditions.js?v=20261028b';
// Task 6：右栏卡是「所属工作台内」入口 ⇒ locate；完整页出口统一走对象路由（缺 id 不渲染）。
import { objectDetailHref } from '../../core/domain/object-route.js?v=20261028b';

import { emptyStateHtml } from '../ui/empty-state.js?v=20261028b';
// T-217 §2.4：任务状态定义（status-badge 用，色点 + 文字）
const TASK_STATUSES = {
  pending:     { label: '待处理', color: '#9CA3AF' },
  in_progress: { label: '进行中', color: '#D97706' },
  completed:   { label: '已完成', color: '#16A34A' },
};

// T-218：活动执行态由任务进度派生（支书裁决 2026-08-05「进度驱动活动状态」）
// - 有关联任务且全部 completed → 'completed'（已完成）
// - 有关联任务且未全部完成 → 'ongoing'（进行中）
// - 无关联任务 → 保持计划态（draft/published）原样
// 以全活动任务为准（呼应支书「支书看全部任务」裁决）；展示与写联动统一走本函数。
export function deriveActivityExecutionStatus(activity, allTasks) {
  const actTasks = allTasks.filter(t => t.activityId === activity.id);
  if (actTasks.length === 0) return activity.status;
  const allDone = actTasks.every(t => t.status === 'completed');
  return allDone ? 'completed' : 'ongoing';
}

// ── 活动生命周期态（2026-08-07 支书裁决：消除"已完成 vs 未归档"矛盾）──
// 草稿→已发布→进行中→已执行→待归档→已归档（+已取消）
// "已完成"字样全站移除：执行完毕且产出齐备才为"已执行"，产出缺失为"待归档"。
export const ACTIVITY_LIFECYCLE = {
  draft:          { label: '草稿',   variant: 'neutral' },
  pending_approval:{ label: '待批',   variant: 'warning' },
  // 2026-10-24 批次 508：信息态白名单——「已发布」是流程已完成但非终态的信息展示，
  // 保留 info（蓝）与 archived/neutral、executed/success 三态区分；不属于「活动类别恒灰」问题。
  published:      { label: '已发布', variant: 'info' },
  ongoing:        { label: '进行中', variant: 'warning' },
  pending_archive:{ label: '待归档', variant: 'warning' },
  executed:       { label: '已执行', variant: 'success' },
  archived:       { label: '已归档', variant: 'neutral' },
  cancelled:      { label: '已取消', variant: 'neutral' },
};

export function deriveActivityLifecycleStatus(activity, allTasks) {
  if (activity.status === 'cancelled') return 'cancelled';
  if (activity.archived) return 'archived';
  if (activity.status === 'draft') return 'draft';
  if (activity.status === PENDING_APPROVAL_STATUS) return 'pending_approval';
  const exec = deriveActivityExecutionStatus(activity, allTasks || []);
  if (exec === 'completed') {
    const { canClose, missing } = checkActivityCloseConditions(activity);
    return canClose ? 'executed' : 'pending_archive';
  }
  return exec; // published | ongoing
}

export function activityLifecycleBadgeHtml(activity, allTasks) {
  const st = deriveActivityLifecycleStatus(activity, allTasks || []);
  const meta = ACTIVITY_LIFECYCLE[st] || ACTIVITY_LIFECYCLE.draft;
  const title = st === 'pending_archive'
    ? `待归档：${checkActivityCloseConditions(activity).missing.join('、')}`
    : undefined;
  return badgeHtml(meta.label, meta.variant, { title });
}

// ════════════════════════════════════════════════════════════════
//  RBAC 任务过滤核
//  commissioner 系列：兼容多种 executor/supervisor 字符串
// ════════════════════════════════════════════════════════════════
export function filterTasksByManagementRole(tasks, managementRole) {
  if (managementRole === 'participant' || !managementRole) return tasks;
  // 支书（党支书）为支部总负责人：活动详情展示该活动全部任务节点，便于全面监督（T-217 支书裁决 2026-08-05）
  if (managementRole === 'secretary') return tasks;
  return tasks.filter(t => {
    const ex  = t.executor  || '';
    const sup = t.supervisor || '';
    if (managementRole === 'org-commissioner' || managementRole === 'prop-commissioner' || managementRole === 'disc-commissioner') {
      return COMMISSIONER_ROLES.has(ex) || COMMISSIONER_ROLES.has(sup) || ex === managementRole || sup === managementRole;
    }
    return ex === managementRole || sup === managementRole;
  });
}

// ════════════════════════════════════════════════════════════════
//  检查器状态路由分发（根据 viewMode / viewType 切换 List / Detail）
// ════════════════════════════════════════════════════════════════
export function renderInspectorFromState(state = getAppState()) {
  if (!state || !state.activities) return;
  if (state.viewType === 'participant' && state.viewMode !== 'detail') {
    renderInspectorList(state.activities, state.selectedDate, state.viewType, state.viewArchived);
    return;
  }

  if (state.viewMode === 'detail' && state.selectedActivityId) {
    const act = state.activities.find(a => a.id === state.selectedActivityId);
    if (act) {
      const actTasks = state.tasks.filter(t => t.activityId === act.id);
      renderInspectorDetail(act, actTasks, state.managementRole);
    } else {
      renderInspectorList(state.activities, state.selectedDate, state.viewType, state.viewArchived);
    }
  } else {
    renderInspectorList(state.activities, state.selectedDate, state.viewType, state.viewArchived);
  }
}

// ════════════════════════════════════════════════════════════════
//  轻量参与者浮层（DOM Modal）
// ════════════════════════════════════════════════════════════════
function _showParticipantModal(act) {
  // 只读摘要也走统一浮层（DESIGN_SYSTEM §4.27）：dialog 语义 / 焦点接管 / 背景 inert 由 modal.js 单点提供
  const orgPerson = getPersonById(act.organizer);
  const rows = [
    `<p class="text-sm text-gray-700">标题：${esc(act.title || '')}</p>`,
    `<p class="text-sm text-gray-700">日期：${esc(act.date || '未设定')}</p>`,
  ];
  if (orgPerson) rows.push(`<p class="text-sm text-gray-700">组织者：${esc(orgPerson.name || '')}</p>`);
  if (act.participants && act.participants.length > 0) {
    const deepNames = act.participants
      .filter(pid => pid !== act.organizer)
      .map(pid => getPersonById(pid)?.name)
      .filter(Boolean);
    if (deepNames.length > 0) rows.push(`<p class="text-sm text-gray-700">参与者：${esc(deepNames.join('、'))}</p>`);
  }

  openModal({
    id: 'participant-summary',
    title: '活动摘要',
    size: 'sm',
    bodyHtml: `
      <div class="space-y-1.5">${rows.join('')}</div>
      <p class="text-xs text-gray-500 border-t border-gray-100 pt-3 mt-3 leading-relaxed">如需查看任务详情，请前往对应的工作台页面。</p>`,
    footerHtml: `<button type="button" data-modal-cancel="participant-summary" class="btn-accent text-sm px-4 py-1.5">关闭</button>`,
  });
}

// ════════════════════════════════════════════════════════════════
//  列表视图：渲染指定日期的活动列表（普通或归档模式）
// ════════════════════════════════════════════════════════════════
/** 考勤上传位：按角色落本位；无本位返回空串（不造假入口）。 */
function _attendanceUploadHref(role, actId) {
  const id = encodeURIComponent(actId || '');
  if (role === 'leader' || role === 'deputy-leader') return `./workspace/leader.html?tab=attendance&focusActivityId=${id}`;
  if (role === 'disc-commissioner') return `./workspace/disc.html?tab=attendance&focusActivityId=${id}`;
  if (role === 'participant') return './workspace/visitor.html?tab=attendance#org-host';
  return '';
}

/** 考勤上传入口：仅在 `canUploadAttendance` 且本角色确有上传位时给出；否则返回空串。 */
function _attendanceActionHtml(act) {
  const me = AuthStore.getCurrentUser();
  const href = _attendanceUploadHref(me?.role, act.id);
  if (!href || !canUploadAttendance(me?.personId, act.id)) return '';
  return `<a href="${href}" class="text-xs text-accent" data-inspector-attendance>登记考勤</a>`;
}

/**
 * 管理侧右栏每行的就地动作（2026-10-20 R3-05）：
 *   查看详情 / 写纪要 / 登记考勤（仅在 `canUploadAttendance` 且本角色确有上传位时出现）。
 * 为什么不做成整卡点击：日期清单的价值是「点进来就能办一件事」，整卡只跳详情等于把左栏标签又说一遍。
 */
function _inspectorAdminActionsHtml(act) {
  const id = encodeURIComponent(act.id || '');
  // Task 6：本卡在「活动管理」所属工作台内 ⇒ locate（同页预览 + 「打开完整页」），
  //   不整页跳走丢失右栏/筛选；缺 id 时不渲染该出口。
  const detailHref = objectDetailHref('activity', act.id, { entry: 'owner-workspace' });
  const links = [
    detailHref ? `<a href="./${detailHref}" class="text-xs text-accent" data-inspector-open>打开完整页 →</a>` : '',
    `<a href="./activity-materials.html?id=${id}" class="text-xs text-accent" title="材料清单：宣传材料 / 考勤 / 考察 / 复盘">材料与归档</a>`,
  ];
  const attendance = _attendanceActionHtml(act);
  if (attendance) links.push(attendance);
  return `<div class="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1" data-inspector-actions>${links.filter(Boolean).join('')}</div>`;
}

/** 管理侧活动的组织者文字（复用活动 assignments 口径，不新造字段）。 */
function _organizerText(act) {
  const ids = [...new Set([
    act.organizer,
    ...(Array.isArray(act.assignments)
      ? act.assignments.filter((member) => member && member.role === 'organizer').map((member) => member.personId)
      : []),
  ].filter(Boolean))];
  return ids.length ? ids.map((id) => getPersonName(id) || id).join('、') : '待指定';
}

export function renderInspectorList(activities, dateKey, viewType, viewArchived = false) {
  const defEl     = document.getElementById('inspector-default');
  const contentEl = document.getElementById('inspector-content');
  const titleEl   = document.getElementById('inspector-date-title');
  const cardsEl   = document.getElementById('inspector-cards');
  if (!defEl || !contentEl) return;

  let dateActivities;
  if (viewArchived) {
    dateActivities = activities.filter(a => a.archived === true);
  } else {
    dateActivities = dateKey
      ? activities.filter(a => !a.archived && a.date === dateKey)
      : [];
  }

  const isParticipant = !viewArchived && (viewType === 'participant' || !viewType);

  if (dateActivities.length === 0) {
    defEl.classList.remove('hidden');
    if (viewArchived) {
      defEl.innerHTML = emptyStateHtml({ text: "归档库暂无活动", variant: 'panel' });
    } else if (dateKey && !isParticipant) {
      // 管理侧空日不是死路：带日期开「写入活动」，把右栏从回声变成动作位。
      defEl.innerHTML = emptyStateHtml({
        variant: 'panel',
        text: '当日暂无活动',
        actionHtml: `<button type="button" class="btn-accent-soft text-xs px-3 py-1.5" data-inspector-new-activity="${esc(dateKey)}">新建活动</button>`,
      });
      defEl.querySelector('[data-inspector-new-activity]')?.addEventListener('click', () => {
        document.dispatchEvent(new CustomEvent('inspector:new-activity', { detail: { date: dateKey } }));
      });
    } else if (dateKey) {
      defEl.innerHTML = emptyStateHtml({ text: "当日暂无活动", variant: 'panel' });
    } else {
      defEl.innerHTML = '<div class="text-center text-gray-500 py-8  text-sm">未选择日期</div>';
    }
    contentEl.classList.add('hidden');
    return;
  }
  defEl.innerHTML = '';

  defEl.classList.add('hidden');
  contentEl.classList.remove('hidden');

  if (titleEl) {
    titleEl.textContent = viewArchived
      ? '归档库 · 已归档活动'
      : `${_fmtChinese(new Date(dateKey + 'T00:00:00'))} · ${dateActivities.length} 场`;
  }

  // 确保 inspector 可见：滚动到视图中
  contentEl.closest('#inspector-container')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

  const allTasks = (getAppState() || {}).tasks || [];
  let html = '';
  dateActivities.forEach(act => {
    // T229：生命周期徽章（草稿→已发布→进行中→待归档→已执行→已归档），进度+产出共同驱动
    const isBrand = !!act.isBrand;
    const brandTag = isBrand ? badgeHtml('品牌', 'brand') : '';
    if (isParticipant) {
      html += `<div class="inspector-card inspector-card--action" role="button" tabindex="0" aria-label="查看活动摘要：${esc(act.title || '未命名活动')}" data-act-id="${act.id}" style="${isBrand ? 'border-left:3px solid var(--party-gold);' : ''}">`;
      html += `<div class="flex items-start justify-between gap-2 mb-1">`;
      html += `<p class=" font-bold text-sm text-gray-800 leading-snug flex-1">${esc(act.title)}</p>`;
      html += activityLifecycleBadgeHtml(act, allTasks);
      html += '</div>';
      html += `<div class="flex items-center gap-1.5">${brandTag}<p class=" text-xs text-gray-500">活动信息</p></div>`;
      // 本轮组织者在本台有上传位时，右栏也给一个就地出口（只跳本位，不在只读日历里复制表单）。
      const attendance = _attendanceActionHtml(act);
      if (attendance) html += `<div class="mt-2" data-inspector-actions>${attendance}</div>`;
      html += '</div>';
    } else {
      html += `<div class="inspector-card inspector-card--action" role="button" tabindex="0" aria-label="展开活动详情：${esc(act.title || '未命名活动')}" style="${isBrand ? 'border-left:3px solid var(--party-gold);' : ''}" data-act-id="${esc(act.id)}">`;
      html += `<div class="flex items-start justify-between gap-2 mb-1">`;
      html += `<div class="flex items-center gap-1.5 flex-1"><p class=" font-bold text-sm text-gray-800 leading-snug">${esc(act.title)}</p>${brandTag}</div>`;
      html += activityLifecycleBadgeHtml(act, allTasks);
      html += '</div>';
      html += `<p class="mt-0.5 text-xs text-gray-500">${esc(act.date || '')} · 组织者：${esc(_organizerText(act))}</p>`;
      html += _inspectorAdminActionsHtml(act);
      html += '</div>';
    }
  });

  if (cardsEl) {
    cardsEl.innerHTML = html;
    // I3：列表视图无表态面板 → 清除代次标记，防详情页遗留的旧 fetch 触碰列表 DOM
    delete cardsEl.dataset.actId;

    if (!isParticipant) {
      // 行内动作不得被整卡「进详情」吞掉：显式阻止冒泡。
      cardsEl.querySelectorAll('[data-inspector-actions] a').forEach((link) => {
        link.addEventListener('click', (e) => e.stopPropagation());
      });
      cardsEl.querySelectorAll('[data-act-id]').forEach(card => {
        card.addEventListener('click', () => {
          setState({ viewMode: 'detail', selectedActivityId: card.dataset.actId });
        });
      });
    } else {
      cardsEl.querySelectorAll('[data-inspector-actions] a').forEach((link) => {
        link.addEventListener('click', (e) => e.stopPropagation());
      });
      cardsEl.querySelectorAll('[data-act-id]').forEach(card => {
        card.addEventListener('click', () => {
          const act = dateActivities.find(a => a.id === card.dataset.actId);
          if (act) _showParticipantModal(act);
        });
      });
    }
    // Task 6.6：可点卡片键盘同权（Enter / Space），与鼠标点击走同一路径。
    cardsEl.querySelectorAll('[data-act-id][role="button"]').forEach(card => {
      card.addEventListener('keydown', (e) => {
        if (e.target !== card) return;
        if (e.key !== 'Enter' && e.key !== ' ' && e.key !== 'Spacebar') return;
        e.preventDefault();
        card.click();
      });
    });
  }
}

// ════════════════════════════════════════════════════════════════
//  产出物区（T-224 §8 附件查看窗口）
//  同源读取：考勤/考察正式库 + actSubRecords 子记录 + 档案归档记录，
//  投递去向按产出类型确定（OUTPUT_ROUTES 路由表）。
// ════════════════════════════════════════════════════════════════
function _buildOutputsSectionHTML(activity) {
  const actId = activity.id;

  // 考勤数据（正式库，同源）
  const atts = loadAttendanceRecords().filter(r => r.activityId === actId);
  const attRoute = deriveOutputRoute(OutputType.ATTENDANCE);

  // 工作考察（正式库，同源；专班考察不计入活动详情）
  const inss = loadInspectionRecords().filter(r => r.activityId === actId);
  const inspRoute = deriveOutputRoute(OutputType.INSPECTION);

  // 宣传材料（同源：leader actSubRecords.publicity + 宣传委员 archiveRecords）
  // 归档记录以 activityId 为主关联键（2026-08-06 支书裁决），无 activityId 的兜底按活动标题匹配
  const actSubs = (mockDB.actSubRecords && mockDB.actSubRecords[actId]) || {};
  const publicitySubs = actSubs.publicity || [];
  const archiveRecs = (mockDB.archiveRecords || []).filter(r =>
    (r.activityId && r.activityId === actId) || (!r.activityId && r.activityName === activity.title)
  );
  const pubRoute = deriveOutputRoute(OutputType.PUBLICITY);

  // 复盘总结（正式库，同源）
  const review = loadActivityReviews().find(r => r.activityId === actId) || null;
  const reviewRoute = deriveOutputRoute(OutputType.REVIEW);

  // 产出物行：色点 + 名称 + 自动投递去向 + 状态徽标
  const row = (label, route, statusHtml) => `
    <div class="flex items-center gap-2 text-xs py-1">
      <span class="w-1.5 h-1.5 rounded-full flex-shrink-0" style="background:${route && route.color || 'var(--neutral-400)'};"></span>
      <span class="text-gray-600 flex-shrink-0">${label}</span>
      <span class="text-gray-500 text-xs flex-1 truncate">${route ? route.route : ''}</span>
      ${statusHtml}
    </div>`;

  const attStatus = atts.length === 0
    ? badgeHtml('未提交', 'neutral')
    : atts.every(r => isAttendanceConfirmed(r))
      ? badgeHtml(`已确认 ${atts.length}`, 'success')
      : badgeHtml(`待确认 ${atts.filter(r => !isAttendanceConfirmed(r)).length}`, 'warning');

  const inspStatus = inss.length === 0
    ? badgeHtml('未提交', 'neutral')
    : inss.every(r => r.status === 'confirmed')
      ? badgeHtml(`已确认 ${inss.length}`, 'success')
      : badgeHtml(`待确认 ${inss.filter(r => r.status !== 'confirmed').length}`, 'warning');

  const pubItems = [
    // R7-04：历史宣传记录 author 为空 ⇒ 按既有 recordedBy 回填展示（不留无解释的空位）
    ...publicitySubs.map(p => ({ title: p.title || '宣传材料', meta: [p.author || (p.recordedBy ? getPersonName(p.recordedBy) : ''), p.channel].filter(Boolean).join(' · '), status: '已提交' })),
    ...archiveRecs.map(a => ({ title: `${a.category || '材料'}：${a.activityName}`, meta: [a.archiveDate, a.fileName].filter(Boolean).join(' · '), status: a.status === 'archived' ? '已归档' : (a.status === 'in_progress' ? '归档中' : '待归档'), fileName: a.fileName, fileData: a.fileData, filePath: a.filePath, arcId: a.id })),
  ];
  // 2026-10-24 批次 508：材料计数是中性数量信息（非「信息态流程状态」），改 neutral，
  // 避免与「已发布」等生命周期 info 徽章抢同一种蓝色语义。
  const pubStatus = pubItems.length === 0
    ? badgeHtml('未归档', 'neutral')
    : badgeHtml(`${pubItems.length} 项`, 'neutral');

  const reviewStatus = !review
    ? badgeHtml('未提交', 'neutral')
    : (review.reviewStatus === ReviewStatus.CONFIRMED
      ? badgeHtml('已确认', 'success')
      : badgeHtml(review.reviewStatus || '待处理', 'warning'));

  return `
    <div class="mb-3 card rounded-xl p-4">
      <div class="flex items-center justify-between mb-1.5">
        <p class="text-xs text-gray-500">产出物</p>
      </div>
      ${row('考勤', attRoute, attStatus)}
      ${row('考察', inspRoute, inspStatus)}
      ${row('宣传', pubRoute, pubStatus)}
      ${row('复盘', reviewRoute, reviewStatus)}
      ${pubItems.length > 0 ? `
        <div class="mt-1.5 pt-1.5 border-t border-gray-100">
          <div class="text-xs text-gray-500 mb-1">宣传材料预览：</div>
          ${pubItems.slice(0, 5).map(it => `
            <div class="flex items-center justify-between text-xs text-gray-600 py-0.5">
              <span class="truncate pr-2">${it.title}</span>
              <span class="text-gray-500 flex-shrink-0">${it.meta ? it.meta + ' · ' : ''}${it.status}</span>
              ${it.fileName ? `<button type="button" class="btn-outline btn-sm insp-pub-dl flex-shrink-0" data-arc-id="${it.arcId}" title="下载 ${it.fileName}">下载</button>` : ''}
            </div>`).join('')}
          ${pubItems.length > 5 ? `<div class="text-xs text-gray-500">…另有 ${pubItems.length - 5} 项</div>` : ''}
        </div>` : ''}
    </div>`;
}

// ════════════════════════════════════════════════════════════════
//  分类型关闭条件（T-224 §7）
//  三会一课（党小组会/支委会/党课/支部党员大会）→ 支书关闭：
//    会议纪要 + 请假已确认（缺勤需补课闭环）
//  主题党日 → 支书关闭：
//    考勤确认 + 考察确认 + 复盘确认 + 宣传归档
//  专班 → 组织委员解散（另见 ws-org-commissioner-entry）：考察确认 + 工作量报告
//  产出缺失阻塞关闭，缺失项在关闭入口明确显示（最小信息成本）。
// ════════════════════════════════════════════════════════════════
// 三会四子类单一源 = ACTIVITY_CLASSIFICATION['three-meetings'].subtypes（2026-09-03 去重收口，勿再手写清单）
// 2026-10-25 批次 510：关闭条件判据整段迁至 services/activity/close-conditions.js（服务层复用，避免 UI↔服务成环）；
//   本文件原样转出，调用点与对外导出名不变。
export { checkActivityCloseConditions };

function _showCloseBlockModal(activity, missing) {
  openModal({
    id: 'activity-close-block',
    title: `无法关闭「${activity.title || ''}」`,
    size: 'sm',
    bodyHtml: `
      <p class="text-xs text-gray-500 mb-3">以下产出未齐，补齐后方可关闭：</p>
      <ul class="space-y-1.5">
        ${missing.map(m => `<li class="text-xs text-red-600 flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-red-400 flex-shrink-0"></span>${esc(m)}</li>`).join('')}
      </ul>`,
    footerHtml: `<button type="button" data-modal-cancel="activity-close-block" class="btn-accent text-sm px-4 py-1.5">知道了</button>`,
  });
}

// ════════════════════════════════════════════════════════════════
//  详情视图：渲染单个活动的任务列表与危险操作按钮
// ════════════════════════════════════════════════════════════════

/** 议程结果徽章文案/配色（S-1：新增 partial=部分通过） */
const AGENDA_RESULT_META = {
  passed:   { label: '已通过',   cls: 'text-green-700 bg-green-50' },
  partial:  { label: '部分通过', cls: 'text-amber-700 bg-amber-50' },
  rejected: { label: '未通过',   cls: 'text-red-700 bg-red-50' },
};

/** 草案已附材料件数（SOP-B-13 第 4 项 · D-305）：过程材料跟草案走（附件 / 网页正文各计 1 件），
 *  不新增「材料包」——议程项只做数量只读提示，材料本体仍归那份草案；导出供创建表单议程行「同款提示」复用（calendar-tab.js）。 */
export function _draftMaterialCount(doc) {
  return (doc && doc.fileName ? 1 : 0) + (doc && String(doc.bodyText || '').trim() ? 1 : 0);
}

/** 议程类型徽章（2026-09-01 支书点验链路 ①/②）：讨论文件 → 草案标题 ＋ 已附材料件数；待讨论名单 → 人数与目标阶段（S-2 只显目标） */
function _agendaTypeBadges(a) {
  const badges = [];
  const isKind = (k) => (Array.isArray(a.kinds) && a.kinds.includes(k)) || a.kind === k;
  if (isKind('discussion-file')) {
    // 按 id 解析本活动议程引用的草案（单条，非列表隔离面）：议程仅能引用同支部可选草案，
    // 故不存在跨支部泄漏；且为同步渲染路径（改异步需重构渲染链）。豁免 listDocs 接线，保持不过滤。
    const doc = (mockDB.branchDocs || []).find(d => d.id === a.branchDocId);
    const docLabel = doc ? (doc.title || doc.fileName || '未命名草案') : '（草案已删除）';
    badges.push(`<span class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium text-amber-700 bg-amber-50">讨论文件：${docLabel}</span>`);
    // SOP-B-13 第 4 项（D-305）：草案还在时给一条只读提示，不提供第二个材料库入口
    if (doc) {
      badges.push(`<span class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium text-gray-600 bg-gray-100" title="过程材料（试点意见 / 征求意见 / 修改说明）随草案归档，本处只作数量提示">已附材料 ${_draftMaterialCount(doc)} 件</span>`);
    }
  }
  // 品牌认定提案（2026-09-21 批次 132）：本议程项指向哪场活动被提案认定
  if (isKind('brand-designation')) {
    const target = (mockDB.activities || []).find(x => x.id === a.brandActivityId);
    const targetLabel = target ? (target.title || target.id) : '（活动已删除）';
    badges.push(`<span class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium text-amber-700 bg-amber-50">品牌认定：${esc(targetLabel)}</span>`);
  }
  if (isKind('attendee-list') || isKind('member-change')) {
    const personIds = Array.isArray(a.personIds) ? a.personIds : (a.personId ? [a.personId] : []);
    // S-2：只显示目标阶段（不再显示「从 X 到 Y」）
    const target = a.toStage ? ` · 转为${a.toStage}` : '';
    const label = personIds.length > 0
      ? `待讨论名单：${personIds.length} 名${target}`
      : `待讨论名单${target}`;
    badges.push(`<span class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium text-blue-700 bg-blue-50">${label}</span>`);
  }
  return badges.join('');
}

/** 议程结果记录（2026-09-01 支书点验链路 ②）：记录通过/未通过 → 归档草案/建成员变更申请 → 落库活动
 * outcome：字符串 'passed'/'rejected'（旧单值）或对象 { personResults }（S-1 逐人结果） */
async function _recordAgendaResult(activity, agendaItemId, outcome) {
  const actor = AuthStore.getCurrentUser();
  const adapter = getAdapter();
  const db = {
    branchDocs: [...(mockDB.branchDocs || [])],
    memberChangeRequests: [...(mockDB.memberChangeRequests || [])],
  };
  const payload = (outcome && typeof outcome === 'object') ? outcome : { result: outcome };
  const updated = await recordAgendaResultForActivity({
    activity,
    agendaItemId,
    ...payload,
    adapter,
    db,
    actorId: actor?.personId || null,
  });
  // 2026-09-01 代码审查修复（P1）：新创建的申请回写 mockDB（recordAgendaResult 只在局部 db 更新，
  // 不回写会导致 API 模式下本地查重失效、重复建申请）
  if (Array.isArray(db.memberChangeRequests) && db.memberChangeRequests.length > 0) {
    mockDB.memberChangeRequests = db.memberChangeRequests;
  }
  await BranchService.updateActivity(activity.id, { agenda: updated.agenda });
  return updated;
}

// ════════════════════════════════════════════════════════════════
//  委员/党员端表态面板（2026-09-01 线上支委会 Task3：支委角色可见；2026-09-02 AV4：选项集参数化）
//  未锁定 → 按活动 optionSet 渲染表态按钮（deliberative: 同意/异议/附言；formal: 赞成/反对/弃权）
//          + 附言输入框 + 提交（可覆盖表态）；
//  已表态 → 「已表态：…」；锁定后只读（标题带「已截止」，仅显示已表态记录）
//  文案/校验来自 vote-config.js OPTION_SETS（labels/options/objectRequiresNote），勿再本地硬编码
// ════════════════════════════════════════════════════════════════

// HTML 转义统一走 core/base/utils.js escHtml（2026-09-03 去重收口）

function renderVotePanel(container, { activity, agendaItem, votes, canVote, currentUserId }) {
  const locked = activity.votesLocked === true;
  const os = optionSetOf(activity);
  const labelOf = (pos) => (os.labels && os.labels[pos]) || pos;
  const options = (Array.isArray(os.options) && os.options.length > 0) ? os.options : OPTION_SETS.deliberative.options;
  // 无记名（2026-09-12 支书裁定）：本人选项不落库、回显不展示（只提示已计入汇总）；
  //   附言亦不落库，匿名态不提供附言输入（口径与公共端 vote-widget.js 一致）。
  const anonymous = isAnonymousActivity(activity);
  const mine = currentUserId
    ? (votes || []).find(v => v.personId === currentUserId && v.agendaItemId === agendaItem.id)
    : null;
  container.innerHTML = `
    <div class="vote-panel">
      <div class="vote-title">我的表态${locked ? '（已截止）' : ''}${anonymous ? '（无记名）' : ''}</div>
      ${mine ? (anonymous
        ? '<div class="vote-current">已表态（无记名，已计入汇总，不展示个人选项）</div>'
        : `<div class="vote-current">已表态：${esc(labelOf(mine.position))}${mine.note ? '（' + esc(mine.note) + '）' : ''}</div>`) : ''}
      ${!locked && canVote ? `
        <div class="vote-actions">
          ${options.map((pos) => `<button type="button" class="btn-outline vote-btn" data-pos="${pos}">${labelOf(pos)}</button>`).join('')}
        </div>
        ${anonymous ? '' : `<textarea class="vote-note" rows="2" placeholder="${os.objectRequiresNote ? '附言/异议说明（异议必填）' : '附言说明（选填）'}"></textarea>`}
        <button type="button" class="btn-outline btn-sm vote-submit">提交表态</button>` : ''}
    </div>`;

  container.querySelectorAll('.vote-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      container.querySelectorAll('.vote-btn').forEach(x => {
        x.classList.remove('active');
        x.setAttribute('aria-pressed', 'false');
      });
      btn.classList.add('active');
      btn.setAttribute('aria-pressed', 'true');
    });
  });

  const submitBtn = container.querySelector('.vote-submit');
  if (submitBtn) {
    submitBtn.addEventListener('click', async () => {
      const pos = container.querySelector('.vote-btn.active')?.dataset.pos;
      if (!pos) { showToast('error', `请先选择表态（${options.map((p) => labelOf(p)).join('/')}）`); return; }
      const note = container.querySelector('.vote-note')?.value.trim() || '';
      // 「异议须附言」由选项集 objectRequiresNote 控制（deliberative 适用；formal 附言选填不强制）
      if (os.objectRequiresNote && pos === 'object' && !note) { showToast('error', `${labelOf('object')}须附言说明`); return; }
      // P1 防连点：提交期间禁用按钮（异步落库期间重复点击会重复请求）
      if (submitBtn.dataset.processing === '1') return;
      submitBtn.dataset.processing = '1';
      submitBtn.disabled = true;
      submitBtn.style.opacity = '0.5';
      try {
        // 无记名不落附言（服务端亦丢弃）
        await submitVote({ activityId: activity.id, agendaItemId: agendaItem.id, position: pos, note: anonymous ? '' : note });
        showToast('success', anonymous ? '表态已提交（无记名）' : '表态已提交');
        // I2：仅重绘本议程表态区（其他议程已填草稿保留），detail 携带触发项 id
        container.dispatchEvent(new CustomEvent('vote-submitted', {
          bubbles: true,
          detail: { agendaItemId: agendaItem.id },
        }));
        // I1：成功路径恢复按钮（重绘为异步进行，若监听缺失/失败也不残留禁用态）
        submitBtn.dataset.processing = '';
        submitBtn.disabled = false;
        submitBtn.style.opacity = '';
      } catch (e) {
        console.warn('[inspector] 表态提交失败：', e);
        showToast('error', (e && e.message) || '表态提交失败');
        submitBtn.dataset.processing = '';
        submitBtn.disabled = false;
        submitBtn.style.opacity = '';
      }
    });
  }
}

function renderInspectorDetail(activity, tasks, managementRole) {
  const defEl     = document.getElementById('inspector-default');
  const contentEl = document.getElementById('inspector-content');
  const titleEl   = document.getElementById('inspector-date-title');
  const cardsEl   = document.getElementById('inspector-cards');
  if (!defEl || !contentEl) return;

  defEl.classList.add('hidden');
  contentEl.classList.remove('hidden');

  if (titleEl) titleEl.textContent = activity.title;

  // 确保 inspector 可见：滚动到视图中
  contentEl.closest('#inspector-container')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

  const visibleTasks = filterTasksByManagementRole(tasks, managementRole);
  const themeClass   = ROLE_THEME_CLASS[managementRole] || '';
  const isArchived   = activity.archived === true;
  const _user = AuthStore.getCurrentUser();
  const isSecretary = !!_user && SECRETARY_ROLES.includes(_user.role); // 支书专属（单一源 constants.js::SECRETARY_ROLES）——活动信息编辑等仍归支书；品牌认定已归支委层（见下方 isCommittee）
  // 支书/副支书可查看表态汇总（2026-09-01 线上支委会 Task4：支书端汇总矩阵+截止）
  const isSecretaryOrDeputy = !!_user && (_user.role === 'secretary' || _user.role === 'deputy-secretary');
  // 支委集合（支书/副支书/组织/宣传/纪检）→ 表态面板可见（AuthStore.isCommissioner 与 auth.js 授权语义一致）
  const isCommittee = !!_user && AuthStore.isCommissioner(_user.role);
  const currentUserId = _user?.personId || null;
  const isBrandActive = !!activity.isBrand;

  let html = '';

  html += '<button id="inspector-back-btn"'
    + ' class="btn-text  text-xs text-red-700 hover:text-red-900 mb-3'
    + ' flex items-center gap-1 transition-colors"'
    + ' style="background:none;border:none;cursor:pointer;padding:0;">'
    + '← 返回列表</button>';

  const mgrLabels = {
    'org-commissioner': '组织委员',
    'prop-commissioner': '宣传委员',
    'disc-commissioner': '纪检委员',
    secretary: '党支书',
    organizer: '组织者',
    deep: '深度参与者',
    leader: '党小组组长',
  };
  const mgrLabel = mgrLabels[managementRole] || managementRole;
  const mgrTheme = ROLE_THEME_CLASS[managementRole] || '';
  if (managementRole && managementRole !== 'participant') {
    html += `<div class="inspector-role-banner ${mgrTheme}"><span class="font-semibold">${mgrLabel}</span></div>`;
  }

  html += '<div class="flex items-center gap-1.5 flex-wrap mb-3">';
  // T229：顶部徽章走生命周期态（进度+产出共同驱动；已归档由生命周期态覆盖，不再单独渲染）
  html += activityLifecycleBadgeHtml(activity, tasks);
  if (activity.date) {
    html += `<span class=" text-xs text-gray-500">${activity.date}</span>`;
  }
  // 2026-10-01 批次 330（支书裁「加一枚跳转到活动详情页（推荐）」）：本面板**不写第二份「转交组织者」实现**，
  //   只给**支书台**一枚跳转——转交入口在活动详情页（`components/governance/organizer-transfer.js` 的宿主）。
  //   `<base href="../">`（`docs/workspace/*.html` 第 5 行）⇒ 渲染型路径须写 './activity.html'（L1 约定）。
  const detailHref = objectDetailHref('activity', activity.id, { entry: 'owner-workspace' });
  if (isSecretary && detailHref) {
    html += `<a class="link text-xs ml-auto flex-shrink-0" href="./${detailHref}" title="打开活动详情完整页（含「转交组织者」入口）">打开完整页 →</a>`;
  }
  html += '</div>';

  // ── 活动信息（复用写入时收集的详情字段：时间/地点/主持人/组织者/参与者/方向/维度/描述）──
  const infoRows = [];
  if (activity.time) infoRows.push({ label: '时间', value: activity.time });
  if (activity.location) infoRows.push({ label: '地点', value: activity.location });
  if (activity.host) infoRows.push({ label: '主持人', value: activity.host });
  if (activity.organizer) {
    const orgPerson = getPersonById(activity.organizer);
    if (orgPerson) infoRows.push({ label: '组织者', value: orgPerson.name });
  }
  let memberNames = [];
  if (Array.isArray(activity.participants)) {
    memberNames = activity.participants.filter(pid => pid !== activity.organizer).map(pid => getPersonById(pid)?.name).filter(Boolean);
  }
  if (memberNames.length === 0 && Array.isArray(activity.assignments)) {
    memberNames = activity.assignments.filter(a => a.role !== 'organizer').map(a => getPersonById(a.personId)?.name).filter(Boolean);
  }
  if (memberNames.length) infoRows.push({ label: '参与者', value: memberNames.join('、') });
  const directionVal = activity._dt_direction || activity.direction;
  if (directionVal) infoRows.push({ label: '发起方向', value: directionVal === 'top-down' ? '自上而下' : directionVal === 'bottom-up' ? '自下而上' : directionVal });
  const durationVal = activity._dt_duration;
  if (durationVal) infoRows.push({ label: '时长', value: durationVal === 'short' ? '短期' : durationVal === 'long' ? '长期' : durationVal });
  const dimParts = [];
  if (activity.isJoint !== undefined && activity.isJoint !== '') dimParts.push(activity.isJoint === 'true' || activity.isJoint === true ? '共建开展' : '独立开展');
  if (activity.isOutdoor !== undefined && activity.isOutdoor !== '') dimParts.push(activity.isOutdoor === 'true' || activity.isOutdoor === true ? '校外' : '校内');
  if (Array.isArray(activity.carriers) && activity.carriers.length) dimParts.push(activity.carriers.join('、'));
  if (dimParts.length) infoRows.push({ label: '活动维度', value: dimParts.join(' · ') });

  if (infoRows.length) {
    html += '<div class="mb-3 card rounded-xl p-4 space-y-1">';
    infoRows.forEach(r => {
      html += `<div class="flex items-start gap-2 text-xs"><span class="text-gray-500 flex-shrink-0 w-14">${r.label}</span><span class="text-gray-700">${r.value}</span></div>`;
    });
    html += '</div>';
  }
  if (activity.description) {
    html += `<div class="mb-3 card rounded-xl p-4"><p class="text-xs text-gray-500 mb-1">活动详情</p><p class="text-xs text-gray-700 leading-relaxed">${activity.description}</p></div>`;
  }

  // ── 会议议程（T-283：三会一课；显示 + 支书行内编辑；2026-09-01：类型徽章 + 结果记录）──
  // 副书同权（2026-09-10 修复）：议程编辑/结果记录对副支书放开——依据
  // content/02_institution/SYSTEM_ROLE_PERMISSION.md:142「副书同权」（支书/副支书共用支书工作台，
  // 见 constants.js ROLE_PAGE_MAP secretary→secretary.html）；仅此区块，范围不外扩。
  if (Array.isArray(activity.agenda) && activity.agenda.length > 0) {
    html += '<div class="mb-3 card rounded-xl p-4" id="agenda-block">';
    html += '<div class="flex items-center justify-between mb-1.5">';
    html += '<p class="text-xs text-gray-500">会议议程</p>';
    if (isSecretaryOrDeputy && !isArchived) {
      html += '<button id="inspector-agenda-edit-btn" class="btn-outline text-xs px-2.5 py-1">编辑议程</button>';
    }
    html += '</div>';
    html += '<ol class="space-y-1.5">';
    activity.agenda.forEach((a, i) => {
      const isDiscussionStep = a.agendaStep === 'discussion';
      const canRecord = isSecretaryOrDeputy && !isArchived && !isDiscussionStep && !a.result && !!a.id;
      const decisionSource = agendaDecisionSource(activity.agenda, a);
      const typeBadges = _agendaTypeBadges(decisionSource);
      const agendaStepBadge = a.agendaStep === 'discussion'
        ? '<span class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium text-indigo-700 bg-indigo-50">讨论项</span>'
        : (a.agendaStep === 'vote' ? '<span class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium text-rose-700 bg-rose-50">表决项</span>' : '');
      const relatedDiscussion = a.discussionAgendaItemId
        ? activity.agenda.find((item) => item.id === a.discussionAgendaItemId) : null;
      const stepNote = a.agendaStep === 'discussion'
        ? '讨论过程项；表态与决议结果记录在关联表决项'
        : (a.agendaStep === 'vote' ? `对应讨论：${esc(relatedDiscussion?.item || '议程关系无效')}` : '');
      const meta = AGENDA_RESULT_META[a.result];
      const resultBadge = meta
        ? `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium ${meta.cls}">${meta.label}</span>`
        : '';
      const recordInfo = a.recordedBy ? ` · 记录：${getPersonById(a.recordedBy)?.name || a.recordedBy}${a.recordedAt ? ' ' + String(a.recordedAt).slice(0, 10) : ''}` : '';
      // S-1：逐人结果议程（待讨论名单）→ 提供逐人「通过/未通过」勾选（未通过留痕 → 见下方只读留痕）
      const isKind = (k) => (Array.isArray(decisionSource.kinds) && decisionSource.kinds.includes(k)) || decisionSource.kind === k;
      const personIds = Array.isArray(decisionSource.personIds)
        ? decisionSource.personIds : (decisionSource.personId ? [decisionSource.personId] : []);
      const perPerson = (isKind('attendee-list') || isKind('member-change')) && personIds.length > 0;
      const perPersonTally = (Array.isArray(a.personResults) && a.personResults.length > 0)
        ? `<div class="text-xs text-gray-500 mt-0.5">${a.personResults.map(r =>
            `${esc(getPersonById(r.personId)?.name || r.personId)}：${r.passed ? '通过' : '未通过'}${r.note ? '（' + esc(r.note) + '）' : ''}`
          ).join('、')}</div>`
        : '';
      const personPanel = (canRecord && perPerson) ? `
        <div class="mt-1.5 rounded-lg border border-gray-100 bg-white p-2 space-y-1" data-agenda-person-results="${a.id}">
          <p class="text-xs text-gray-500">逐人结果（默认通过；取消勾选即未通过，可填备注）</p>
          ${personIds.map(pid => `
            <label class="flex items-center gap-1.5 text-xs">
              <input type="checkbox" class="ap-pass shrink-0" data-person-id="${esc(pid)}" checked style="cursor:pointer;">
              <span class="text-gray-700 w-14 shrink-0 truncate">${esc(getPersonById(pid)?.name || pid)}</span>
              <input type="text" class="ap-note input-flat flex-1 text-xs" data-person-id="${esc(pid)}" placeholder="备注（选填）">
            </label>`).join('')}
          <button type="button" class="btn-action-green ap-submit px-2.5 py-1 font-medium">记录结果</button>
        </div>` : '';
      html += `<li class="flex items-start gap-2 text-xs">
        <span class="text-gray-500 flex-shrink-0 w-4">${i + 1}.</span>
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-1.5 flex-wrap">
            <span class="text-gray-700">${a.item}</span>
            ${agendaStepBadge}
            ${typeBadges}
            ${resultBadge}
          </div>
          <div class="text-gray-500 mt-0.5">${a.host ? `（主持人：${a.host}）` : ''}${stepNote ? ` · ${stepNote}` : ''}${recordInfo}${a.reportToPartyMeeting ? ' · 已定：报送党员大会表决' : ''}</div>${_reportPartyToggleHtml(a, canRecord, decisionSource)}
          ${perPersonTally}
          ${!isDiscussionStep && isVoterOf(activity, currentUserId) && a.id ? `<div class="vote-panel-slot" data-vote-agenda-id="${a.id}"></div>` : ''}
          ${personPanel}
        </div>
        ${canRecord && !perPerson ? `
          <div class="flex gap-1 shrink-0">
            <button type="button" data-agenda-result="passed" data-agenda-item-id="${a.id}" class="btn-action-green inspector-agenda-result px-2 py-0.5 font-medium">通过</button>
            <button type="button" data-agenda-result="rejected" data-agenda-item-id="${a.id}" class="btn-outline inspector-agenda-result px-2 py-0.5">未通过</button>
          </div>` : ''}
      </li>`;
    });
    html += '</ol>';
    html += '</div>';
  }

  // ── 表态汇总（2026-09-01 线上支委会 Task4：支书/副支书专属，议程区下方） ──
  if (isSecretaryOrDeputy && Array.isArray(activity.agenda) && activity.agenda.length > 0) {
    html += '<div id="vote-summary-slot" class="mb-3"></div>';
  }

  // ── 产出物区（T-224 §8 附件查看窗口：同源读取，点击展开预览） ──
  html += _buildOutputsSectionHTML(activity);

  if (visibleTasks.length > 0) {
    // 2026-08-10 支书裁定（设计原则 11）：进度指标只显未完成类——「已完成 N/总数」无信息增量，
    // 仅保留待完成数（>0 时有提示价值；全部完成时无未完成=无需提示，不渲染）。
    const pendingCount = visibleTasks.filter(t => t.status !== 'completed').length;
    if (pendingCount > 0) {
      html += `<p class=" text-xs text-gray-500 mb-3">待完成 ${pendingCount} 项</p>`;
    }
  }

  if (visibleTasks.length > 0) {
    visibleTasks.forEach(t => {
      const cardClass = themeClass ? `inspector-card ${themeClass}` : 'inspector-card';
      html += `<div class="${cardClass}">`;
      html += `<div class="flex items-start justify-between gap-2 mb-1">`;
      html += `<p class=" font-bold text-sm leading-snug flex-1">${t.title}</p>`;
      // T-217 §2.4：任务状态由行内 select 改为 status-badge（色点+文字+悬浮选择器）
      html += statusBadgeHtml(t.status, {
        statuses: TASK_STATUSES,
        disabled: isArchived,
        attrs: `data-task-id="${t.id}"`,
      });
      // 任务「作废」：支委层直接生效，其余人报支委会确认；作废后不再计入进度，可在归档中回查。
      if (!isArchived) {
        html += `<button class="btn-action btn-action-gray task-void-btn" data-task-id="${t.id}" title="作废后不再计入进度，可在归档中回查">作废</button>`;
      }
      html += '</div>';
      html += '</div>';
    });
  } else if (tasks.length > 0) {
    html += emptyStateHtml({ text: "该角色在此活动中暂无专属任务节点", variant: 'panel' });
  } else {
    html += emptyStateHtml({ text: "暂无关联任务", variant: 'inline' });
  }

  // 品牌认定（2026-09-21 批次 132 · 支书口径二「支委/党小组组长均可以提案，支委会……通过后确定」）：
  //   **不再有「点一下即认定」**——提案权＝支委层 ＋ 党小组组长；确定权＝支委会（议程项「记录结果」通过）。
  //   本处按状态渲染三态：已认定（支委层可取消，留痕） / 已提案待审议（提案人或支委层可撤回） / 未提案（可提案）。
  const brandProposal = brandProposalOf(activity);
  if ((isCommittee || canProposeBrand(_user?.role)) && !isArchived) {
    html += '<div class="mt-3 flex items-center gap-2 flex-wrap">';
    if (isBrandActive) {
      html += `<span class=" text-xs text-gray-500">本场已由支委会认定为品牌活动${activity.brandDesignatedAt ? `（${String(activity.brandDesignatedAt).slice(0, 10)}）` : ''}</span>`;
      if (isCommittee) html += `<button id="inspector-brand-revoke-btn" class="tint-action text-xs px-3 py-1.5 inline-flex items-center gap-1" data-tone="gold">${icon('starFilled', { className: 'w-3 h-3' })} 取消品牌认定</button>`;
    } else if (brandProposal) {
      const proposerName = brandProposal.by ? (getPersonName(brandProposal.by) || brandProposal.by) : '—';
      html += `<span class=" text-xs text-gray-500">品牌认定提案待支委会审议（提案人 ${esc(brandProposal.by ? proposerName : '—')}${brandProposal.reviewResult === 'rejected' ? ' · 上次未通过' : ''}）</span>`;
      if (isCommittee || brandProposal.by === _user?.personId) html += `<button id="inspector-brand-withdraw-btn" class="tint-action text-xs px-3 py-1.5 inline-flex items-center gap-1" data-tone="gold">撤回提案</button>`;
    } else if (canProposeBrand(_user?.role)) {
      html += `<button id="inspector-brand-propose-btn" class="tint-action text-xs px-3 py-1.5 inline-flex items-center gap-1" data-tone="gold">${icon('starOutline', { className: 'w-3 h-3' })} 提议认定为品牌活动</button>`;
      html += '<span class=" text-xs text-gray-500">提案后进支委会「拟上会」清单，通过后才认定</span>';
    }
    html += '</div>';
  }

  // 活动批准门（2026-09-22 批次 150 / 批次 151 · 支书裁定「做成可开关的制度参数（默认关）」＋「支委会档复用
  // 已有的线上表决」）：仅在该活动的待批态渲染；放行者按**当前档位**判定（判据单一源在 services/activity/activity.js）。
  // 两档行为**不同**：支书档＝点一下即批 / 不批准即终止；支委会档＝**提请支委会表决**（不直接改状态），
  // 表决通过才发布、未通过则终止（承载＝本活动上那条 `activity-approval` 议程项 ＋ 既有线上表决配置）。
  // 关闭（默认）时任何活动都不会是待批态 ⇒ 本块永不渲染（零行为变化）。
  if (activity.status === PENDING_APPROVAL_STATUS && !isArchived) {
    const aprMode = activityApprovalMode();
    const aprModeLabel = ACTIVITY_APPROVAL_MODE_LABELS[aprMode] || aprMode; // 档位标签单一源（policy-defaults；2026-09-22 批次 150）
    html += '<div class="mt-3 flex items-center gap-2 flex-wrap">';
    html += `<span class=" text-xs text-gray-500">待批（档位：${esc(aprModeLabel)}）——批准前不推进；不批准则终止</span>`;
    if (canApproveActivity(_user?.role, aprMode)) {
      if (aprMode === 'branch-committee') {
        const aprVote = activityApprovalVoteOf(activity);
        if (!aprVote) {
          html += '<button id="inspector-committee-vote-btn" class="tint-action text-xs px-3 py-1.5 inline-flex items-center gap-1" data-tone="success">提请支委会表决</button>';
          html += '<span class=" text-xs text-gray-500">提请后由支委层在本场表态；记录「通过」才发布</span>';
        } else {
          html += `<span class=" text-xs text-gray-500">已提请支委会表决（${aprVote.decided ? '已记录结果' : '待支委表态'}）——在本场议程「审议活动…的批准」处表态 / 记录结果</span>`;
        }
      } else {
        html += '<button id="inspector-approve-btn" class="tint-action text-xs px-3 py-1.5 inline-flex items-center gap-1" data-tone="success">批准发布</button>';
        html += '<button id="inspector-reject-btn" class="btn-danger text-xs px-3 py-1.5 inline-flex items-center gap-1">不批准（终止）</button>';
      }
    }
    html += '</div>';
  }

  html += '<div class="flex gap-2 mt-4 pt-3 border-t border-gray-100">';
  if (isSecretary && !isArchived) {
    // B 档 CRUD 补全：活动信息编辑（支书持有 create_activity，含编辑权）——本屏唯一主行动。
    html += '<button id="inspector-edit-btn"'
      + ' class="tint-action text-xs px-3 py-1.5" data-tone="info">编辑信息</button>';
  }
  // 2026-10-28 阶段三（A2 主行动唯一）：归档 / 删除保持三枚按钮同排（支书裁定「有空间摊开可以」），
  //   但降为次行动视觉权重（`tint-action--secondary`：透明底 + 中性描边）；语义色只在 hover 回到 tone，
  //   危险色不与「编辑信息」同权重。危险动作的确认面由 confirmDanger 承担，按钮本身不删。
  if (isArchived) {
    html += '<button id="inspector-restore-btn"'
      + ' class="tint-action text-xs px-3 py-1.5" data-tone="success">恢复活动</button>';
  } else {
    html += '<button id="inspector-archive-btn"'
      + ' class="tint-action tint-action--secondary text-xs px-3 py-1.5" data-tone="warning">归档活动</button>';
  }
  html += '<button id="inspector-delete-btn"'
    + ' class="tint-action tint-action--secondary text-xs px-3 py-1.5" data-tone="danger">删除活动</button>';
  html += '</div>';

  if (!cardsEl) return;
  cardsEl.innerHTML = html;

  // 委员/党员端表态面板（2026-09-01 线上支委会 Task3）
  // 加载后 fetchVotes → 逐条议程渲染表态区；vote-submitted 冒泡刷新（重新拉取重绘，支持覆盖表态）。
  // 监听挂在 #agenda-block 上（每次内渲染重建，闭包捕获本次 activity，避免跨活动串态）。
  // 批次 312 收口：门由 `isCommittee` 改为 `canVote`（＝`isVoterOf`，角色无关）——否则应到名单内的
  //   普通党员在支书台只挂得出空槽（批次 304 只改了 slot、漏了这里）。
  const canVote = isVoterOf(activity, currentUserId);
  if (canVote) {
    const actId = activity.id;
    const renderAllVotePanels = async () => {
      const votes = await fetchVotes(actId);
      cardsEl.querySelectorAll('.vote-panel-slot').forEach(slot => {
        const agendaItem = (activity.agenda || []).find(a => a.id === slot.dataset.voteAgendaId);
        if (agendaItem) renderVotePanel(slot, { activity, agendaItem, votes, canVote, currentUserId });
      });
    };
    renderAllVotePanels().catch(e => console.warn('[inspector] 表态数据加载失败：', e));
    const agendaBlock = cardsEl.querySelector('#agenda-block');
    if (agendaBlock) {
      agendaBlock.addEventListener('vote-submitted', () => {
        renderAllVotePanels().catch(e => console.warn('[inspector] 表态刷新失败：', e));
      });
    }
  }

  // 支书端表态汇总（2026-09-01 线上支委会 Task4：支书/副支书可见）
  // 加载后 fetchVotes → 汇总矩阵；votes-locked 冒泡 → 提示记录决议 + setState 刷新锁定态
  // 矩阵名单 = 活动投票成员：有 voteConfig.voterIds（创建时固化应到名单）→ 按名单映射人员（AV4 泛化，
  //   支部党员大会/支委会通用）；无 voteConfig（旧活动/线下）→ 回退权威支委名单 resolveVoterIds('committee')
  //   （vote-config.js：people.js role + isCommissioner、排除 u_*）。再映射回 PersonStore 人员对象
  //   （渲染需姓名/角色；名单顺序仍以 PersonStore 原序为准，勿自行重写过滤口径）
  // canLock：支书/副支书同权（2026-09-11 副书同权裁定 + 2026-09-13 dogfood 权限专项修正——
  //   此前仅支书为 true，导致副支书看得到表态汇总却**无截止按钮且无任何提示**；
  //   server 端已同源改为 requireRole(SECRETARY_AND_DEPUTY_ROLES)）
  if (isSecretaryOrDeputy && Array.isArray(activity.agenda) && activity.agenda.length > 0) {
    const vsSlot = cardsEl.querySelector('#vote-summary-slot');
    if (vsSlot) {
      const cfgIds = (Array.isArray(activity.voteConfig?.voterIds) && activity.voteConfig.voterIds.length > 0)
        ? activity.voteConfig.voterIds
        : resolveVoterIds('committee');
      const memberIds = new Set(cfgIds);
      const committeeMembers = PersonStore.getAll().filter((p) => memberIds.has(p.id));
      renderVoteSummary(vsSlot, { activity, committeeMembers, canLock: true })
        .catch(e => console.warn('[inspector] 表态汇总加载失败：', e));
      vsSlot.addEventListener('votes-locked', () => {
        showToast('success', '表态已截止，请记录决议');
        // lockVotes 已落库（mock 直写 mockDB / API 写服务器）。setState 触发全局重建，
        // 重建后 renderVoteSummary 重新 fetchVotes 渲染「已截止」态。
        // latest 本地构造为即时反馈：保证 API 模式下重绘时 activity.votesLocked 立即为 true
        // （服务器锁定态尚未同步回本地 state，不能只依赖 mockDB）。
        const latest = { ...activity, votesLocked: true };
        setState({ activities: getAppState().activities.map(a => (a.id === activity.id ? latest : a)) });
      });
    }
  }

  // 会议议程编辑入口（T-283：支书行内编辑，保存→persist→重渲染）
  const agendaEditBtn = document.getElementById('inspector-agenda-edit-btn');
  if (agendaEditBtn) {
    agendaEditBtn.addEventListener('click', () => {
      _startAgendaEdit(activity, cardsEl, tasks, managementRole);
    });
  }

  // 议程结果记录（2026-09-01 支书点验链路 ②：通过/未通过 → 归档草案/建成员变更申请 → 重渲染）
  // P1 防连点：点击后禁用按钮（async 落库期间重复点击会重复建申请）
  cardsEl.querySelectorAll('.inspector-agenda-result').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (btn.dataset.processing === '1') return;
      btn.dataset.processing = '1';
      btn.disabled = true;
      btn.style.opacity = '0.5';
      try {
        const result = btn.dataset.agendaResult;
        const itemId = btn.dataset.agendaItemId;
        // 制度链（2026-09-21 批次 129）：制度草案议程项旁若勾了「报送党员大会表决」则一并落库
        // （无该勾选位的议程项 → false，与既有行为一致）
        const reportFlag = cardsEl.querySelector(`.ap-report-party[data-agenda-item-id="${itemId}"]`)?.checked === true;
        await _recordAgendaResult(activity, itemId, { result, reportToPartyMeeting: reportFlag });
        showToast('success', result === 'passed'
          ? (reportFlag ? '已记录通过（报送党员大会表决）' : '已记录通过')
          : '已记录未通过');
        // 同步全局 state（mockDB 已更新，state.activities 是旧副本 → 不刷新则详情不即时更新）
        setState({ activities: [...mockDB.activities] });
        renderInspectorFromState();
      } catch (e) {
        console.warn('[inspector] 议程结果记录失败：', e);
        showToast('error', e.message || '记录失败');
        btn.dataset.processing = '';
        btn.disabled = false;
        btn.style.opacity = '';
      }
    });
  });

  // 议程逐人结果记录（S-1 2026-09-09 支书批：待讨论名单逐人「通过/未通过」+ 备注 → 通过者自动派生成员变更申请）
  // P1 防连点：提交期间禁用按钮
  cardsEl.querySelectorAll('[data-agenda-person-results]').forEach(box => {
    const submit = box.querySelector('.ap-submit');
    if (!submit) return;
    submit.addEventListener('click', async () => {
      if (submit.dataset.processing === '1') return;
      const personResults = [...box.querySelectorAll('.ap-pass')].map(cb => {
        const pid = cb.dataset.personId;
        const note = box.querySelector(`.ap-note[data-person-id="${pid}"]`)?.value?.trim() || '';
        return { personId: pid, passed: cb.checked, note };
      });
      submit.dataset.processing = '1';
      submit.disabled = true;
      submit.style.opacity = '0.5';
      try {
        await _recordAgendaResult(activity, box.dataset.agendaPersonResults, { personResults });
        const passedN = personResults.filter(r => r.passed).length;
        showToast('success', passedN === personResults.length
          ? '已记录通过'
          : passedN === 0 ? '已记录未通过' : `已记录：${passedN} 人通过`);
        setState({ activities: [...mockDB.activities] });
        renderInspectorFromState();
      } catch (e) {
        console.warn('[inspector] 议程逐人结果记录失败：', e);
        showToast('error', e.message || '记录失败');
        submit.dataset.processing = '';
        submit.disabled = false;
        submit.style.opacity = '';
      }
    });
  });

  // B 档 CRUD 补全：活动信息编辑入口（支书专属）
  const editBtn = document.getElementById('inspector-edit-btn');
  if (editBtn) {
    editBtn.addEventListener('click', () => {
      _openActivityEditModal(activity, tasks, managementRole);
    });
  }

  // D 档文件闭环：产出物区材料下载（mock base64 直下 / server 带鉴权拉取）
  cardsEl.querySelectorAll('.insp-pub-dl').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const rec = (mockDB.archiveRecords || []).find(r => r.id === btn.dataset.arcId);
      if (!rec) { showToast('error', '材料记录不存在'); return; }
      const ok = await _downloadMaterialRecord(rec);
      showToast(ok ? 'success' : 'error', ok ? `「${rec.fileName || '材料'}」已下载` : '材料下载失败');
    });
  });

  if (!isArchived) {
    cardsEl.querySelectorAll('[data-status-badge]').forEach(badge => {
      bindStatusBadge(badge, {
        statuses: TASK_STATUSES,
        onChange: async (newStatus) => {
          const taskId = badge.dataset.taskId;
          const newTasks = BranchService.updateTask(taskId, { status: newStatus });
          // T-218：进度驱动活动状态——任务变更后重算活动执行态并落库
          // （BranchService 直写路径仅 saveDB() 本地，必须显式 persist() 写穿服务器）
          const newActStatus = deriveActivityExecutionStatus(activity, newTasks);
          if (newActStatus !== activity.status) {
            await BranchService.updateActivity(activity.id, { status: newActStatus });
          }
          setState({
            tasks: newTasks,
            activities: getAppState().activities.map(a => (a.id === activity.id ? { ...a, status: newActStatus } : a)),
          });
          persist();
        },
      });
    });
  }

  // 任务「作废」：支委层直接生效，其余人报支委会确认（统一走 components/ui/void-record.js）；
  //   作废后任务不再计入进度，活动执行态随之重算。
  if (!isArchived) {
    cardsEl.querySelectorAll('.task-void-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const t = ((getAppState() || {}).tasks || []).find(x => x.id === btn.dataset.taskId);
        openVoidModal({
          resource: 'tasks', id: btn.dataset.taskId, label: '任务',
          subject: (t && t.title) || btn.dataset.taskId,
          onDone: async () => {
            const reloaded = await BranchService.listTasks();
            const newActStatus = deriveActivityExecutionStatus(activity, reloaded);
            if (newActStatus !== activity.status) {
              await BranchService.updateActivity(activity.id, { status: newActStatus });
            }
            setState({
              tasks: reloaded,
              activities: getAppState().activities.map(a => (a.id === activity.id ? { ...a, status: newActStatus } : a)),
            });
            persist();
          },
        });
      });
    });
  }

  // 品牌认定三动作（2026-09-21 批次 132 · 支书口径二）：**认定只能由支委会审议通过产生**，故本处只有
  //   ① 提案（支委层 / 党小组组长）② 撤回提案（提案人或支委层）③ 取消已有认定（支委层，留痕）。
  //   放行判据在服务层各函数内复算一次（点了没反应＝按钮没渲染出来，属「漏挂」类问题，不静默）。
  const reloadAfterBrandWrite = async () => {
    const activities = await BranchService.listActivities();
    setState({ status: STATE.IDLE, activities });
  };
  const brandProposeBtn = document.getElementById('inspector-brand-propose-btn');
  if (brandProposeBtn) {
    brandProposeBtn.addEventListener('click', async () => {
      if (!await confirmDanger({ id: 'brand-propose', title: '提交品牌认定提案', bodyHtml: '<p class="text-sm text-gray-700">把本场活动列为品牌认定候选。<br>影响：进入支委会「拟上会」清单，不改活动状态与展示。<br>可恢复：可随时撤回提案。</p>', confirmLabel: '提交提案' })) return;
      const res = proposeBrandDesignation({ activityId: activity.id, by: currentUserId, role: _user?.role });
      if (!res.ok) { showToast('error', res.reason || '提案失败'); return; }
      showToast('success', '已提交品牌认定提案（进支委会「拟上会」清单）');
      await reloadAfterBrandWrite();
    });
  }
  const brandWithdrawBtn = document.getElementById('inspector-brand-withdraw-btn');
  if (brandWithdrawBtn) {
    brandWithdrawBtn.addEventListener('click', async () => {
      if (!await confirmDanger({ id: 'brand-withdraw', title: '撤回品牌认定提案', bodyHtml: '<p class="text-sm text-gray-700">撤回本场已提交的品牌认定提案。<br>影响：本场退出支委会「拟上会」清单，活动本身不变。<br>可恢复：可重新提交提案。</p>', confirmLabel: '撤回' })) return;
      const res = withdrawBrandProposal({ activityId: activity.id, by: currentUserId, role: _user?.role });
      if (!res.ok) { showToast('error', res.reason || '撤回失败'); return; }
      showToast('success', '已撤回品牌认定提案');
      await reloadAfterBrandWrite();
    });
  }
  const brandRevokeBtn = document.getElementById('inspector-brand-revoke-btn');
  if (brandRevokeBtn) {
    brandRevokeBtn.addEventListener('click', async () => {
      if (!await confirmDanger({ id: 'brand-revoke', title: '取消品牌认定', bodyHtml: '<p class="text-sm text-gray-700">取消本场活动的品牌认定。<br>影响：本场不再显示品牌标签，退出首页「活动风采」的品牌展示；取消人与时间记入留痕。<br>可恢复：重新认定仍须支委会审议通过。</p>', confirmLabel: '取消认定' })) return;
      const res = revokeBrandDesignation({ activityId: activity.id, by: currentUserId, role: _user?.role });
      if (!res.ok) { showToast('error', res.reason || '取消失败'); return; }
      showToast('success', '已取消品牌认定');
      await reloadAfterBrandWrite();
    });
  }

  // 活动批准门·支委会档（2026-09-22 批次 151 · 支书裁定「复用线上表决」）：提请支委会表决 —— 只在本活动上挂
  // 一条 `activity-approval` 议程项 ＋ 支委会档线上表决配置（**不改状态**）；支委层在本场表态、支书记录结果后
  // 才发布/终止。放行判据在服务层复算一次（点了没反应＝按钮没渲染出来，属「漏挂」类问题，不静默）。
  const committeeVoteBtn = document.getElementById('inspector-committee-vote-btn');
  if (committeeVoteBtn) {
    committeeVoteBtn.addEventListener('click', async () => {
      if (!await confirmDanger({ id: 'committee-vote', title: '提请支委会表决', bodyHtml: '<p class="text-sm text-gray-700">把本场活动提交支委会表决。<br>影响：本场挂一条表决议程项，由支委层在本场表态；记录「通过」才发布，未通过则终止。<br><b>不可恢复</b>：提请后不能撤回，须待支委会记录结果。</p>', confirmLabel: '提请表决' })) return;
      committeeVoteBtn.disabled = true;
      const res = await openCommitteeVoteForActivity({ activityId: activity.id, by: currentUserId, role: _user?.role, mode: activityApprovalMode() });
      if (!res.ok) { showToast('error', res.reason || '提请表决失败'); committeeVoteBtn.disabled = false; return; }
      showToast('success', res.already ? '本场已提请支委会表决（未重复挂）' : '已提请支委会表决——请支委层在本场表态');
      await reloadAfterBrandWrite();
    });
  }

  // 活动批准门两动作（2026-09-22 批次 150，仅支书档）：批准 ⇒ 已发布；不批准 ⇒ 终止（已取消，留退回意见）。
  // 放行判据在服务层复算一次（点了没反应＝按钮没渲染出来，属「漏挂」类问题，不静默）。
  const approveBtn = document.getElementById('inspector-approve-btn');
  if (approveBtn) {
    approveBtn.addEventListener('click', async () => {
      if (!await confirmDanger({ id: 'activity-approve', title: '批准并发布活动', bodyHtml: '<p class="text-sm text-gray-700">批准本场活动并立即发布。<br>影响：全支部可见，相关任务与通知按既有流程推进。<br><b>不可恢复</b>：发布后不能撤回。</p>', confirmLabel: '批准发布' })) return;
      const res = approveActivity({ activityId: activity.id, by: currentUserId, role: _user?.role, mode: activityApprovalMode() });
      if (!res.ok) { showToast('error', res.reason || '批准失败'); return; }
      showToast('success', '已批准发布');
      await reloadAfterBrandWrite();
    });
  }
  const rejectBtn = document.getElementById('inspector-reject-btn');
  if (rejectBtn) {
    rejectBtn.addEventListener('click', async () => {
      const note = window.prompt('不批准该活动：本场将终止（不再发布，关联任务停止推进），终止后不能恢复。可填写退回意见：', '');
      if (note === null) return;
      const res = rejectActivity({ activityId: activity.id, by: currentUserId, role: _user?.role, mode: activityApprovalMode(), note });
      if (!res.ok) { showToast('error', res.reason || '驳回失败'); return; }
      showToast('success', '未批准，该活动已终止（已取消）');
      await reloadAfterBrandWrite();
    });
  }

  const backBtn = document.getElementById('inspector-back-btn');
  if (backBtn) {
    backBtn.addEventListener('click', () => {
      setState({ viewMode: 'list', selectedActivityId: null });
    });
  }

  const restoreBtn = document.getElementById('inspector-restore-btn');
  if (restoreBtn) {
    restoreBtn.addEventListener('click', async () => {
      if (!await confirmDanger({ id: 'activity-restore', title: '恢复至主视图', bodyHtml: '<p class="text-sm text-gray-700">把本场活动从「已归档」恢复到主视图。<br>影响：本场重新出现在活动列表与工作区；归档记录与材料保留。<br>可恢复：可再次归档。</p>', confirmLabel: '恢复' })) return;
      try {
        setState({ status: STATE.SUBMITTING });
        await BranchService.updateActivity(activity.id, { archived: false });
        persist(); // 扎口修复（Z1/Z3）：updateActivity 内部不落盘，必须显式 persist 写穿
        const [activities, tasks2] = await Promise.all([
          BranchService.listActivities(),
          typeof BranchService.listTasks === 'function' ? BranchService.listTasks() : Promise.resolve([]),
        ]);
        setState({ status: STATE.IDLE, activities, tasks: tasks2, viewMode: 'list', selectedActivityId: null, viewArchived: false });
        showToast('success', '活动已恢复，可在主视图中查看。');
      } catch (err) {
        setState({ status: STATE.ERROR, error: err });
        showToast('error', (err && err.message) ? err.message : '恢复失败，请稍后重试。');
      }
    });
  }

  const archiveBtn = document.getElementById('inspector-archive-btn');
  if (archiveBtn) {
    archiveBtn.addEventListener('click', async () => {
      // T-224 §7 分类型关闭条件：产出缺失阻塞归档，缺失项明确显示
      const { canClose, missing } = checkActivityCloseConditions(activity);
      if (!canClose) {
        _showCloseBlockModal(activity, missing);
        return;
      }
      if (!await confirmDanger({ id: 'activity-archive', title: '归档活动', bodyHtml: '<p class="text-sm text-gray-700">把本场活动归档。<br>影响：从主视图消失，本场任务与材料转为只读，关联「待归档」待办销项。<br>可恢复：可在「已归档」中回查并恢复至主视图。</p>', confirmLabel: '归档' })) return;
      try {
        setState({ status: STATE.SUBMITTING });
        await BranchService.archiveActivity(activity.id);
        const [activities, tasks2] = await Promise.all([
          BranchService.listActivities(),
          typeof BranchService.listTasks === 'function' ? BranchService.listTasks() : Promise.resolve([]),
        ]);
        setState({ status: STATE.IDLE, activities, tasks: tasks2, viewMode: 'list', selectedActivityId: null });
        showToast('success', '活动已归档。');
      } catch (err) {
        setState({ status: STATE.ERROR, error: err });
        showToast('error', (err && err.message) ? err.message : '归档失败，请稍后重试。');
      }
    });
  }

  const deleteBtn = document.getElementById('inspector-delete-btn');
  if (deleteBtn) {
    deleteBtn.addEventListener('click', async () => {
      if (!await confirmDanger({ id: 'activity-delete', title: '彻底删除活动', bodyHtml: '<p class="text-sm text-gray-700">删除本场活动。<br>影响：活动及其关联数据（任务 / 材料 / 考勤 / 考察 / 报名）一并删除，不再出现在任何列表。<br><b>不可恢复</b>。</p>', confirmLabel: '彻底删除' })) return;
      try {
        setState({ status: STATE.SUBMITTING });
        await BranchService.deleteActivity(activity.id);
        const [activities, tasks2] = await Promise.all([
          BranchService.listActivities(),
          typeof BranchService.listTasks === 'function' ? BranchService.listTasks() : Promise.resolve([]),
        ]);
        setState({ status: STATE.IDLE, activities, tasks: tasks2, viewMode: 'list', selectedActivityId: null });
        showToast('success', '活动已删除。');
      } catch (err) {
        setState({ status: STATE.ERROR, error: err });
        showToast('error', (err && err.message) ? err.message : '删除失败，请稍后重试。');
      }
    });
  }
}

// ════════════════════════════════════════════════════════════════
//  会议议程行内编辑（T-283：三会一课；支书修改议程，保存→persist→重渲染）
//  数据安全（2026-09-06 点验结论）：编辑仅覆盖每行议程项的 item/host 文本，
//  完整原对象（id/kinds/branchDocId/personIds/fromStage/toStage/result/recordedBy/recordedAt）
//  按原 index 随行保留——保存时 {...原对象, item, host} 重建，杜绝清空结构化配置、
//  抹掉已记录结果、丢失 item.id 使 agendaVotes 关联失效（票成孤儿/记录按钮失效）。
//  投影/规范化纯函数复用 services/activity/agenda-editing.js（原为死代码，本次接线激活）。
// ════════════════════════════════════════════════════════════════
function _startAgendaEdit(activity, cardsEl, tasks, managementRole) {
  const block = cardsEl.querySelector('#agenda-block');
  if (!block) return;
  // 编辑态行数据 = 议程项完整对象（createEditableAgenda 整对象投影，保留 id/扩展字段/结果字段），
  // DOM 行顺序恒等于本数组 index：删除=splice 真删该对象；新增=push 新对象。
  const current = createEditableAgenda(Array.isArray(activity.agenda) ? activity.agenda : []);

  // 该行是否含结构化扩展配置（讨论文件/待讨论名单，含旧单值 kind/personId 兼容）：
  // 是 → 编辑只改文本，配置与已记录结果原样保留（渲染只读提示，不提供配置编辑入口）
  const _hasStructuredCfg = (a) => !!(a && (
    (Array.isArray(a.kinds) && a.kinds.length > 0)
    || (Array.isArray(a.personIds) && a.personIds.length > 0)
    || a.branchDocId || a.kind || a.personId || a.fromStage || a.toStage
  ));
  const _hasAgendaStep = (a) => !!(a && (a.agendaStep || a.discussionAgendaItemId));

  const renderEditor = () => {
    let html = '<div class="flex items-center justify-between mb-1.5"><p class="text-xs text-gray-500">编辑会议议程</p></div>';
    html += '<div id="agenda-edit-list" class="space-y-1.5"></div>';
    html += '<div class="flex items-center gap-2 mt-2">';
    html += '<button id="agenda-edit-add" class="btn-outline text-xs px-2.5 py-1">+ 添加议程</button>';
    html += '<button id="agenda-edit-save" class="btn-accent text-xs px-3 py-1 font-medium">保存</button>';
    html += '<button id="agenda-edit-cancel" class="btn-outline btn-sm">取消</button>';
    html += '</div>';
    block.innerHTML = html;

    const list = block.querySelector('#agenda-edit-list');
    // DOM → current 同步：重建/保存前读回已输入文本（仅覆盖 item/host，扩展字段不动，
    // 防添加/删除重建时丢失未保存的输入——T-283 判例）
    const syncFromDom = () => {
      const rows = [...list.children].filter(c => c.classList.contains('agenda-edit-row'));
      rows.forEach((row, i) => {
        if (current[i]) {
          current[i].item = row.querySelector('.agenda-edit-item')?.value || '';
          current[i].host = row.querySelector('.agenda-edit-host')?.value || '';
        }
      });
    };
    const refreshRows = () => {
      syncFromDom();
      if (current.length === 0) {
        list.innerHTML = emptyStateHtml({ text: "暂无议程，点击「添加议程」填写", variant: 'inline' });
        return;
      }
      // 行模板仅编辑 item/host 文本；含讨论文件/待讨论名单配置的行在输入区下方给只读提示
      list.innerHTML = current.map((a) => `
        <div class="agenda-edit-row">
          <div class="flex items-center gap-1.5">
            <input type="text" class="agenda-edit-item input-flat w-full text-xs" value="${a.item}" placeholder="议题">
            <input type="text" class="agenda-edit-host input-flat w-24 text-xs" value="${a.host}" placeholder="主持人">
            <button type="button" class="btn-danger btn-icon agenda-edit-del shrink-0" aria-label="删除该议程" title="删除该议程（连同其讨论文件/待讨论名单配置）">✕</button>
          </div>
          ${_hasStructuredCfg(a) || _hasAgendaStep(a) ? `<div class="agenda-edit-ext text-xs text-amber-700 pl-1 mt-0.5 leading-snug" title="议程业务配置、步骤关系及已记录结果将原样保留，本次仅可修改议题/主持人文本">${_hasAgendaStep(a) ? (a.agendaStep === 'discussion' ? '讨论项' : '表决项及其关联') : '讨论文件/待讨论名单配置'}将原样保留</div>` : ''}
        </div>`).join('');
      list.querySelectorAll('.agenda-edit-del').forEach((btn) => {
        btn.addEventListener('click', () => {
          const row = btn.closest('.agenda-edit-row');
          const idx = [...list.children].indexOf(row);
          if (idx > -1) current.splice(idx, 1); // 真删该项：id/扩展字段/已记录结果一并移除
          refreshRows();
        });
      });
    };
    refreshRows();

    block.querySelector('#agenda-edit-add').addEventListener('click', () => {
      current.push({ item: '', host: '' }); // 新增普通文本行（无原项可保留，保持既有无 id 语义）
      refreshRows();
      list.lastElementChild?.querySelector('.agenda-edit-item')?.focus();
    });
    block.querySelector('#agenda-edit-cancel').addEventListener('click', () => {
      renderInspectorDetail(activity, tasks, managementRole);
    });
    block.querySelector('#agenda-edit-save').addEventListener('click', async () => {
      // 先同步 DOM 已填文本，再规范化保存：逐行 {...完整原对象, item/host trim}，
      // 剔除空 item 行（新加未填行自动忽略）；原对象的 id/result/扩展字段全部保留
      syncFromDom();
      const next = normalizeEditedAgenda(current);
      const relationCheck = validateAgendaStructure(next);
      if (!relationCheck.ok) {
        showToast('error', relationCheck.error);
        return;
      }
      try {
        const updated = await BranchService.updateActivity(activity.id, { agenda: next });
        persist();
        showToast('success', '会议议程已更新');
        // 通知全员（不加 actionRoles = 全员可见；活动锚定 targetType/targetId 供归档联动）
        // R-22（2026-09-13）：系统派生通知改由服务端按 kind 生成（不再前端自述可信标记）
        try {
          NoticeStore.addSystem('activity-agenda-updated', activity.id, { activityTitle: activity.title });
        } catch (ne) {
          console.warn('[inspector] 议程更新通知发送失败（不影响保存）：', ne);
        }
        renderInspectorDetail(updated, tasks, managementRole);
      } catch (e) {
        showToast('error', '议程保存失败：' + ((e && e.message) || '未知错误'));
      }
    });
  };
  renderEditor();
}

// ════════════════════════════════════════════════════════════════
//  B 档 CRUD 补全：活动信息编辑浮窗（支书预填 → BranchService.updateActivity）
//  仅编辑基础信息（名称/日期/时间/地点/主持人/详情），议程走行内编辑、状态走生命周期。
// ════════════════════════════════════════════════════════════════
function _openActivityEditModal(activity, tasks, managementRole) {
  openModal({
    id: 'activity-edit',
    title: '编辑活动信息',
    width: '560px',
    accentColor: '#CE1126',
    bodyHtml: `
      <div class="space-y-3">
        <div>
          <label class="text-xs text-gray-500 mb-1.5 block font-medium">活动名称 <span class="text-red-600">*</span></label>
          <input type="text" id="ae-title" class="input-flat w-full" value="${activity.title || ''}">
        </div>
        <div class="modal-form-grid">
          <div>
            <label class="text-xs text-gray-500 mb-1.5 block font-medium">日期 <span class="text-red-600">*</span></label>
            <input type="date" id="ae-date" class="input-flat w-full" value="${activity.date || ''}">
          </div>
          <div>
            <label class="text-xs text-gray-500 mb-1.5 block font-medium">时间 <span class="text-gray-500">（选填）</span></label>
            <input type="text" id="ae-time" class="input-flat w-full" value="${activity.time || ''}" placeholder="如 14:00-16:00">
          </div>
        </div>
        <div>
          <label class="text-xs text-gray-500 mb-1.5 block font-medium">地点 <span class="text-red-600">*</span></label>
          <input type="text" id="ae-location" class="input-flat w-full" value="${activity.location || ''}">
        </div>
        <div>
          <label class="text-xs text-gray-500 mb-1.5 block font-medium">主持人 <span class="text-gray-500">（选填）</span></label>
          <input type="text" id="ae-host" class="input-flat w-full" value="${activity.host || ''}">
        </div>
        <div>
          <label class="text-xs text-gray-500 mb-1.5 block font-medium">活动详情 <span class="text-gray-500">（选填）</span></label>
          <textarea id="ae-desc" rows="3" class="input-flat w-full">${activity.description || ''}</textarea>
        </div>
      </div>`,
    footerHtml: `
      <button id="ae-cancel" type="button" data-modal-cancel="activity-edit" class="btn-outline text-sm px-4 py-1.5">取消</button>
      <button id="ae-save" type="button" class="btn-accent text-sm px-4 py-1.5 font-medium">保存</button>`,
    onMount: (panel) => {
      panel.querySelector('#ae-save')?.addEventListener('click', async () => {
        const title = panel.querySelector('#ae-title')?.value?.trim();
        const date = panel.querySelector('#ae-date')?.value?.trim();
        const location = panel.querySelector('#ae-location')?.value?.trim();
        if (!title) { showToast('error', '请填写活动名称'); return; }
        if (!date) { showToast('error', '请选择日期'); return; }
        if (!location) { showToast('error', '请填写活动地点'); return; }
        const patch = {
          title,
          date,
          time: panel.querySelector('#ae-time')?.value?.trim() || '',
          location,
          host: panel.querySelector('#ae-host')?.value?.trim() || '',
          description: panel.querySelector('#ae-desc')?.value?.trim() || '',
        };
        try {
          const updated = await BranchService.updateActivity(activity.id, patch);
          persist();
          showToast('success', '活动信息已更新');
          closeModal('activity-edit');
          setState({
            activities: getAppState().activities.map(a => (a.id === activity.id ? updated : a)),
          });
          renderInspectorDetail(updated, tasks, managementRole);
        } catch (e) {
          showToast('error', '保存失败：' + ((e && e.message) || '未知错误'));
        }
      });
    },
  });
}

/** D 档文件闭环：产出物区材料下载（mock=base64 dataURL 直下；server=受保护静态下载带鉴权拉取） */
async function _downloadMaterialRecord(rec) {
  if (rec.fileData) {
    const a = document.createElement('a');
    a.href = rec.fileData;
    a.download = rec.fileName || 'material';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    return true;
  }
  if (rec.filePath) {
    const baseUrl = getApiBaseUrl();
    const token = getAuthToken();
    const filePath = withSelectedBranchScope(rec.filePath);
    const url = filePath.startsWith('http') ? filePath : `${baseUrl}${filePath}`;
    try {
      const resp = await fetch(url, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
      if (!resp.ok) return false;
      const blob = await resp.blob();
      const u = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = u;
      a.download = rec.fileName || 'material';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(u);
      return true;
    } catch (e) {
      console.warn('[inspector] 材料下载失败：', e);
      return false;
    }
  }
  return false;
}

/**
 * 制度草案议程项旁的「是否报送党员大会表决」勾选位（2026-09-21 批次 129 · 制度链）。
 * 口径＝母本《常见工作场景快速指南》「制度建设」第 7 步「决定是否报送党员大会｜由支委会审议；
 *   是否报送支部党员大会表决，**在审议时确定**」⇒ 勾选位就挂在**记录结果**这一处，支书/副支书记录时一并定。
 * 「不勾」＝支委会审议通过即成现行版；「勾」＝审议通过后转「待党员大会表决」，再由支部党员大会那条议程定。
 * 判据（该议程项是否「支委会审议制度草案」）单一源＝`services/branch/branch-doc.js::isInstitutionDraftAgendaItem`；
 * 真正生效的门在服务层（`applyInstitutionAgendaResult`，会议类型与环节不符时会忽略这个勾选）。
 * @param {Object} agendaItem 议程项
 * @param {boolean} canRecord 当前人可记录结果（支书/副支书且未归档且尚无结果）
 * @returns {string} HTML（不适用时为空串）
 */
function _reportPartyToggleHtml(agendaItem, canRecord, decisionSource = agendaItem) {
  if (!canRecord || !agendaItem || agendaItem.result) return '';
  if (!isInstitutionDraftAgendaItem(decisionSource, mockDB.branchDocs || [])) return '';
  return `<label class="text-xs text-gray-500 inline-flex items-center gap-1 mt-1"><input type="checkbox" class="ap-report-party" data-agenda-item-id="${esc(agendaItem.id)}" style="cursor:pointer;">报送党员大会表决（不勾＝支委会通过即现行版）</label>`;
}
