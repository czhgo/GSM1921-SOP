// role: [工程师]+[AI]
// ════════════════════════════════════════════════════════════════
//  config-clean.js — 支部 config（modules/blocks）净化唯一实现（P1a 单向权威，2026-09-03）
//  消费方（两端共用同一实现，防止未同步的情况）：
//    docs/src/services/branch/branch.js（前端写路径：party-config 配置 UI / 支书操作）
//    server/routes/resources.js（PATCH /branches/:id/config）
//  语义采用 server 严格口径：id 只收非空字符串（不强制转串）、长度 ≤80、去重保序、限长截断。
//  本文件为纯 ESM（仅依赖 work-map / policy-defaults 两个纯数据模块），浏览器与 node 双端可加载。
// ════════════════════════════════════════════════════════════════
import { WORK_MAP_IDS, canDisableModule } from '../../core/domain/work-map.js?v=20261028a';
import { CAPABILITY_PACKAGE_BY_ID } from '../../core/domain/capability-packages.js?v=20261028a';
// 批4（2026-09-09 支书批「域参数」）：policyOverrides 白名单/复位/注入原语取自 policy-defaults
// （单源：覆盖白名单 POLICY_OVERRIDABLE 只定义于 policy-defaults，本文件为其唯一净化消费方）
import {
  POLICY_OVERRIDABLE,
  resetPolicyDefaults,
  applyPolicyOverrides,
} from '../../core/domain/policy-defaults.js?v=20261028a';

const MAX_ID_LEN = 80;
const MODULES_LIMIT = 200;
const BLOCKS_LIMIT = 50;

// ── 配置变更留痕审计内核共享常量（2026-09-09 支书批：支部 config 审计 why+回滚+上限）────────
// 单一源供两端消费：docs/src/services/branch/branch.js（mock 直写形态）与 server/routes/resources.js
// （PATCH /branches/:id/config 与 /branches/:id/config/rollback）——双形态同源，防止未同步的情况。
// config.configChangeHistory 现逐键留痕 {by,at,what,from,to,why?}；why=依据/出处（可选，来源页回填
// 如 REVIEW_QUEUE 附录编号）；单键回滚以 ROLLBACKABLE 键白名单收敛（跨键/聚合留痕不回滚）。
export const CONFIG_HISTORY_MAX = 100; // 历史上限：保留最近 N 条（追加/回滚后裁剪最早）
// R2-21（2026-10-20）：页面展示条数是**展示口径**，单独命名并从本文件导出——
//   原先「展示最近 50 条」既写死在 slice 里、又写死在设置页文案里，两处数字各一份。
export const CONFIG_HISTORY_DISPLAY_MAX = 50;
export const CONFIG_ROLLBACK_WHAT = 'rollback'; // 回滚留痕 what 标记
// 可回滚的单键变更（= 两端口径的追踪键全集；what 不在表内的留痕仅展示不可回滚）
export const CONFIG_ROLLBACK_KEYS = [
  'modules', 'blocks', 'workforce', 'capabilityPackages', 'headerTitle', 'desc', 'themePreset', 'policyOverrides',
];

/** 净化 id 数组：只收非空字符串、去重保序、长度 ≤80、最多保留 limit 项 */
export function cleanIdList(v, limit) {
  if (!Array.isArray(v)) return [];
  return [...new Set(v)].filter((x) => typeof x === 'string' && x && x.length <= MAX_ID_LEN).slice(0, limit);
}

/**
 * 净化 config.modules（{ hiddenTabIds, tabOrder }；均按 MODULES_LIMIT 截断）
 * @param {Object|null} modules
 * @param {{ coreIds?: Set<string> }} [opts] coreIds 非空时排除核心 tab（前端用；server 无能力清单，传空）
 */
export function sanitizeConfigModules(modules, { coreIds = new Set() } = {}) {
  if (modules === null) return null;
  return {
    hiddenTabIds: cleanIdList(modules?.hiddenTabIds, MODULES_LIMIT).filter((id) => !coreIds.has(id)),
    tabOrder: cleanIdList(modules?.tabOrder, MODULES_LIMIT).filter((id) => !coreIds.has(id)),
  };
}

/**
 * 净化 config.workforce（L4 支部分工；null=恢复默认缺省分工）
 * 只保留 WORK_MAP_IDS 内的模块键；每项 { ownerType∈{role,person,org}, ownerId: 非空字符串 ≤80 }。
 * `org` ＝**组织型主体**（见 `work-map.js::ORG_SUBJECTS`，如 `branch-committee`＝支委会：类似法人、
 *   不是自然人、不是角色键，**不能当登录身份**）；语义校验（ownerId 是否真实角色 / 成员 / 组织主体）
 *   由 service/UI 层负责，此处只做形状防脏注入。
 */
export function sanitizeConfigWorkforce(workforce) {
  if (workforce === null) return null;
  if (!workforce || typeof workforce !== 'object' || Array.isArray(workforce)) return {};
  const idSet = new Set(WORK_MAP_IDS);
  const out = {};
  for (const [moduleId, assign] of Object.entries(workforce)) {
    if (!idSet.has(moduleId)) continue;
    const ownerType = assign?.ownerType;
    const ownerId = assign?.ownerId;
    // 停用标记（2026-09-13 分层）：ownerType='none' 仅方法类可停用（规范类=必办，落库前拦掉）
    if (ownerType === 'none') {
      if (canDisableModule(moduleId)) out[moduleId] = { ownerType: 'none', ownerId: '' };
      continue;
    }
    if ((ownerType === 'role' || ownerType === 'person' || ownerType === 'org') &&
        typeof ownerId === 'string' && ownerId && ownerId.length <= MAX_ID_LEN) {
      out[moduleId] = { ownerType, ownerId };
    }
  }
  return out;
}
/**
 * 净化 config.blocks（{ outputBlocks?, workflowBlocks? }；null=恢复默认）
 * 只保留调用方提供的子段；每子段 id 按 BLOCKS_LIMIT 截断。
 */
export function sanitizeConfigBlocks(blocks) {
  if (blocks === null) return null;
  const out = {};
  if (blocks.outputBlocks) {
    out.outputBlocks = {
      hiddenBlockIds: cleanIdList(blocks.outputBlocks.hiddenBlockIds, BLOCKS_LIMIT),
      blockOrder: cleanIdList(blocks.outputBlocks.blockOrder, BLOCKS_LIMIT),
    };
  }
  if (blocks.workflowBlocks) {
    out.workflowBlocks = {
      hiddenBlockIds: cleanIdList(blocks.workflowBlocks.hiddenBlockIds, BLOCKS_LIMIT),
      // L3 流程组合（2026-09-28 批次 246）：工作流块亦支持支部级顺序（与 outputBlocks.blockOrder 同口径）
      blockOrder: cleanIdList(blocks.workflowBlocks.blockOrder, BLOCKS_LIMIT),
    };
    // ② 表单条目轴（契约 §8.2，2026-09-29 批次 275）：块级「字段策略」——单一净化实现
    if (blocks.workflowBlocks.fieldPolicies) {
      out.workflowBlocks.fieldPolicies = cleanFieldPolicies(blocks.workflowBlocks.fieldPolicies);
    }
    // ③ 参与人范围轴（契约 §8.3，2026-09-29 批次 275）：块级「名单解析模式」——单一净化实现
    if (blocks.workflowBlocks.participantPolicies) {
      out.workflowBlocks.participantPolicies = cleanParticipantPolicies(blocks.workflowBlocks.participantPolicies);
    }
  }
  return out;
}

/**
 * 净化支部选用的业务能力包版本；适用范围/依据仍由党委目录定义，支部只保存是否启用与采用版本。
 * 仅 `optional` / `local` 包可由支部关闭；`required` / `pending` 不允许关闭或伪造新版本。
 */
export function sanitizeConfigCapabilityPackages(value) {
  if (value === null) return null;
  const raw = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const source = raw.packages && typeof raw.packages === 'object' && !Array.isArray(raw.packages) ? raw.packages : {};
  const packages = {};
  for (const [id, entry] of Object.entries(source)) {
    const definition = CAPABILITY_PACKAGE_BY_ID.get(id);
    if (!definition || !entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
    if (typeof entry.enabled !== 'boolean' || entry.version !== definition.version) continue;
    if (!entry.enabled && !['optional', 'local'].includes(definition.applicability)) continue;
    packages[id] = { version: definition.version, enabled: entry.enabled };
  }
  return { schemaVersion: 1, packages };
}

// ③ 参与人范围轴（契约 §8.3）：可配面**只开两字段**——`mode` ∈ {fixed, configurable}、
//   `orgMode` ∈ {none, organizer-deep}（均为 manifest 已有取值，**不新造枚举**）。
const PARTICIPANT_MODE_SET = new Set(['fixed', 'configurable']);
const PARTICIPANT_ORG_MODE_SET = new Set(['none', 'organizer-deep']);

/**
 * 净化 workflowBlocks.participantPolicies ＝ { [blockId]: { mode?, orgMode? } }
 * 形状防脏：blockId ≤80 字、至多 BLOCKS_LIMIT 个；两字段各按白名单收，非法丢弃；
 *   空壳（两字段皆缺）不保留。**不含任何具体人名**（§8.3：人名一律不落 config）。
 */
export function cleanParticipantPolicies(v) {
  if (!v || typeof v !== 'object' || Array.isArray(v)) return {};
  const out = {};
  let n = 0;
  for (const [blockId, pol] of Object.entries(v)) {
    if (n >= BLOCKS_LIMIT) break;
    if (typeof blockId !== 'string' || !blockId || blockId.length > MAX_ID_LEN) continue;
    const item = {};
    if (PARTICIPANT_MODE_SET.has(pol?.mode)) item.mode = pol.mode;
    if (PARTICIPANT_ORG_MODE_SET.has(pol?.orgMode)) item.orgMode = pol.orgMode;
    if (!Object.keys(item).length) continue;
    out[blockId] = item;
    n++;
  }
  return out;
}

/**
 * 净化 workflowBlocks.fieldPolicies ＝ { [blockId]: { hiddenFieldIds, requiredOverrides } }
 * 语义（契约 §8.2）：支部可配面**只开两类**——`hiddenFieldIds`（字段启停）＋
 *   `requiredOverrides`（必填覆盖）。第三类（重命名 / 重排 / 新增字段）**不开**。
 * 形状防脏：blockId ≤80 字、至多 BLOCKS_LIMIT 个；hiddenFieldIds 走 cleanIdList；
 *   requiredOverrides 只收**布尔值**（键 ≤80 字）。空壳（两类皆空）不保留。
 */
export function cleanFieldPolicies(v) {
  if (!v || typeof v !== 'object' || Array.isArray(v)) return {};
  const out = {};
  let n = 0;
  for (const [blockId, pol] of Object.entries(v)) {
    if (n >= BLOCKS_LIMIT) break;
    if (typeof blockId !== 'string' || !blockId || blockId.length > MAX_ID_LEN) continue;
    const hiddenFieldIds = cleanIdList(pol?.hiddenFieldIds, BLOCKS_LIMIT);
    const requiredOverrides = {};
    const raw = pol?.requiredOverrides;
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
      for (const [fid, val] of Object.entries(raw)) {
        if (typeof fid !== 'string' || !fid || fid.length > MAX_ID_LEN) continue;
        if (typeof val === 'boolean') requiredOverrides[fid] = val;
      }
    }
    if (!hiddenFieldIds.length && !Object.keys(requiredOverrides).length) continue;
    out[blockId] = { hiddenFieldIds, requiredOverrides };
    n++;
  }
  return out;
}

// ── 换组织向导 · 支部组织档案字段（2026-09-06 支书 R4：可改即改 + 固定令牌不改）─────────
// config.headerTitle（页眉显示名）/ config.desc（支部自述）/ config.themePreset（主题预设 id）。
// 主题预设只提供「可调令牌」（角色识别层强调色 --app-accent 三件套）的 3-4 档；
// 党建红 party-red 与党徽金 party-gold 为固定合规底线，不提供更改——预设 id 白名单即此口径的代码面。
export const THEME_PRESET_IDS = ['red', 'green', 'sky', 'blue'];

const ORG_MAX = { name: 80, headerTitle: 120, desc: 500 };

/**
 * 净化支部组织档案写片（向导步骤①；单一实现 = 本文件，前端 branch.js / server resources.js 共用）
 * 仅返回「调用方提供了且净化后合法」的键：name/headerTitle/desc/themePreset。
 * 语义：
 *   - name/headerTitle：trim 非空、按上限截断；空串 → 不返回（不改，页眉名不允许清空）。
 *   - desc：trim 后按上限截断；空串 → ''（可清空自述）。
 *   - themePreset：白名单 THEME_PRESET_IDS 内 → 返回；null → null（清除预设回默认红调）；其它 → 忽略。
 * @param {Object|null} org 前端 UI 传入的写片
 */
export function sanitizeConfigOrg(org) {
  if (!org || typeof org !== 'object' || Array.isArray(org)) return {};
  const out = {};
  if (Object.prototype.hasOwnProperty.call(org, 'name')) {
    const t = String(org.name ?? '').trim();
    if (t) out.name = t.slice(0, ORG_MAX.name);
  }
  if (Object.prototype.hasOwnProperty.call(org, 'headerTitle')) {
    const t = String(org.headerTitle ?? '').trim();
    if (t) out.headerTitle = t.slice(0, ORG_MAX.headerTitle);
  }
  if (Object.prototype.hasOwnProperty.call(org, 'desc')) {
    out.desc = String(org.desc ?? '').trim().slice(0, ORG_MAX.desc);
  }
  if (Object.prototype.hasOwnProperty.call(org, 'themePreset')) {
    const v = org.themePreset;
    if (v === null) out.themePreset = null;
    else if (THEME_PRESET_IDS.includes(v)) out.themePreset = v;
  }
  return out;
}

// ── 批4 域参数 policyOverrides（2026-09-09 支书批：config 独立域；白名单=policy-defaults POLICY_OVERRIDABLE）──
// 语义：
//   · policyOverrides = { 节: { 叶: 值 } }——节/叶白名单单一源 = POLICY_OVERRIDABLE（path 行走），
//     institutional（制度裁决固定）键不在表内 → 写不进来。
//   · 值校验：int=整数且钳 [min,max]（防负数/超长天数）；boolean=严格布尔；windows=窗口数组
//     （每窗 [起月,起日,止月,止日]，月 1..12、日 1..31，至多保留前 2 窗、去重）。
//   · 非法值/未知键一律丢弃（不写坏）；null/undefined 入参 → null（= 无 overrides / 整体恢复默认）。
//   · 前端 branch.js savePolicyOverrides 与 server PATCH /branches/:id/config 共用本净化实现（防止未同步的情况）。

function _cleanPolicyValue(spec, raw) {
  if (spec.type === 'int') {
    if (!Number.isInteger(raw)) return undefined;
    return Math.min(Math.max(raw, spec.min), spec.max);
  }
  if (spec.type === 'boolean') return typeof raw === 'boolean' ? raw : undefined;
  // enum（2026-09-22 批次 150：活动批准门三态）：只收白名单取值，其余丢弃
  if (spec.type === 'enum') return (Array.isArray(spec.values) && spec.values.includes(raw)) ? raw : undefined;
  if (spec.type === 'windows') {
    if (!Array.isArray(raw)) return undefined;
    const seen = new Set();
    const out = [];
    for (const w of raw) {
      if (!Array.isArray(w) || w.length !== 4 || out.length >= 2) continue;
      const [sm, sd, em, ed] = w;
      if (!(Number.isInteger(sm) && Number.isInteger(sd) && Number.isInteger(em) && Number.isInteger(ed))) continue;
      if (sm < 1 || sm > 12 || em < 1 || em > 12 || sd < 1 || sd > 31 || ed < 1 || ed > 31) continue;
      const key = `${sm}-${sd}-${em}-${ed}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push([sm, sd, em, ed]);
    }
    return out.length ? out : undefined;
  }
  return undefined;
}

/**
 * 净化 config.policyOverrides（键白名单 + 值类型校验 + 数值范围钳制唯一实现）。
 * @param {Object|null} policyOverrides
 * @returns {Object|null} null=无 overrides（删除语义）；对象=仅白名单合法键；空对象=全非法
 */
export function sanitizeConfigPolicyOverrides(policyOverrides) {
  if (policyOverrides === null || policyOverrides === undefined) return null;
  if (!policyOverrides || typeof policyOverrides !== 'object' || Array.isArray(policyOverrides)) return {};
  const out = {};
  for (const spec of POLICY_OVERRIDABLE) {
    const [s0, s1, s2] = spec.path;
    const holder = policyOverrides[s0];
    if (!holder || typeof holder !== 'object' || Array.isArray(holder)) continue;
    const raw = s2 === undefined
      ? holder[s1]
      : (holder[s1] && typeof holder[s1] === 'object' && !Array.isArray(holder[s1]) ? holder[s1][s2] : undefined);
    if (raw === undefined) continue;
    const v = _cleanPolicyValue(spec, raw);
    if (v === undefined) continue;
    if (!out[s0] || typeof out[s0] !== 'object') out[s0] = {};
    if (s2 === undefined) {
      out[s0][s1] = v;
    } else {
      if (!out[s0][s1] || typeof out[s0][s1] !== 'object') out[s0][s1] = {};
      out[s0][s1][s2] = v;
    }
  }
  return out;
}

/**
 * 读侧有效默认注入（批4）：先复位出厂默认，再按目标支部 config.policyOverrides（白名单净化后）
 * 就地覆盖进 POLICY_DEFAULTS —— 无 overrides = 保持默认（零 diff）；先复位再覆盖保证跨支部
 * 重复调用不残留上一支部值（幂等）。纯函数入参（branch 记录），可在 node 侧直接单测。
 * @param {Object|null} branch 支部记录（取 branch.config.policyOverrides）
 * @returns {boolean} 是否实际应用了覆盖
 */
export function applyBranchPolicyOverrides(branch) {
  resetPolicyDefaults();
  if (!branch || !branch.config) return false;
  const clean = sanitizeConfigPolicyOverrides(branch.config.policyOverrides);
  if (clean && Object.keys(clean).length) {
    applyPolicyOverrides(clean);
    return true;
  }
  return false;
}
