// role: [工程师]+[AI]
// services/core/auth.js — 权限系统（重构版）
// 设计文档: docs/superpowers/specs/2026-07-12-permission-system-redesign-design.md
//
// 核心变化:
//   - 去掉 stance/view/mode 三元组
//   - 去掉 AUTHZ_CHAIN + scope 双轨制
//   - 常设角色判全局本职；项目成员身份与工作组操作授权分开记录
//   - 链式赋权: AUTHORIZE_CHAIN 定义谁可以赋权什么角色
//   - party 页面已移除，organizer/deep 内容落在成员工作台（workspace/visitor.html）——
//     首页并无"我的角色"区块（2026-09-17 批次 64 dogfood 实测）

import { DEFAULT_BRANCH_ID, ROLE_LABELS, ROLE_PAGE_MAP, BRANCH_COMMISSION_ROLES } from '../../core/domain/constants.js?v=20261028b';
import { PEOPLE } from '../../data/mock/index.js?v=20261028b';
// 账号登录校验（认证域收口：UI 不直连 mock 账号仓；真实后端接入时此处替换校验实现）
// 2026-09-14 批次 25：改为「可持久化账号层 ∪ 静态种子表」校验（成员流入自动建号 / 流出停用；
//   见 services/core/accounts.js），支撑「账号与成员档案同源」口径。
import { verifyLogin } from './accounts.js?v=20261028b';
import { getPersonById, getPersonName } from '../member/person.js?v=20261028b';
import { mockDB, WORKGROUP_WRITABLE_STATUSES } from '../../core/domain/domain.js?v=20261028b';
import { NoticeStore } from '../governance/notice.js?v=20261028b';
import { getAdapter, migrateLegacyPersonId } from '../../data/data-adapter.js?v=20261028b';
import { enableApiMode } from './runtime.js?v=20261028b';
import { generateId } from '../../core/base/id.js?v=20261028b';
import { todayLocal } from '../../core/base/utils.js?v=20261028b';
import { WORKGROUP_PERMISSION_TEMPLATES_BY_KIND } from '../../core/domain/workgroup-policy.js?v=20261028b';

// 迁移期（2026-10-20）：旧 p* 仅作登录别名 / 历史 localStorage 兼容，会话一律存学号。
// 映射表经 data-adapter 的迁移入口转出，业务层不直接引用 deprecated 映射文件。
let _legacyAliasWarned = false;
function _toStudentId(id) {
  const mapped = migrateLegacyPersonId(id);
  if (mapped == null) return null;
  if (mapped !== id && !_legacyAliasWarned) {
    _legacyAliasWarned = true;
    console.warn('[AuthStore] 检测到旧 p* 人员 id（仅迁移期兼容），已按学号处理');
  }
  return mapped;
}

// ── 登录状态 ─────────────────────────────────────
const LOGIN_KEY = 'gsm1921-login-user';   // localStorage: { personId, role, tabId }
const TAB_KEY = 'gsm1921-tab-id';         // sessionStorage: 当前标签页唯一 ID（A-11 防串扰）
const SESSION_KEY = 'gsm1921-session-snap'; // sessionStorage: 本标签页登录会话快照
const SESSION_TOKEN_KEY = 'gsm1921-api-token'; // sessionStorage: API 认证 token（runtime.js enableApiMode 写入）

// A-11 多标签页登录防串扰：每个标签页生成唯一 tabId。
// 登录写入 localStorage（带 tabId）+ sessionStorage 快照；
// getCurrentUser 校验 tabId——localStorage 被其它标签页覆盖时回退到本页快照，B 页登录不再改变 A 页身份。
function _getTabId() {
  let id = null;
  try { id = sessionStorage.getItem(TAB_KEY); } catch {}
  if (!id) {
    id = generateId('tab', '-');
    try { sessionStorage.setItem(TAB_KEY, id); } catch {}
  }
  return id;
}

function _writeLogin(data) {
  const payload = { ...data, tabId: _getTabId() };
  // 批次 277（IAAA 入站）：`branchId` 可选携带——**IAAA 与账号登录都会写**，
  //   供「待归属阻断层」在**无网络请求**的前提下判定（`null` ＝ 已知未归属；缺字段 ＝ 未知 ⇒ 不拦）。
  const snap = { personId: data.personId, role: data.role };
  if (Object.prototype.hasOwnProperty.call(data, 'branchId')) snap.branchId = data.branchId;
  try {
    localStorage.setItem(LOGIN_KEY, JSON.stringify(payload));
    // 本标签页会话快照（不含 tabId，供被覆盖时回退）
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(snap));
  } catch {}
}

// 其它标签页改动登录状态 → 派发 auth-changed 事件，供页面刷新用户区（防串扰辅助）
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key !== LOGIN_KEY) return;
    document.dispatchEvent(new CustomEvent('gsm1921:auth-changed', { detail: { storageEvent: e } }));
  });
}

// ── 权限表 ──────────────────────────────────────
// issue.* 权限项遵循 GitHub Issue 风格权限矩阵（spec §五）
//   全员基础权限（view/create/comment/reaction/mention/reference/edit.own）通过 _ISSUE_PERMS_ALL 注入
//   意见处置权限（status.change/close/comment.hide/edit.others/milestone.manage/assignee.set/drafts.merge/drafts.reject）
//   ＝支委会职权（2026-09-21 批次 126 · D-550：由「仅支书」放开）⇒ 支委层五角色（支书/副支书/组织/宣传/纪检）均持
const _ISSUE_PERMS_ALL = [
  'issue.view', 'issue.create', 'issue.comment.add', 'issue.reaction.toggle',
  'issue.mention', 'issue.reference', 'issue.edit.own',
];
const _ISSUE_PERMS_DISPOSITION = [
  'issue.status.change', 'issue.close', 'issue.comment.hide', 'issue.edit.others',
  'issue.milestone.manage', 'issue.assignee.set', 'issue.drafts.merge', 'issue.drafts.reject',
];
const ROLE_PERMISSIONS = {
  'secretary':         ['view_all', 'create_activity', 'assign_task', 'modify_assignment', 'mark_complete', 'fill_review', 'record_inspection', 'manage_taskforce', 'initiate_taskforce', 'authorize_taskforce', 'authorize', 'archive', 'manage_members', ..._ISSUE_PERMS_ALL, ..._ISSUE_PERMS_DISPOSITION],
  'deputy-secretary':  ['view_all', 'create_activity', 'assign_task', 'modify_assignment', 'mark_complete', 'fill_review', 'record_inspection', 'manage_taskforce', 'initiate_taskforce', 'authorize_taskforce', 'authorize', 'archive', 'manage_members', ..._ISSUE_PERMS_ALL, ..._ISSUE_PERMS_DISPOSITION],
  'org-commissioner':  ['view_all', 'record_inspection', 'manage_taskforce', 'initiate_taskforce', 'authorize_taskforce', 'archive', 'dispatch_line', ..._ISSUE_PERMS_ALL, ..._ISSUE_PERMS_DISPOSITION],
  'prop-commissioner': ['view_all', 'manage_taskforce', 'initiate_taskforce', 'archive', 'dispatch_line', ..._ISSUE_PERMS_ALL, ..._ISSUE_PERMS_DISPOSITION],
  'disc-commissioner': ['view_all', 'record_attendance', 'summarize_inspection', 'record_inspection', 'manage_taskforce', 'initiate_taskforce', 'dispatch_line', ..._ISSUE_PERMS_ALL, ..._ISSUE_PERMS_DISPOSITION],
  'leader':            ['view_all', 'create_activity', 'assign_task', 'modify_assignment', 'mark_complete', 'fill_review', 'record_inspection', 'assign_project_role', ..._ISSUE_PERMS_ALL],
  'participant':       ['view_public', ..._ISSUE_PERMS_ALL], // record_inspection 已收敛（2026-09-05 支书裁：无「本人写」路径，矩阵 §9d 改 '--'，本人素材走活动参与记录）
};
// dispatch_line（条线下发，A1-2026-09-05 落代码）：组织线/宣传线/纪检线职能任务下发，授予对应支委；
// 与 assign_task（支书/副支书/组长派执行）分两类——键级已入集（canDo 可判定），交互流消费侧待建。
// 文档映射：content/02_institution/SYSTEM_ROLE_PERMISSION.md §9f（权限名语义说明）+ CF §C.2。
// 注：§9b 16 操作矩阵列不并该键（消费侧未建、不硬凑列），见该文件变更历史 2026-09-05 条目。

// 项目身份说明「在这件事里承担什么职责」；系统动作另由 workgroupGrants 明确授予。
const PROJECT_ACTION_PERMISSION = {
  view_project: 'activity.view',
  assign_task: 'task.manage',
  modify_assignment: 'workgroup.members.manage',
  mark_complete: 'task.complete',
  fill_review: 'output.submit',
  record_inspection: 'output.submit',
  assign_project_role: 'workgroup.members.manage',
};

// 旧编辑入口按活动默认；新共享编辑器按工作组类型选择独立模板。
export const WORKGROUP_PERMISSION_TEMPLATES = WORKGROUP_PERMISSION_TEMPLATES_BY_KIND.activity;

function _workgroupIdForProject(projectId) {
  const activity = mockDB.activities.find((row) => row.id === projectId);
  if (activity) return activity.workgroupId || `wg-activity-${projectId}`;
  const taskforce = mockDB.taskforces.find((row) => row.id === projectId);
  if (taskforce) return taskforce.workgroupId || `wg-taskforce-${projectId}`;
  return null;
}

function _updateProjectMemberCache(projectId, personId, role, remove = false) {
  const activity = mockDB.activities.find((row) => row.id === projectId);
  const taskforce = mockDB.taskforces.find((row) => row.id === projectId);
  const source = activity || taskforce;
  if (!source) return;
  const memberKey = activity ? 'assignments' : 'members';
  const members = Array.isArray(source[memberKey]) ? source[memberKey] : [];
  const nextMembers = members.filter((member) => member.personId !== personId);
  if (!remove && role && !nextMembers.some((member) => member.personId === personId)) {
    const previous = members.find((member) => member.personId === personId);
    nextMembers.push({ ...previous, personId, role });
  }
  const next = { ...source, [memberKey]: nextMembers };
  if (activity) next.organizer = nextMembers.find((member) => member.role === 'organizer')?.personId || null;
  const collection = activity ? 'activities' : 'taskforces';
  mockDB[collection] = mockDB[collection].map((row) => row.id === projectId ? next : row);
}

async function _upsertProjectMember(projectId, personId, role) {
  const workgroupId = _workgroupIdForProject(projectId);
  if (!workgroupId) throw new Error('找不到项目对应的工作组');
  const row = await getAdapter().workgroups.members.add(workgroupId, { personId, role });
  const previous = mockDB.workgroupMembers.find((item) => item.id === row?.id);
  mockDB.workgroupMembers = [...mockDB.workgroupMembers.filter((item) => item.id !== row?.id), { ...(previous || {}), ...row }];
  _updateProjectMemberCache(projectId, personId, role, false);
  return row;
}

async function _removeProjectMember(projectId, personId) {
  const workgroupId = _workgroupIdForProject(projectId);
  if (!workgroupId) throw new Error('找不到项目对应的工作组');
  const actor = AuthStore.getCurrentUser();
  const removedBy = actor?.personId || actor?.id || null;
  const removedAt = new Date().toISOString();
  await getAdapter().workgroups.members.remove(workgroupId, personId, { removedBy });
  const memberId = `wgm-${encodeURIComponent(workgroupId)}-${encodeURIComponent(String(personId))}`;
  mockDB.workgroupMembers = mockDB.workgroupMembers.map((item) => item.id === memberId
    ? { ...item, status: 'removed', removedBy, removedAt } : item);
  mockDB.workgroupGrants = mockDB.workgroupGrants.map((item) => item.workgroupId === workgroupId && item.personId === personId && item.status === 'active'
    ? { ...item, status: 'revoked', revokedBy, revokedAt: removedAt, revocationReason: 'membership-removed' } : item);
  _updateProjectMemberCache(projectId, personId, null, true);
}

async function _grantProjectPermissions(projectId, personId, templateKey, options = {}) {
  const workgroupId = _workgroupIdForProject(projectId);
  if (!workgroupId) throw new Error('找不到项目对应的工作组');
  const grant = await getAdapter().workgroups.grants.create(workgroupId, {
    personId, templateKey, permissionKeys: options.permissionKeys,
    reason: options.reason || '', grantedBy: options.grantedBy || null,
  });
  if (grant) mockDB.workgroupGrants = [...mockDB.workgroupGrants.filter((item) => item.id !== grant.id), grant];
  return grant;
}

async function _replaceProjectPermissions(projectId, personId, templateKey, options = {}) {
  const workgroupId = _workgroupIdForProject(projectId);
  if (!workgroupId) throw new Error('找不到项目对应的工作组');
  const grants = await getAdapter().workgroups.grants.list(workgroupId);
  for (const grant of grants.filter((row) => row.personId === personId && row.status === 'active')) {
    await getAdapter().workgroups.grants.revoke(workgroupId, grant.id);
    mockDB.workgroupGrants = mockDB.workgroupGrants.map((row) => row.id === grant.id
      ? { ...row, status: 'revoked', revokedAt: new Date().toISOString() } : row);
  }
  return _grantProjectPermissions(projectId, personId, templateKey, options);
}

// ── 赋权链 ──────────────────────────────────────
// 统一记录"谁可以赋权什么角色"，由 authorize() 的 context 参数区分:
//   context 为空 → 常设角色赋权（系统级，如支委赋权组长）
//   context = { projectId } → 项目角色指派（项目级，如组长指派组织者）
// 注: 支委中「支书 / 副支书」由**党委**配置、不在本链（`D-585`）；其余支委身份（组织 / 宣传 / 纪检委员）由**本支部现任支书 / 副支书**配置 —— 2026-09-23 支书裁定＋追裁「副支书也可配」（见 services/branch/appointment.js::appointBranchCommissioner）
const AUTHORIZE_CHAIN = {
  'secretary':         ['leader', 'deputy-leader', 'organizer', 'deep', 'org-commissioner', 'prop-commissioner', 'disc-commissioner'],
  'deputy-secretary':  ['leader', 'deputy-leader', 'organizer', 'deep', 'org-commissioner', 'prop-commissioner', 'disc-commissioner'],
  'org-commissioner':  ['organizer', 'deep'],
  'leader':            ['organizer', 'deep'],
  'organizer':         ['deep'],
};

// ── 常设角色集合 ────────────────────────────────
// 支委授权角色（支书/副支书/组织/宣传/纪检）——vote-config.js resolveVoterIds('committee') 依此过滤
// （people.js role + isCommissioner），为前端支委名单的角色底层源；
// P2c（2026-09-03）：授权集单一源 = constants.js BRANCH_COMMISSION_ROLES（勿手写，server requireRole 同源）
const COMMISSIONER_ROLES = new Set(BRANCH_COMMISSION_ROLES);

// ── 获取用户的常设角色 ──────────────────────────
// 优先级: 赋权记录 > mock 数据
function _getUserRoleFromMemory(personId) {
  // 1. 检查赋权记录（组长 / 副组长由支委赋权）——取最新一条判定（revoke 追加语义）
  const records = _getAuthRecords();
  const groupRecs = records.filter(r => r.targetPersonId === personId && (r.role === 'leader' || r.role === 'deputy-leader'));
  if (groupRecs.length > 0) {
    const latest = groupRecs[groupRecs.length - 1]; // 数组顺序即时间顺序（批次 139：组正 / 副同取更晚一条）
    if (latest.action !== 'revoke') return latest.role;
  }

  // 2. 检查 mock 数据（新格式: role 单一值）
  const person = getPersonById(personId);
  if (person && person.role) return person.role;

  return 'participant';
}

// ── 获取用户在项目中的项目角色 ──────────────────
// 统一读入口：一级读主源（活动 assignments / 专班 members 运行时数据），
// 二级回退审计快照（仅历史数据；按角色取最新一条 action 判定是否已回收）。
// 注：主源优先于快照——若主源登记 participant 而快照有更新的 organizer/deep，以主源为准（快照仅历史兜底）。
function _getProjectRole(personId, projectId) {
  if (!projectId) return null;

  // 一级：主源 — 活动 assignments
  const activity = mockDB.activities.find(a => a.id === projectId);
  if (activity && Array.isArray(activity.assignments)) {
    const rec = activity.assignments.find(a => a.personId === personId);
    if (rec) return rec.role;  // 'organizer' | 'deep' | 'participant'
  }

  // 一级：主源 — 专班 members
  const tf = mockDB.taskforces.find(t => t.id === projectId);
  if (tf && Array.isArray(tf.members)) {
    const m = tf.members.find(m => m.personId === personId);
    if (m) return m.role;  // 'organizer' | 'deep' | 'participant'
  }

  // 二级：审计快照回退（按 (personId, role, scopeRef) 取最新一条，revoke 视为已回收）
  const records = _getAuthRecords();
  const roleRecs = records.filter(r =>
    r.targetPersonId === personId &&
    r.role && ['organizer', 'deep'].includes(r.role) &&
    r.scopeRef === projectId
  );
  const latestByRole = {};
  roleRecs.forEach(r => { latestByRole[r.role] = r; }); // 数组顺序即时间顺序
  for (const role of ['organizer', 'deep']) {
    const rec = latestByRole[role];
    if (rec && rec.action !== 'revoke') return role;
  }

  return null;
}

// ── 根据 projectId 取项目名称（用于赋权通知文案）──────────────────
function _getProjectName(projectId) {
  if (!projectId) return null;
  const a = mockDB.activities.find(x => x.id === projectId);
  if (a) return a.title;
  const t = mockDB.taskforces.find(x => x.id === projectId);
  if (t) return t.name;
  return null;
}

// ── 项目角色赋权通知（organizer / deep 被赋权时推送）──────────────
function _notifyProjectAuth(projectId, authorizerId, targetPersonId, role) {
  // 赋权通知直达**接收人本位**工作台（F12 · 2026-10-20 IA 修复）：
  //   原「组长→leader，其余→visitor」会把被赋权的支委/副组长弹回成员台（身份门拦回）。
  //   角色→页单一源 = constants.js::ROLE_PAGE_MAP.workspace；活动项目附带 activityId 供定位。
  const person = getPersonById(targetPersonId);
  const isActivity = !!mockDB.activities.find(x => x.id === projectId);
  const homePage = ROLE_PAGE_MAP.workspace[person?.role] || 'visitor.html';
  const targetPage = homePage === 'visitor.html' && isActivity
    ? `workspace/visitor.html?activityId=${projectId}`
    : `workspace/${homePage}`;

  const authorizerName = getPersonName(authorizerId) || authorizerId || '系统';
  const projectName = _getProjectName(projectId) || '未命名项目';
  const roleLabel = ROLE_LABELS[role] || role;

  // 确保 NoticeStore 已初始化（幂等兜底）
  if (typeof NoticeStore.init === 'function' && NoticeStore._notices.length === 0) {
    NoticeStore.init();
  }

  // R-22（2026-09-13）：系统派生通知改由服务端生成（kind 注册表复算授权 + 文案 + 落点）
  // R-23 余项收口（2026-10-06 批次 427）：**随包带 `role` 键**——服务端据此按
  //   `constants.js::ROLE_LABELS`（单一源）**复算** `roleLabel`，不再采信客户端自述的标签。
  NoticeStore.addSystem('project-auth-granted', projectId, {
    targetPage, authorizerName, projectName, roleLabel, role,
  });
}

// ── 追加审计快照条目 ──────────────────────────────
function _appendAuditEntries(scopeRef, actorId, entries, action) {
  if (!Array.isArray(entries) || entries.length === 0) return 0;
  const records = _getAuthRecords();
  entries.forEach(e => {
    records.push({
      id: generateId('auth', '-'),
      targetPersonId: e.personId,
      role: e.role || null,
      scopeRef,
      authorizedBy: actorId || null,
      authorizedAt: todayLocal(),
      action, // 'grant' | 'revoke'
    });
  });
  _saveAuthRecords(records);
  return entries.length;
}

// ── 审计快照存储（T-190 独立持久化；2026-09-24 批次 169 补服务端权威 auth_audit 表）──
// T-190：赋权审计快照不再是 mockDB 业务实体（只增不改，判定取最新一条），独立持久化杜绝双轨。
// api：服务端表 `auth_audit`（GET/POST /api/v1/auth-audit）为权威——读 init 缓存、写同发端点；mock：本机键。
const AUDIT_KEY = 'sop_org_os_auth_audit';

function _getAuthRecords() {
  try {
    if (Array.isArray(mockDB.authAudit)) return [...mockDB.authAudit]; // api：服务端缓存为权威
    const raw = localStorage.getItem(AUDIT_KEY); if (!raw) return [];   // mock：本机键
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (_) { return []; }
}

function _saveAuthRecords(records) {
  try { localStorage.setItem(AUDIT_KEY, JSON.stringify(records)); } catch (_) { /* quota exceeded 静默降级 */ }
  _syncAuthAuditToServer(records); mockDB.authAudit = records; }

// ════════════════════════════════════════════════
// AuthStore API
// ════════════════════════════════════════════════
export const AuthStore = {
  /**
   * 账号密码校验（登录域收口 2026-09-03：UI 不直连 mock 账号仓；真实后端接入时替换实现）
   * @param {string} studentId
   * @param {string} password
   * @returns {{ ok: boolean, personId: string|null }}
   */
  verifyCredentials(studentId, password) {
    // 迁移期：旧 p* 可作登录别名，校验通过后返回的 personId 一律是学号
    const resolved = _toStudentId(studentId);
    if (resolved == null) return { ok: false, personId: null };
    return verifyLogin(resolved, password);
  },

  /**
   * 登录（本地角色判定 + 后端 token 会话，失败静默降级本地模式）
   * @param {string} personId
   * @param {string} [password] 账号密码（后端 /login 校验口令；演示账号=123456）
   * @returns {Promise<void>}
   */
  async login(personId, password) {
    const accountId = _toStudentId(personId);
    if (accountId == null) return;
    personId = accountId;
    const role = _getUserRoleFromMemory(personId);
    _writeLogin({ personId, role });

    // 后端登录获取 token（失败静默降级到本地，不阻断使用）
    try {
      const r = await fetch('/api/v1/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ personId, password }),
      });
      const data = r.ok ? await r.json() : null;
      if (data && data.token) {
        enableApiMode(data.token);
        // 以后端返回的角色为准刷新本地会话
        if (data.user && data.user.role) {
          const patch = { personId: data.user.id || personId, role: data.user.role };
          // 批次 277：服务端**明给** branchId 才带上（缺字段＝未知 ⇒ 不写 ⇒ 不走待归属阻断层）
          if (Object.prototype.hasOwnProperty.call(data.user, 'branchId')) patch.branchId = data.user.branchId;
          _writeLogin(patch);
        }
        console.info('[AuthStore] 已切换至 API 数据源');
      }
    } catch (e) {
      console.warn('[AuthStore] 后端登录失败，保持本地模式', e);
    }
  },

  /**
   * **IAAA 入站落地**（2026-09-29 批次 277）：把 `/api/v1/auth/iaaa/callback` 换来的会话 token
   * 落地为本地会话。与 `login()` 的落点同一处（`_writeLogin` ＋ `enableApiMode`），不另写第二套。
   * @param {string} token 服务端会话 token
   * @param {{id:string, role:string, branchId?:string|null}} user 服务端 `/auth/me` 返回的用户
   */
  startIaaaSession(token, user) {
    try { enableApiMode(token); } catch (e) { console.warn('[AuthStore] IAAA 会话落地失败', e); }
    if (user && user.id && user.role) {
      _writeLogin({ personId: user.id, role: user.role, branchId: user.branchId === undefined ? null : user.branchId });
    }
  },

  /**
   * 开发模式直接登录（选身份）
   * 附带清除各工作台 Tab 缓存记忆（workflowos_tab_*），
   * 使开发模式打开页面始终显示默认 Tab（支书 2026-08-02 反馈"浏览器缓存干扰默认显示"）。
   * @param {string} role
   */
  devLogin(role) {
    // 找到该角色的第一个 mock 用户
    const person = PEOPLE.find(p => p.role === role);
    const personId = person ? person.id : (PEOPLE[0]?.id || null);
    _writeLogin({ personId, role });
    // 修复（2026-08-05）：开发模式是纯 mock 路径，必须清除残留 API token，
    // 否则 bootstrap 检测到 sessionStorage['gsm1921-api-token'] 会把开发模式劫持为 API 模式
    // （复现：账号登录后切开发模式卡片 → 28 个 /api/v1 请求）。
    try { sessionStorage.removeItem(SESSION_TOKEN_KEY); } catch (_) {}
    // 开发模式默认显示：清除 Tab 记忆，打开页面显示 defaultTab
    try {
      for (let i = localStorage.length - 1; i >= 0; i--) {
        const k = localStorage.key(i);
        if (k && k.startsWith('workflowos_tab_')) {
          localStorage.removeItem(k);
        }
      }
    } catch (_) { /* localStorage 不可用时静默降级 */ }
  },

  logout() {
    try {
      localStorage.removeItem(LOGIN_KEY);
      sessionStorage.removeItem(SESSION_KEY);
      // 修复（2026-08-05）：退出登录必须同时清除 API token，否则重新进入开发模式
      // 仍会因残留 token 被切回 API 数据源（开发模式与真实后端混淆）。
      sessionStorage.removeItem(SESSION_TOKEN_KEY);
    } catch {}
  },

  /**
   * 获取当前登录用户
   * @returns {{ personId: string, role: string } | null}
   */
  getCurrentUser() {
    try {
      const raw = localStorage.getItem(LOGIN_KEY);
      if (!raw) return null;
      const data = JSON.parse(raw);
      // A-11 防串扰：localStorage 中的登录若由其它标签页写入（tabId 不匹配），
      // 回退到本标签页会话快照，避免 B 页登录改变 A 页身份。
      if (data.tabId && data.tabId !== _getTabId()) {
        const snapRaw = sessionStorage.getItem(SESSION_KEY);
        if (snapRaw) {
          const snap = JSON.parse(snapRaw);
          const mapped = _toStudentId(snap.personId);
          if (mapped && mapped !== snap.personId) snap.personId = mapped;
          return snap;
        }
        return null;
      }
      // 迁移：旧格式 { userId, role } → 新格式 { personId, role }
      if (data.userId && !data.personId) {
        data.personId = data.userId;
        delete data.userId;
        localStorage.setItem(LOGIN_KEY, JSON.stringify(data));
      }
      // 迁移期：历史 localStorage 里的 p* 会话一次性改存学号
      const mapped = _toStudentId(data.personId);
      if (mapped && mapped !== data.personId) {
        data.personId = mapped;
        localStorage.setItem(LOGIN_KEY, JSON.stringify(data));
      }
      return data;
    } catch { return null; }
  },

  /**
   * 获取用户的常设角色
   */
  getUserRole(personId) {
    return _getUserRoleFromMemory(personId);
  },

  /**
   * 获取用户的有效角色（回退常设角色）
   * 用途：sidebar/header 等组件根据有效角色决定跳转目标
   * @param {string} personId
   * @returns {string} 角色 ID
   */
  getEffectiveRole(personId) {
    return this.getUserRole(personId);
  },

  /**
   * 获取用户在项目内的项目角色
   */
  getProjectRole(personId, projectId) {
    return _getProjectRole(personId, projectId);
  },

  /**
   * 获取该用户持有的所有项目角色（去重）
   * 用于 sidebar 渲染"可达的工作台页面"
   * @param {string} personId
   * @returns {string[]} - 如 ['organizer', 'deep']
   */
  getUserProjectRoles(personId) {
    if (!personId) return [];
    const projectRoleSet = new Set();

    // 仅读主源（活动 assignments / 专班 members）；审计快照只增不改，不做读源
    mockDB.activities.forEach(a => {
      if (Array.isArray(a.assignments)) {
        a.assignments.forEach(rec => {
          if (rec.personId === personId && ['organizer', 'deep'].includes(rec.role)) {
            projectRoleSet.add(rec.role);
          }
        });
      }
    });

    mockDB.taskforces.forEach(t => {
      if (Array.isArray(t.members)) {
        t.members.forEach(m => {
          if (m.personId === personId && ['organizer', 'deep'].includes(m.role)) {
            projectRoleSet.add(m.role);
          }
        });
      }
    });

    return [...projectRoleSet];
  },

  /**
   * 便捷判定该用户是否持有某项目角色
   * @param {string} personId
   * @param {string} role - 'organizer' | 'deep'
   * @returns {boolean}
   */
  hasProjectRole(personId, role) {
    if (!personId || !role) return false;
    return this.getUserProjectRoles(personId).includes(role);
  },

  /**
   * 该用户可达的所有 workspace 页面（standing + project）
   * 用于 sidebar 渲染"工作台"链接或子菜单
   * @param {string} personId
   * @returns {Array<{ role: string, page: string, label: string }>}
   */
  getAccessibleWorkspacePages(personId) {
    if (!personId) return [];
    const pages = [];
    const standingRole = _getUserRoleFromMemory(personId);

    // 1. standing role 对应页面（来自 ROLE_PAGE_MAP.workspace）
    const standingPage = (ROLE_PAGE_MAP.workspace || {})[standingRole];
    if (standingPage) {
      pages.push({
        role: standingRole,
        page: standingPage,
        label: ROLE_LABELS[standingRole] || standingRole,
      });
    }

    // 2. 项目角色（organizer/deep）**没有独立工作台页**——内容落在成员工作台（workspace/visitor.html），
    //    首页并无"我的角色"区块（2026-09-17 批次 64 dogfood 实测）；此处 page 值仅是历史占位，
    //    唯一调用方 sidebar.js 只取 pages.length 判定「工作台」入口是否渲染、不读本字段。
    const projectRoles = this.getUserProjectRoles(personId);
    projectRoles.forEach(role => {
      pages.push({
        role,
        page: 'index.html',
        label: ROLE_LABELS[role] || role,
      });
    });

    return pages;
  },

  /**
   * 统一权限判定
   * @param {string} personId
   * @param {string} action - 权限名（如 'create_activity'）
   * @param {{ projectId?: string }} context - 项目上下文
   * @returns {boolean}
   */
  canDo(personId, action, context = {}) {
    const userRole = _getUserRoleFromMemory(personId);
    const perms = ROLE_PERMISSIONS[userRole] || [];
    const projectIdentityOnly = userRole === 'organizer' || userRole === 'deep';

    // 全局权限判定
    if (!projectIdentityOnly && perms.includes(action)) return true;
    if (!projectIdentityOnly && perms.includes('view_all') && action.startsWith('view_')) return true;

    // 项目身份只说明成员承担的职责。工作组动作须另有显式 grant；支委等常设角色仍保留其本职能力。
    if (context.projectId) {
      const workgroupId = _workgroupIdForProject(context.projectId);
      const permissionKey = PROJECT_ACTION_PERMISSION[action] || (action.startsWith('view_') ? 'activity.view' : null);
      const workgroup = mockDB.workgroups.find((row) => row.id === workgroupId);
      // 工作组写权限只认 canonical 在办状态（recruiting/active）；draft/pending_review 只读等待。
      if (workgroupId && workgroup && WORKGROUP_WRITABLE_STATUSES.includes(workgroup.status) && permissionKey && mockDB.workgroupGrants.some((grant) => grant.workgroupId === workgroupId
        && grant.personId === personId && grant.status === 'active'
        && Array.isArray(grant.permissionKeys) && grant.permissionKeys.includes(permissionKey))) return true;
    }

    return false;
  },

  /**
   * 赋权（三合一：写主源 + 追加快照 + 发通知）
   * @param {string} authorizerId - 授权人 ID
   * @param {string} targetPersonId - 被赋权人 ID
   * @param {string} role - 角色
   * @param {{ projectId?: string }} context
   * @returns {Promise<{ ok: boolean, id: string }>}
   */
  async authorize(authorizerId, targetPersonId, role, context = {}) {
    if (!authorizerId || !targetPersonId || !role) return { ok: false, id: '' };

    // 校验: 授权人是否有权赋权该角色
    const authorizerRole = _getUserRoleFromMemory(authorizerId);
    const allowedRoles = AUTHORIZE_CHAIN[authorizerRole] || [];
    if (!allowedRoles.includes(role)) return { ok: false, id: '' };

    const scopeRef = context.projectId || null;

    // 查重（审计快照：grant 且未撤销，取最新一条判定）
    const records = _getAuthRecords();
    const dupRecs = records.filter(r =>
      r.targetPersonId === targetPersonId &&
      r.role === role &&
      (r.scopeRef || null) === scopeRef
    );
    const latestDup = dupRecs.length > 0 ? dupRecs[dupRecs.length - 1] : null;
    if (latestDup && latestDup.action !== 'revoke') return { ok: false, id: latestDup.id };

    // ① 项目身份与系统权限分别落表：成员关系写工作组成员表，操作权另写授权表。
    let memberAdded = false;
    try {
      if (scopeRef && (role === 'organizer' || role === 'deep')) {
        const workgroupId = _workgroupIdForProject(scopeRef);
        memberAdded = !mockDB.workgroupMembers.some((row) => row.workgroupId === workgroupId
          && row.personId === targetPersonId && row.status === 'active');
        await _upsertProjectMember(scopeRef, targetPersonId, role);
        await _grantProjectPermissions(scopeRef, targetPersonId, context.templateKey || role, {
          permissionKeys: context.permissionKeys, reason: context.reason, grantedBy: authorizerId,
        });
      }
    } catch (e) {
      console.warn('[AuthStore] authorize 写主源失败：', e);
      if (memberAdded) {
        try { await _removeProjectMember(scopeRef, targetPersonId); } catch {}
      }
      return { ok: false, id: '' };
    }

    // ② 追加审计快照
    const id = generateId('auth', '-');
    records.push({
      id,
      targetPersonId,
      role,
      scopeRef,
      authorizedBy: authorizerId,
      authorizedAt: todayLocal(),
      action: 'grant',
    });
    _saveAuthRecords(records);

    // ③ 赋权通知（organizer / deep）
    if (role === 'organizer' || role === 'deep') {
      _notifyProjectAuth(scopeRef, authorizerId, targetPersonId, role);
    }

    return { ok: true, id };
  },

  /**
   * 撤销赋权（三合一：删主源 + 追加 revoke 快照）
   * 快照只增不改：保留原 grant 记录，追加一条 action='revoke' 记录。
   * @param {string} recordId - 审计快照记录 ID
   * @returns {Promise<boolean>}
   */
  async revokeAuthorization(recordId) {
    if (!recordId) return false;
    const records = _getAuthRecords();
    const rec = records.find(r => r.id === recordId);
    if (!rec) return false;

    const personId = rec.targetPersonId;
    const { role, scopeRef } = rec;

    // 撤销项目身份时，从工作组移除成员；服务端同步撤销其活动授权并保留留痕。
    if (scopeRef && role && (role === 'organizer' || role === 'deep')) {
      try {
        const currentRole = _getProjectRole(personId, scopeRef);
        if (currentRole === role) await _removeProjectMember(scopeRef, personId);
      } catch (e) {
        console.warn('[AuthStore] revoke 工作组成员失败：', e);
        return false;
      }
    }

    // 追加 revoke 快照
    _appendAuditEntries(scopeRef, rec.authorizedBy || null, [{ personId, role }], 'revoke');
    return true;
  },

  getAuthorizations() {
    return _getAuthRecords();
  },

  /**
   * 整组同步项目角色（活动详情 / 专班详情内联编辑共用）
   * 三合一：写主源（全量覆盖 organizer/deep，保留 participant 等其它角色）+
   * 追加快照（新增 grant / 移除 revoke）+ 通知。
   * @param {{ scopeRef: string, assignments: Array<{personId:string, role:string}>, actorId?: string }} opts
   * @returns {Promise<{ added: number, removed: number }>}
   */
  async syncProjectRoles({ scopeRef, assignments = [], actorId, permissionKeysByRole = {} }) {
    if (!scopeRef) return { added: 0, removed: 0 };
    const desired = [...new Map(assignments
      .filter((x) => x.personId && (x.role === 'organizer' || x.role === 'deep'))
      .map((x) => [String(x.personId), { personId: String(x.personId), role: x.role }])).values()];

    const activity = mockDB.activities.find(a => a.id === scopeRef);
    const tf = mockDB.taskforces.find(t => t.id === scopeRef);
    let current = [];
    if (activity) {
      current = Array.isArray(activity.assignments)
        ? activity.assignments.filter(x => x.role === 'organizer' || x.role === 'deep')
        : [];
    } else if (tf) {
      current = Array.isArray(tf.members)
        ? tf.members.filter(m => m.role === 'organizer' || m.role === 'deep')
        : [];
    } else {
      return { added: 0, removed: 0 };
    }

    const currentByPerson = new Map(current.map((row) => [String(row.personId), row]));
    const desiredByPerson = new Map(desired.map((row) => [row.personId, row]));
    const added = desired.filter((row) => currentByPerson.get(row.personId)?.role !== row.role);
    const removed = current.filter((row) => desiredByPerson.get(String(row.personId))?.role !== row.role);

    // 成员和操作授权分别写入语义 API。保留 participant 等非项目角色成员。
    try {
      for (const row of removed) {
        if (!desiredByPerson.has(String(row.personId))) await _removeProjectMember(scopeRef, row.personId);
        else {
          await _upsertProjectMember(scopeRef, row.personId, desiredByPerson.get(String(row.personId)).role);
          const nextRole = desiredByPerson.get(String(row.personId)).role;
          await _replaceProjectPermissions(scopeRef, row.personId, nextRole, {
            permissionKeys: permissionKeysByRole[nextRole], grantedBy: actorId, reason: '工作组职责调整',
          });
        }
      }
      for (const row of added) {
        if (currentByPerson.has(row.personId)) continue;
        await _upsertProjectMember(scopeRef, row.personId, row.role);
        await _grantProjectPermissions(scopeRef, row.personId, row.role, {
          permissionKeys: permissionKeysByRole[row.role], grantedBy: actorId, reason: '工作组职责分配',
        });
      }
      // 同一职责下也允许调整建议模板；只在权限集合确实变化时重建授权并留痕。
      for (const row of desired) {
        if (!currentByPerson.has(row.personId) || permissionKeysByRole[row.role] === undefined) continue;
        const grants = await getAdapter().workgroups.grants.list(_workgroupIdForProject(scopeRef));
        const active = grants.filter((grant) => grant.personId === row.personId && grant.status === 'active');
        const requested = [...new Set(permissionKeysByRole[row.role])].sort();
        const granted = [...new Set(active.flatMap((grant) => grant.permissionKeys || []))].sort();
        if (JSON.stringify(requested) !== JSON.stringify(granted)) {
          await _replaceProjectPermissions(scopeRef, row.personId, row.role, {
            permissionKeys: requested, grantedBy: actorId, reason: '调整工作组操作权限',
          });
        }
      }
    } catch (e) {
      console.warn('[AuthStore] syncProjectRoles 工作组语义写入失败：', e);
      return { added: 0, removed: 0 }; // 主源未写成功不追加审计快照，避免快照与主源不一致
    }

    // 追加快照 + 通知
    _appendAuditEntries(scopeRef, actorId, added, 'grant');
    added.forEach(x => _notifyProjectAuth(scopeRef, actorId, x.personId, x.role));
    _appendAuditEntries(scopeRef, actorId, removed, 'revoke');

    return { added: added.length, removed: removed.length };
  },

  /**
   * 记录项目角色授予（主源已写入后的快照+通知，创建活动内联赋权/专班招募用）
   * @param {string} scopeRef - 活动或专班 ID
   * @param {Array<{personId:string, role:string}>} assignments
   * @param {string} [actorId]
   * @returns {number} 实际新增快照条数
   */
  async recordProjectGrants(scopeRef, assignments, actorId, { permissionKeysByRole = {} } = {}) {
    if (!scopeRef || !Array.isArray(assignments)) return 0;
    const records = _getAuthRecords();
    let count = 0;
    for (const a of assignments) {
      if (!a.personId || (a.role !== 'organizer' && a.role !== 'deep')) continue;
      const dupRecs = records.filter(r =>
        r.targetPersonId === a.personId && r.role === a.role && r.scopeRef === scopeRef
      );
      const latestDup = dupRecs.length > 0 ? dupRecs[dupRecs.length - 1] : null;
      if (latestDup && latestDup.action !== 'revoke') continue;
      await _grantProjectPermissions(scopeRef, a.personId, a.role, {
        permissionKeys: permissionKeysByRole[a.role], grantedBy: actorId, reason: '活动/工作组创建时赋予职责',
      });
      records.push({
        id: generateId('auth', '-'),
        targetPersonId: a.personId,
        role: a.role,
        scopeRef,
        authorizedBy: actorId || null,
        authorizedAt: todayLocal(),
        action: 'grant',
      });
      if (actorId !== a.personId) _notifyProjectAuth(scopeRef, actorId, a.personId, a.role);
      count++;
    }
    _saveAuthRecords(records);
    return count;
  },

  /**
   * 批量记录项目角色回收（专班解散等批量场景：主源由调用方清空，此处只追加快照）
   * @param {string} scopeRef
   * @param {Array<{personId:string, role?:string}>} entries
   * @param {string} [actorId]
   * @returns {number}
   */
  recordProjectRevokes(scopeRef, entries, actorId) {
    return _appendAuditEntries(scopeRef, actorId, entries || [], 'revoke');
  },

  // ── 辅助方法 ────────────────────────────────

  getRoleLabel(role) {
    return ROLE_LABELS[role] || role;
  },

  getPageForRole(module, role) {
    return (ROLE_PAGE_MAP[module] || {})[role] || null;
  },

  isCommissioner(role) {
    return COMMISSIONER_ROLES.has(role);
  },
};

/**
 * 当前登录人 personId（数据生命周期 P1-11，2026-10-20）。
 *
 * 为什么要有这个单一出口：各 tab 原写 `AuthStore.getCurrentUser()?.personId || 'pN'`，
 *   登录态失效时会把写操作记到固定演示人名下（支书概况甚至回落到组长 p1）。现统一返回
 *   `null`——写口必须拒绝并提示「请重新登录」，读口显示「—」，不得再猜人。
 * @returns {string|null}
 */
export function currentUserId() {
  return AuthStore.getCurrentUser()?.personId || null;
}

// ════════════════════════════════════════════════════════════════
//  副组长键的权限 / 赋权链（2026-09-21 批次 139 · 裁定 `D-571`，系照支书 2026-09-21 口径落）
// ════════════════════════════════════════════════════════════════
// 支书口径第 ③ 层：「我们并不像〔想〕给组长和副组长明确分工，而由他们自己探讨分工。所以设定了两者同样
//   的工作台。但是后台还是知道谁是组长，谁是副组长的」⇒ **系统不硬切分正副职责**：副组长的权限集与
//   赋权链**与同组组长同一份**（同一数组引用，未复制第二份，避免两处维护走偏）。
// ⚠ 为什么不写进上方 ROLE_PERMISSIONS / AUTHORIZE_CHAIN 字面量：`README-server.md` 按**行号**逐个引用
//   本文件的角色行与 `:90-106` / `:474-493`，插行会整体漂移（本批不许改 README）⇒ 集中在文件末挂载。
// 消费方：`AuthStore.canDo`（权限集）/ `AuthStore.authorize`（赋权链）/ `_getUserRoleFromMemory`（读回角色）。
ROLE_PERMISSIONS['deputy-leader'] = ROLE_PERMISSIONS['leader'];
AUTHORIZE_CHAIN['deputy-leader'] = AUTHORIZE_CHAIN['leader'];

// ════════════════════════════════════════════════════════════════
//  审计留痕的服务端同步（2026-09-24 批次 169；集中置尾 = 上文行号是 README-server.md 的取证靶点）
// ════════════════════════════════════════════════════════════════
// 病灶：赋权审计留痕原先**只有本机一份**（键 sop_org_os_auth_audit）⇒ 清缓存即留痕灭失；
//   而留痕的意义＝让「谁给谁赋了什么角色」这条治理承诺**可被事后核对**（没有它，承诺无从证伪）。
// 现 api 形态落服务端表 `auth_audit`（端点 GET/POST /api/v1/auth-audit，见 server/routes/resources.js 末
//   「授权审计留痕」段），`init()` 拉取填 `mockDB.authAudit`（data-adapter.js::_loadAuxCollections）。
// 同步口径：**只发本机新增的行**（服务端已存在的 id 不重发）；失败仅告警、下次 init 以服务端为准。
// ⚠ 动态 import（不在文件顶部静态引入 data-adapter）：本文件顶部 import 段被 README-server.md 按行号引用，
//   插行会整体漂移（同上方 deputy-leader 的处置）。
let _auditSyncedIds = null; // null = 未初始化；首次同步时以「服务端缓存里已有的 id」为起点

/** api 形态：把新增的审计留痕同步到服务端（R3-P1（F-09）：登记 pending-writes，失败让调用方感知） */
function _syncAuthAuditToServer(records) {
  const rows = Array.isArray(records) ? records : [];
  if (_auditSyncedIds === null) {
    _auditSyncedIds = new Set((Array.isArray(mockDB.authAudit) ? mockDB.authAudit : []).map((r) => r && r.id));
  }
  const fresh = rows.filter((r) => r && r.id && !_auditSyncedIds.has(r.id));
  if (!fresh.length) return;
  fresh.forEach((r) => _auditSyncedIds.add(r.id));
  const sync = import('../../data/data-adapter.js?v=20261028b').then(async ({ getDataSource, getAdapter }) => {
    if (getDataSource() !== 'api') return; // mock 形态：不发（本机键即权威）
    const a = getAdapter();
    if (!a.authAudit || typeof a.authAudit.create !== 'function') return;
    for (const r of fresh) {
      const target = getPersonById(r.targetPersonId);
      await a.authAudit.create({ ...r, branchId: target?.branchId || AuthStore.getCurrentUser()?.branchId || DEFAULT_BRANCH_ID });
    }
  }).catch((e) => {
    fresh.forEach((r) => _auditSyncedIds.delete(r.id)); // 失败回滚登记 → 下次写重试
    console.warn('[AuthStore] api 形态审计留痕落服务端失败（本地已记，下次 init 以服务端为准）：', e);
    throw e;
  });
  trackWrite(sync).catch(() => {});
}

// R3-P1（F-09）：授权审计语义端点登记 pending-writes（置尾 import，避免上文 README 取证行号漂移）
import { trackWrite } from '../../core/session/pending-writes.js?v=20261028b';

// ════════════════════════════════════════════════════════════════
//  服务端优先登录（2026-10-26 Task 2.1）
// ════════════════════════════════════════════════════════════════
// 口径（spec「登录服务端优先」）：有 server（非静态托管）时**先** `POST /api/v1/auth/login`，
//   成功后才写 `gsm1921-login-user` / `gsm1921-api-token` / 本标签页会话快照；
//   后端 401 或网络失败 ⇒ 抛错（登录页显示可见错误并停留，不跳工作台）。
// 本地账号层（`verifyCredentials` + `gsm1921-accounts` / `MOCK_ACCOUNTS`）只用于：
//   · 静态托管（`DEPLOY_MODE === 'static'`）；· 显式开发模式（登录页复选框 / 调用方传 `serverFirst:false`）。
// IAAA 路径不经本函数（`startIaaaSession` 保持原样）。
// ⚠ 置尾覆盖：本文件上文的行号是 README-server.md 的取证靶点，`login()` 原位改写会整体漂移；
//   故与 `deputy-leader` / 审计同步同法——**集中置尾**重绑 `AuthStore.login`，语义不变、上方行号不动。
import { DEPLOY_MODE } from '../../config/deploy.js?v=20261028b';

const LOGIN_ENDPOINT = '/api/v1/auth/login';

/** 构造带 HTTP 状态的登录错误（401=口令/账号错误；0=网络不可达；其余=服务端失败） */
function _loginFailure(message, status) {
  return Object.assign(new Error(message), { status });
}

/**
 * 服务端登录取会话（成功才返回 `{token,user}`；失败一律抛错，不静默降级）。
 * @param {string} personId
 * @param {string} password
 * @returns {Promise<{token:string,user:Object}>}
 */
async function _requestServerLogin(personId, password) {
  let response;
  try {
    response = await fetch(LOGIN_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ personId, password }),
    });
  } catch (e) {
    throw _loginFailure('无法连接服务器，请稍后重试', 0);
  }
  let body = null;
  try { body = await response.json(); } catch (_) { body = null; }
  if (!response.ok) {
    const message = (body && body.error)
      || (response.status === 401 ? '学号或口令错误，请重试' : `登录失败（HTTP ${response.status}）`);
    throw _loginFailure(message, response.status);
  }
  if (!body || !body.token) throw _loginFailure('服务器未返回登录会话，请稍后重试', 502);
  return body;
}

/** 是否走服务端优先：调用方可显式覆盖；缺省按部署形态（server=是 / static=否） */
function _loginServerFirst(options) {
  if (options && options.serverFirst !== undefined) return !!options.serverFirst;
  return DEPLOY_MODE === 'server';
}

// 保留本地优先实现（静态托管 / 显式开发模式复用；避免复制第二套落盘逻辑）
const _localFirstLogin = AuthStore.login;

/**
 * 登录（服务端优先）。**成功后才写本地登录态**；后端失败抛错由登录页显示。
 * @param {string} personId
 * @param {string} [password]
 * @param {{ serverFirst?: boolean }} [options] `serverFirst:false` = 静态托管 / 显式开发模式
 * @returns {Promise<void>}
 */
AuthStore.login = async function login(personId, password, options = {}) {
  if (!_loginServerFirst(options)) {
    return _localFirstLogin.call(AuthStore, personId, password);
  }
  const accountId = _toStudentId(personId);
  if (accountId == null) throw _loginFailure('账号不存在', 401);
  const data = await _requestServerLogin(accountId, password);
  const user = data.user || {};
  const patch = {
    personId: user.id || accountId,
    role: user.role || _getUserRoleFromMemory(accountId),
  };
  // 批次 277：服务端**明给** branchId 才带上（缺字段＝未知 ⇒ 不写 ⇒ 不走待归属阻断层）
  if (Object.prototype.hasOwnProperty.call(user, 'branchId')) patch.branchId = user.branchId;
  // 顺序：先落登录快照，再由 enableApiMode 写 token（两者都在服务端 200 之后）
  _writeLogin(patch);
  enableApiMode(data.token);
  console.info('[AuthStore] 已切换至 API 数据源（服务端优先登录）');
};
