// role: [工程师]+[AI]
// ════════════════════════════════════════════════════════════════
//  service.signup.js — 报名记录（活动/专班统一报名渠道）
//  SignupRecord { id, sourceType: 'activity'|'taskforce', sourceId,
//                 personId, role: 'participant'|'organizer'|'deep',
//                 status: 'approved'|'pending'|'rejected'|'cancelled',
//                 createdAt, reviewedBy, reviewedAt, note }
//  分级审批：participant = 报名即加入（auto approved）；
//            organizer/deep = 报名 + 发起人审核（pending → 通过/拒绝）。
// ════════════════════════════════════════════════════════════════

import { mockDB } from '../../core/domain/domain.js?v=20261028a';
import { generateId } from '../../core/base/id.js?v=20261028a';
import { persist, getDataSource } from '../../data/data-adapter.js?v=20261028a';
import { bumpToken } from '../../core/base/version-token.js?v=20261028a'; // P0 域缓存失效（spec §二.3）
import { SEED_SIGNUPS } from '../../data/mock/seed.js?v=20261028a';
import { isInitStateActive } from '../core/init-reset.js?v=20261028a'; // C2 修复（2026-09-08）：init 态跳过演示种子兜底
import { getPersonById } from '../member/person.js?v=20261028a';
import { TodoStore, TodoSourceType, TodoActionType, TodoCategory, TodoStatus } from '../governance/todo.js?v=20261028a';
import { AuthStore } from '../core/auth.js?v=20261028a';
import { TaskForceRecordStore } from './taskforce.js?v=20261028a';
import { isWorkgroupMemberRole, removeSignupWorkgroupRole, workgroupMembers } from './workgroup-members.js?v=20261028a';
// 组织者身份判据单一源（2026-09-19 批次 91 · SOP-B-17）——「谁能关本场报名」读它，勿另写一份
import { isActivityOrganizer } from './activity.js?v=20261028a';
import { todayLocal } from '../../core/base/utils.js?v=20261028a';
import { usesFormalMeetingRoster } from '../../core/domain/constants.js?v=20261028a';

// ── 枚举 ────────────────────────────────────────────────────────
const SignupRole = {
  PARTICIPANT: 'participant', // 普通参与
  ORGANIZER: 'organizer',     // 组织者
  DEEP: 'deep',               // 深度参与
};
export const SIGNUP_ROLE_LABELS = {
  [SignupRole.PARTICIPANT]: '普通参与',
  [SignupRole.ORGANIZER]: '组织者',
  [SignupRole.DEEP]: '深度参与',
};
export const SignupStatus = {
  APPROVED: 'approved',
  PENDING: 'pending',
  REJECTED: 'rejected',
  CANCELLED: 'cancelled',
};
export const SIGNUP_STATUS_LABELS = {
  [SignupStatus.APPROVED]: '已通过',
  [SignupStatus.PENDING]: '待审核',
  [SignupStatus.REJECTED]: '已拒绝',
  [SignupStatus.CANCELLED]: '已取消',
};

function _loadSignups() {
  try { return [...mockDB.signups]; }
  catch (e) { console.warn('[SignupStore] 加载失败：', e); return []; }
}
function _saveSignups(records) {
  mockDB.signups = [...records];
  bumpToken('signup'); // P0：报名写口统一 bump（apply/review/cancel/init 落库均经本函数）
  persist();
}

/** 今日 YYYY-MM-DD */
function _today() { return todayLocal(); }

/** 源对象 scenarioId（活动侧；专班无 scenario）——落 actionData 供 todo 域判定（IA-C1 Task2） */
function _sourceScenarioId(sourceType, sourceId) {
  if (sourceType !== 'activity') return null;
  const act = mockDB.activities.find(a => a.id === sourceId);
  return act ? (act.scenarioId || act.type || null) : null;
}

/**
 * 取审核人（发起人）
 * 活动：activity.organizer || activity.createdBy
 * 专班：taskforce.initiator || members 中 role='organizer' 者
 * @returns {string|null} personId
 */
export function resolveSignupReviewer(sourceType, sourceId) {
  if (sourceType === 'activity') {
    const act = mockDB.activities.find(a => a.id === sourceId);
    return act ? (act.organizer || act.createdBy || null) : null;
  }
  if (sourceType === 'taskforce') {
    const tf = TaskForceRecordStore.getAll().find(t => t.id === sourceId);
    if (!tf) return null;
    if (tf.initiator) return tf.initiator;
    const org = (tf.members || []).find(m => m.role === 'organizer');
    return org ? org.personId : null;
  }
  return null;
}

/** 活动/专班是否存在且可报名 */
function _sourceOpen(sourceType, sourceId) {
  if (sourceType === 'activity') {
    const act = mockDB.activities.find(a => a.id === sourceId);
    if (!act) return { ok: false, reason: '活动不存在' };
    if (usesFormalMeetingRoster(act)) return { ok: false, reason: '三会一课与组织生活会使用正式名单，无需报名' };
    if (act.archived || act.status === 'cancelled') return { ok: false, reason: '该活动当前不可报名' };
    // 草稿活动默认不可报名；写入活动时勾「开放报名」（signupEnabled）者例外——
    // 这样「活动可开报名」是写入侧的一次显式动作，而不是把所有草稿一律放开（SOP-B-2）。
    if (act.status === 'draft' && act.signupEnabled !== true) return { ok: false, reason: '该活动当前不可报名' };
    // 组织者（或支书）手动关掉本场报名（支书 2026-09-20 定案：「不设截止，但组织者可手动关」）——
    // 关掉即不接受**新报**；已报者仍可取消（取消不经本判据，见 cancel()）。
    if (act.signupClosed === true) return { ok: false, reason: '本场报名已关闭' };
    if (!act.date || act.date < _today()) return { ok: false, reason: '活动已结束' };
    return { ok: true };
  }
  const tf = TaskForceRecordStore.getAll().find(t => t.id === sourceId);
  if (!tf) return { ok: false, reason: '专班不存在' };
  if (tf.status !== 'recruiting') return { ok: false, reason: '该专班当前未在招募' };
  if (tf.deadline && tf.deadline < _today()) return { ok: false, reason: '报名已截止' };
  return { ok: true };
}

/** 发起审核待办（pending 报名生成） */
function _createReviewTodo(sourceType, sourceId, signup) {
  const reviewerId = resolveSignupReviewer(sourceType, sourceId);
  if (!reviewerId) return;
  const person = getPersonById(reviewerId);
  const role = person ? person.role : null;
  if (!role) return;
  const label = sourceType === 'activity' ? '活动' : '专班';
  const title = sourceType === 'activity'
    ? (mockDB.activities.find(a => a.id === sourceId)?.title || '活动')
    : (TaskForceRecordStore.getAll().find(t => t.id === sourceId)?.name || '专班');
  TodoStore.create({
    title: `审核「${title}」报名：${getPersonById(signup.personId)?.name || signup.personId}`,
    description: `${label}报名待审核（${SIGNUP_ROLE_LABELS[signup.role] || signup.role}）`,
    role,
    category: TodoCategory.REVIEW,
    priority: 'normal',
    deadline: null,
    sourceType,
    sourceId,
    actionType: TodoActionType.REVIEW,
    actionKey: 'signup-review',
    // IA-C1 Task2：源 scenarioId 落 actionData → domain 判定（活动侧按三会/实践分域；专班侧按 sourceType）
    actionData: { signupId: signup.id, sourceType, sourceId, scenarioId: _sourceScenarioId(sourceType, sourceId) },
    flow: `报名申请 → ${getPersonById(reviewerId)?.name || ''}审核`,
  });
}

/** 生成报名人「参与」待办（approved 后） */
function _createParticipateTodo(sourceType, sourceId, personId) {
  // 专班成员通过组织者/深度参与者身份进入工作组；后续动作由工作任务与工作考察承接。
  if (sourceType === 'taskforce') return;
  const person = getPersonById(personId);
  if (!person || person.role !== 'participant') return; // 仅普通成员视角
  const act = mockDB.activities.find(a => a.id === sourceId);
  if (!act || act.date < _today()) return;
  // dup 检查仅限「参与」类待办，且按人收敛：同源 signup-review 等其它待办 / 他人的参与行不得阻止本人重建（B-499-3）
  const dup = TodoStore.getBySource(TodoSourceType.ACTIVITY, sourceId)
    .some(t => String(t.personId || '') === String(personId)
      && t.actionType === TodoActionType.PARTICIPATE
      && t.status !== TodoStatus.COMPLETED);
  if (dup) return;
  TodoStore.create({
    title: `参与活动「${act.title || '未命名'}」`,
    description: `活动日期：${act.date}。请按时参与并配合考勤。`,
    role: 'visitor',
    // 到人归属：visitor 不是登录角色，服务端行级写门只认 personId（B-499-3）
    personId,
    category: TodoCategory.TRACK,
    priority: 'normal',
    deadline: act.date,
    sourceType: TodoSourceType.ACTIVITY,
    sourceId,
    actionType: TodoActionType.PARTICIPATE,
    // IA-C1 Task2：与 VisitorTodoDeriver 同键聚合；scenarioId 落 actionData 供域判定
    actionKey: 'participate',
    actionData: { activityId: sourceId, scenarioId: act.scenarioId || act.type || null },
  });
}

/** 审核通过后只把组织者/深度参与者同步到工作组成员；普通参与者只保留报名事实。 */
async function _writeSource(sourceType, sourceId, personId, role) {
  if (!isWorkgroupMemberRole(role)) return;
  if (sourceType === 'activity') {
    const act = mockDB.activities.find(a => a.id === sourceId);
    if (!act) return;
    const cur = Array.isArray(act.assignments) ? act.assignments : [];
    if (cur.some((row) => row.personId === personId && row.role === role)) return;
    // 复用三合一机制；旧 participant 行不自动转成成员。
    const merged = [...cur.filter((row) => row.personId !== personId), { personId, role }];
    await AuthStore.syncProjectRoles({ scopeRef: sourceId, assignments: merged, actorId: personId });
  } else {
    const tf = TaskForceRecordStore.getAll().find(t => t.id === sourceId);
    if (!tf) return;
    if ((tf.members || []).some(m => m.personId === personId)) return; // 历史专班 participant 保留待核，不自动转换
    // R9 Task 4.2：成员关系写**工作组主源**（workgroup_members）；适配器同事务回写
    //   `taskforces.members` 兼容镜像（旧读口只读保留）。
    await TaskForceRecordStore.addMember(sourceId, { personId, role });
  }
}

export const SignupStore = {
  _signups: [],

  init() {
    const persisted = _loadSignups();
    if (persisted.length > 0) {
      this._signups = persisted;
    } else if (getDataSource() === 'api' || isInitStateActive()) {
      // C2 修复（2026-09-08）：init 态下「无持久化报名 = 合法空支部态」——不兜底演示种子
      //（否则 SEED_SIGNUPS 会经 _saveSignups 重新写回 mockDB/持久层）。
      // Task 3（2026-10-26）：api 形态同样禁止空表回退，且不落库（没有 _saveSignups / persist）。
      this._signups = [];
    } else {
      this._signups = [...SEED_SIGNUPS];
      _saveSignups(this._signups);
    }
    // 补齐 pending 报名的审核待办（幂等：已存在对应 signup-review 待办则跳过）。
    // 种子/历史 pending 记录无预置待办，首次进入任意页面（含工作台）即可补齐，
    // 否则支书/组长/委员直入工作台看不到「去审核」入口（2026-08-08 验证发现）。
    try {
      const existKeys = new Set(
        TodoStore.getAll()
          .filter(t => t.actionKey === 'signup-review' && t.actionData?.signupId)
          .map(t => t.actionData.signupId)
      );
      for (const s of this._signups) {
        if (s.status !== SignupStatus.PENDING || existKeys.has(s.id)) continue;
        const reviewerId = resolveSignupReviewer(s.sourceType, s.sourceId);
        if (!reviewerId) continue;
        const person = getPersonById(reviewerId);
        if (!person || !person.role) continue;
        const label = s.sourceType === 'activity' ? '活动' : '专班';
        const title = s.sourceType === 'activity'
          ? (mockDB.activities.find(a => a.id === s.sourceId)?.title || '活动')
          : (TaskForceRecordStore.getAll().find(t => t.id === s.sourceId)?.name || '专班');
        TodoStore.create({
          title: `审核「${title}」报名：${getPersonById(s.personId)?.name || s.personId}`,
          description: `${label}报名待审核（${SIGNUP_ROLE_LABELS[s.role] || s.role}）`,
          role: person.role,
          category: TodoCategory.REVIEW,
          priority: 'normal',
          deadline: null,
          sourceType: s.sourceType,
          sourceId: s.sourceId,
          actionType: TodoActionType.REVIEW,
          actionKey: 'signup-review',
          actionData: { signupId: s.id, sourceType: s.sourceType, sourceId: s.sourceId, scenarioId: _sourceScenarioId(s.sourceType, s.sourceId) },
          flow: `报名申请 → ${person.name || ''}审核`,
        });
        existKeys.add(s.id);
      }
    } catch (e) {
      console.warn('[SignupStore] 补齐审核待办失败：', e);
    }
  },

  // 读侧出列（2026-10-03 批次 358 · `D-751`）：被「作废（软）」的报名记录不出现在任何**列表读**里
  //   （`getAll()` 是纯读口——各写口 `apply` / `review` / `cancel` / `deleteBySource` 一律走 `this._signups`，
  //   不经本方法 ⇒ 在此过滤**不会**把 `voided` 行丢掉）。留痕仍在 `mockDB.signups` 里可回查。
  getAll() { return [...this._signups].filter(s => !s.voided); },

  getBySource(sourceType, sourceId) {
    return this._signups.filter(s => s.sourceType === sourceType && s.sourceId === sourceId);
  },

  /**
   * 按来源删除报名（来源对象被删除 / 撤销时的联动清理）。
   * 2026-10-02 批次 343（`D-744` D 档写口纪律）：**本方法取代调用方对 `_signups` 私有字段的原地改写**
   *   ——原先 `org/taskforce-tab.js` 直接 `SignupStore._signups = ...` ＋ `mockDB.signups = ...` ＋ `persist()`，
   *   **绕过了本店写口**（`_saveSignups` 里的 `bumpToken('signup')` 没跑 ⇒ 报名域缓存不失效）。
   *   现统一走 `_saveSignups`，行为与 `apply` / `cancel` / `review` 同源。
   * @param {string} sourceType
   * @param {string} sourceId
   * @returns {number} 删除条数
   */
  deleteBySource(sourceType, sourceId) {
    const before = this._signups.length;
    this._signups = this._signups.filter(s => !(s.sourceType === sourceType && s.sourceId === sourceId));
    const removed = before - this._signups.length;
    if (removed > 0) _saveSignups(this._signups);
    return removed;
  },

  getMySignups(personId) {
    return this._signups.filter(s => s.personId === personId);
  },

  /**
   * 是否「已有有效报名」（**仅计 APPROVED / PENDING**）。
   * `SOP` 裁定（2026-10-05 · 批次 405）：**已「作废（软）」的报名不再挡重复报名** ⇒
   *   显式排除 `voided` 行（作废即释放名额，本人可重新报名）；留痕仍在 `mockDB.signups` 可回查。
   */
  hasApplied(sourceType, sourceId, personId) {
    return this._signups.some(s =>
      !s.voided &&
      s.sourceType === sourceType && s.sourceId === sourceId && s.personId === personId &&
      (s.status === SignupStatus.APPROVED || s.status === SignupStatus.PENDING)
    );
  },

  /**
   * 提交报名。participant → auto approved；organizer/deep → pending 待审核。
   * @returns {{ ok: boolean, reason?: string, signup?: object }}
   */
  apply({ sourceType, sourceId, personId, role = SignupRole.PARTICIPANT, note = '', onsite }) {
    if (!personId) return { ok: false, reason: '未登录' };
    if (sourceType === 'taskforce' && role === SignupRole.PARTICIPANT) {
      return { ok: false, reason: '专班只设组织者与深度参与者，不接受普通参与报名' };
    }
    const chk = _sourceOpen(sourceType, sourceId);
    if (!chk.ok) return { ok: false, reason: chk.reason };
    const activity = sourceType === 'activity' ? mockDB.activities.find((row) => row.id === sourceId) : null;
    if (activity?.type === '主题党日' && ['organizer', 'deep'].includes(role) && typeof onsite !== 'boolean') {
      return { ok: false, reason: '主题党日组织者与深度参与者报名时须明确选择是否线下参加' };
    }
    if (sourceType === 'activity' && activity?.type !== '主题党日' && onsite !== undefined) {
      return { ok: false, reason: '线下参加选择仅适用于主题党日报名' };
    }
    if (this.hasApplied(sourceType, sourceId, personId)) return { ok: false, reason: '您已报名，请勿重复提交' };
    // 专班名额校验
    if (sourceType === 'taskforce') {
      const tf = TaskForceRecordStore.getAll().find(t => t.id === sourceId);
      if (tf && tf.capacity && workgroupMembers(tf.members).length >= tf.capacity) return { ok: false, reason: '名额已满' };
    }
    const isAuto = role === SignupRole.PARTICIPANT;
    const record = {
      id: generateId('su'),
      sourceType,
      sourceId,
      personId,
      role,
      status: isAuto ? SignupStatus.APPROVED : SignupStatus.PENDING,
      ...(activity?.type === '主题党日' ? { onsite: role === SignupRole.PARTICIPANT ? true : onsite } : {}),
      createdAt: new Date().toISOString(),
      reviewedBy: null,
      reviewedAt: null,
      note: note || null,
    };
    this._signups = [...this._signups, record];
    _saveSignups(this._signups);
    // 待办联动
    if (isAuto) {
      _writeSource(sourceType, sourceId, personId, role);
      _createParticipateTodo(sourceType, sourceId, personId);
    } else {
      _createReviewTodo(sourceType, sourceId, record);
    }
    return { ok: true, signup: record };
  },

  /**
   * 审核报名（pending → approved / rejected）
   * @param {string} id 报名记录 ID
   * @param {{ approve: boolean, reviewer: string }} opts
   * @returns {{ ok: boolean, reason?: string, signup?: object }}
   */
  async review(id, { approve, reviewer }) {
    const idx = this._signups.findIndex(s => s.id === id);
    if (idx === -1) return { ok: false, reason: '报名记录不存在' };
    const s = this._signups[idx];
    if (s.status !== SignupStatus.PENDING) return { ok: false, reason: '该报名已处理' };
    if (approve && s.sourceType === 'taskforce' && s.role === SignupRole.PARTICIPANT) {
      return { ok: false, reason: '专班不设普通参与身份；历史申请只能保留核查或拒绝，不能转为成员' };
    }
    const updated = {
      ...s,
      status: approve ? SignupStatus.APPROVED : SignupStatus.REJECTED,
      reviewedBy: reviewer || null,
      reviewedAt: new Date().toISOString(),
    };
    this._signups = [
      ...this._signups.slice(0, idx),
      updated,
      ...this._signups.slice(idx + 1),
    ];
    _saveSignups(this._signups);
    if (approve) {
      await _writeSource(s.sourceType, s.sourceId, s.personId, s.role);
      _createParticipateTodo(s.sourceType, s.sourceId, s.personId);
    }
    // 销审核待办（仅销该报名对应的 signup-review 待办）
    const todo = TodoStore.getAll().find(t =>
      t.actionKey === 'signup-review' && t.actionData?.signupId === id && t.status !== 'completed'
    );
    if (todo) TodoStore.complete(todo.id);
    return { ok: true, signup: updated };
  },

  /** 撤回/取消报名（pending 撤回；approved 普通参与取消） */
  cancel(id, personId) {
    const idx = this._signups.findIndex(s => s.id === id);
    if (idx === -1) return { ok: false, reason: '报名记录不存在' };
    const s = this._signups[idx];
    if (s.personId !== personId) return { ok: false, reason: '无权操作' };
    if (s.status === SignupStatus.REJECTED || s.status === SignupStatus.CANCELLED) return { ok: false, reason: '该报名不可取消' };
    const updated = { ...s, status: SignupStatus.CANCELLED, reviewedBy: personId, reviewedAt: new Date().toISOString() };
    this._signups = [
      ...this._signups.slice(0, idx),
      updated,
      ...this._signups.slice(idx + 1),
    ];
    _saveSignups(this._signups);
    // 仅取消组织者/深度参与者时同步移除其同角色工作组关系；普通报名不改成员主源。
    if (s.status === SignupStatus.APPROVED) {
      if (s.sourceType === 'activity') {
        const act = mockDB.activities.find(a => a.id === s.sourceId);
        if (act && Array.isArray(act.assignments) && isWorkgroupMemberRole(s.role)) {
          const remaining = removeSignupWorkgroupRole(act.assignments, s);
          if (remaining.length !== act.assignments.length) {
            import('../core/mock.js?v=20261028a').then(({ updateActivity }) => {
              updateActivity(s.sourceId, { assignments: remaining });
              persist(); // updateActivity 不自动落盘，须显式 persist
            });
          }
        }
      } else {
        const tf = TaskForceRecordStore.getAll().find(t => t.id === s.sourceId);
        if (tf && Array.isArray(tf.members) && isWorkgroupMemberRole(s.role)) {
          const remaining = removeSignupWorkgroupRole(tf.members, s);
          if (remaining.length !== tf.members.length) TaskForceRecordStore.update(s.sourceId, { members: remaining });
        }
      }
    }
    // 销对应参与待办
    const todo = TodoStore.getAll().find(t =>
      t.actionType === TodoActionType.PARTICIPATE &&
      t.sourceType === s.sourceType && t.sourceId === s.sourceId && t.status !== 'completed'
    );
    if (todo) TodoStore.complete(todo.id);
    // 撤回 pending 申请时同时销对应审核待办（避免审核人看到已撤回的报名）
    const reviewTodo = TodoStore.getAll().find(t =>
      t.actionKey === 'signup-review' && t.actionData?.signupId === id && t.status !== 'completed'
    );
    if (reviewTodo) TodoStore.complete(reviewTodo.id);
    return { ok: true };
  },
};

/**
 * 某来源「已通过」报名者 personId 列表 —— **考勤候选默认选中的来源**（D-288 / SOP-B-2）。
 * 口径（D-288「优先默认报名者选中，但保留组织者的调整空间」）：
 *   · 只认 `approved`（已通过）——待审核/已拒绝/已取消不进默认值；
 *   · 它只是**默认值**：候选范围不限报名者（未报名而实际参加者照样由组织者/纪检手选补进），
 *     组织者仍可增删（两套逻辑同时成立）。
 * @param {'activity'|'taskforce'} sourceType
 * @param {string} sourceId
 * @returns {string[]}
 */
export function getApprovedSignupPersonIds(sourceType, sourceId) {
  return SignupStore.getAll()
    .filter(s => s.sourceType === sourceType && s.sourceId === sourceId && s.status === SignupStatus.APPROVED)
    .map(s => s.personId);
}

// ════════════════════════════════════════════════════════════════
//  「手动关本场报名」（支书 2026-09-20 定案 · 批次 123）
//  支书原话：「不设截止，但组织者可手动关」⇒ **不新增「报名截止时点」字段**；
//  只在活动上落一个布尔 `signupClosed`（缺省 false＝未关），由**本场组织者 ＋ 支书/副支书**手动置位。
//  关掉后：**成员不能再新报**（`_sourceOpen` 判据）；**已报者仍可取消**（取消不经该判据）。
//  ⚠ 谁能关**照 `SOP-B-17` 既有组织者赋权机制**（发布口按人赋权、解除即收回）——
//    组织者判据读 `services/activity/activity.js::isActivityOrganizer`（单一源），不另写一份。
// ════════════════════════════════════════════════════════════════

/** 支部治理角色（可关本场报名）：支书 / 副支书 */
const SECRETARY_ROLES = new Set(['secretary', 'deputy-secretary']);

/**
 * 某人能否关某场活动的报名：**本场组织者**（`assignments`/顶层 organizer）**或 支书/副支书**。
 * 呈现（是否显示按钮）与动作（是否放行）**共用本判据**，勿在两处各写一份。
 * @param {string} personId
 * @param {Object|null} activity
 * @returns {boolean}
 */
export function canCloseActivitySignup(personId, activity) {
  if (!personId || !activity) return false;
  if (SECRETARY_ROLES.has((getPersonById(personId) || {}).role)) return true;
  return isActivityOrganizer(personId, activity.id);
}

/**
 * 手动关闭本场报名（**单一写口**）。
 * @param {string} activityId
 * @param {string} actorId
 * @returns {Promise<{ok: boolean, reason?: string}>}
 */
export async function closeActivitySignup(activityId, actorId) {
  const act = mockDB.activities.find(a => a.id === activityId);
  if (!act) return { ok: false, reason: '活动不存在' };
  if (!canCloseActivitySignup(actorId, act)) return { ok: false, reason: '仅本场组织者或支书可关闭报名' };
  if (act.signupClosed === true) return { ok: false, reason: '本场报名已关闭' };
  const { updateActivity } = await import('../core/mock.js?v=20261028a');
  await updateActivity(activityId, { signupClosed: true });
  return { ok: true };
}
